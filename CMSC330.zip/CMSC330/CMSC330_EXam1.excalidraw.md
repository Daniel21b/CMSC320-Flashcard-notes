---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠== You can decompress Drawing data with the command palette: 'Decompress current Excalidraw file'. For more info check in plugin settings under 'Saving'



# Code Block

To illustrate functional programming, here's a brief example using Python:

```python
# Functional approach
def double(x):
    return x * 2

numbers = [1, 2, 3, 4, 5]
doubled_numbers = list(map(double, numbers))
print(doubled_numbers)  # Output: [2, 4, 6, 8, 10]
```

This example demonstrates key functional programming concepts:

1. Pure function: `double` always produces the same output for a given input, without side effects.
2. Immutability: The original `numbers` list remains unchanged.
3. Higher-order function: `map` takes the `double` function as an argument.
4. Declarative style: We describe what we want (doubled numbers) rather than how to do it step-by-step.


# Excalidraw Data
## Text Elements
CMSC330 Exam 1 ^0PZsUumk

What is functional language?
-A functional language defines computations as mathematical functions
-avoids mutable state ^pUv4jBW5

State:
the information maintained by a computation ^2hvBfbOR

mutable:
can be changed ^2mzdASeZ

Code Example ^uepkq8Q8

Mutability:
The fantasy of mutablility:
- it's easy to reason about: the machine does this then this, linear action
The reality of mutability:
-Machine are good at complicated manipulation of state
-Humans are not good at understanding it
 ^43HHqLEk

Mutablility breaks the refrential transparency: ablility to replace expression with its value without
affecting result of computation.  ^idi6hpcx

Referential transparency is a property in programming 
where an expression can be replaced by its value
 without changing the program's behavior. 
This is a key feature of pure functional programming ^UAcfSyt3

imparative is on the opposite spectrum of functional programming

in imparative commands specify how to compute by destructively changing state ^zcBHZClJ

example;
functions/methods side effects:
int x = 0
int incr_x(){
  x++;
return x
} ^hEh6O43B

The function `incr_x()` has a side effect because it modifies the state of a variable (`x`) that is external to the function itself. In functional programming, a function is typically expected to return a value based solely on its input parameters without altering any external state. However, in this case, `incr_x()` does the following: ^NEtwD6zr

1. It accesses the global variable `x`, which is defined outside of the function. ^X70ukQGr

2. It increments the value of `x` by 1 using the statement `x++`. ^N0BFQi7R

3. It then returns the new value of `x`. ^GJbns6fv

The side effect here is the modification of the global variable `x`. This means that every time `incr_x()` is called, it changes the value of `x`, which can lead to unintended consequences if other parts of the program rely on the original value of `x`. This behavior is what distinguishes functions with side effects from pure functions, which do not change any state outside their own scope. ^I4RVtcEU

Mainly comparing functional programming and imparative ^jtMu9ju0

in functional programming we dont have commands, we have expressions. ^xQ4ljpKF

functional programming ^aenf53TQ

expressions specify ^V4phRUt1

what to compute ^cKWEQ8Cn

variables(identifiers)  never change value
functions never had side effects ^zi4HqSDb

The reality of immutablility:
_ No need to think about state
-Powerful ways to build correct programs ^Uux281ww

Expressions
 ^88qbulR5

Every kind of expressions has
    syntax
    semantics: - Type checking rules(static semantics): produce a type or fail with an error messag
    Evaluation rules(Dynamic semantics): Produce a value, or exception or infinite loop
 ^MNU34RzX

All values are expressions but all expressions are not values ^m3UFbAxM

Values: A value is an expression that does not need any further evaluation ^33sjopyw

In ocaml to multiply float numbers we need to add . after * arithmetic  ^L3pFIeWK

Type inference and annotation ^GWY0uD4i

Ocaml compiler infers types
 - Compilation fails with type error if it can't
 - Hard part of language design: guaranteeing
comipiler can infer types when program is 
correctly written ^7AyiKqNW

Ocaml does type checking at compile time,not
at run time ^5jqFkckZ

Can manually annotate types anywhere
= example be (6: int)
- useful for diagnosing type errors ^DSXzVypD

if expressions in Ocaml if then else - similar to ternary operator - written with ? :  ^7DwtjN8F

Also we cant use int as a bool
like 
while(1) print: in python would run but in ocaml doesn't ^SMQ5jSof

syntax:
 if e1 then e2 else e3

evaluation
- if e1 ==> true and e2 ==> v, then(if e1 then e2 else e3) ==> v
-if e1 == false and e3 ==> v, then(if e1 then e2 else e3) ==> v

type checking:
 if e1 has type bool and e2 has type t and e3 has type t then if e1 then e2 else e3 has type t ^iTkAy2ws

The let definition is not an expression itself ^KXh0ZQDU

however we can use let expressions ^Y5KzhfUO

we can use the 'in' keyword ^aK3IJsC7

Note: Remember from class that OCaml functions are expressions, and that expressions have values. The value of a function is the function itself. ^icplgVGH

OCaml has an in keyword which lets us use saved variables. For instance, let x = 5 in x evaluates to 5, and let x = 5 in x + 5 evaluates to 10. ^NKkdlFto

This works for any expression including functions: let f x = true && x in f true evaluates to the value of f true which is true while let f x = true && x in f false evaluates to the value of f false which is false. ^Y2NyEplt

In OCaml, the conditional expression `if x then true else false` requires `x` to be of type `bool`, hence the function `f` has the type `bool -> bool`. ^LOzPEB3d

Let expression
 ^9jtgKAa0

let a = 0 in a ;; ^RuLUyRpB

ocaml is binding the value 0 to a ^Isu7Cx1g

let b = 1 in 2 * b;;
int = 2 
b is bounded to 1 and 2 * b(which is 1) ^qif2XE23

Scope: The scope of a variable is where its name is meaningful ^W16l3DeR

let x = 42 in
    (*y is not meaniningful here*)
   x + (let y = '3110' in (* y is meaningful here *) int_of_string y) ^7ML2ZkQP

To ensure name irrelevance in programs, stop substituting when you reach a binding of
the same name ^ZbodHQW2

example: let x = 5 in (let x = 6 in x)
         let x = 6 in x __> we stop since its the same name. The compiler
give warning that there is unused variable x ^u1S6F4Dw

In ocaml variable are immutable, however if we compile the following code it does
seem like it is mutable
let x = 1 
let x = 2 
x will evaluate to 2, but  ^fMPXuc9A

its just nested scopes
   let x = 1 in 
        let x = 2 in 
            x ^8tmDLzQ2

Allocate memory that will alwys be 1 ^AXZtl2tq

Allocate memory that will always be 2 ^NaMMvXfq

Which piece of memory does name mean?
innermost scope, as would you scope ^UeiJZ5lW

Variables are not mutating we are allocating new peice of memory we refer to with 
the same name. At the top level we cant refer to the first variable we set to 1 ^1iO6qBBz

Anonymous function ^i2godk0u

Anonymous function has the key word

 ^zg5VFj1G

fun ^uzdhpPew

Syntax: fun x1 ... xn _> e ^M8EYAkaV

Ocaml rule of evaluation say that  ^2VsrijuS

the body of the function is not
 ^EDYpP2iQ

evaluated until ^IHZ1itH1

that the fuction  ^nbBAG79T

is applied. ^PQFQY7Qf

Evaluation: A function is a value:
no further computation to do
In particular, body e is not evalu
ated until function is applied ^dGO9AoYX

Also named lambda expressions ^M6SgLPct

functions are values
 ^bUE0R8KO

cam use them ^73NHuPh7

anywhere ^Z9w79sxd

we can use values ^eDqxLZb0

functions can take functions as argument ^h3Wjg49I

Functions can return functions as result ^gG2O9j6H

This is an incredibly poweful language feature ^eEBUhcuG

Tuples ^PkL1KQDj

tuples are way to group
different data types 
They are enclosed in parantheses ^AqsI9FC6

Tuples are fixed in size, meaning once created, they cannot be resized.
Access to elements within tuples is done via pattern matching ^IdxkvNTU

Example of function returning tuple ^g4fbI6WF

let divide a b = ^on4JDWMD

let quotient = a / b in ^xf4OUztA

let remainder = a mod b in ^OnzosFFu

(quotient, remainder);; ^Wglji88s

let (q, r) = divide 10 3;; ^y8PdLiv4

(* q is 3, r is 1 *) ^ZO5vW07J

Lists - Are unbounded unlike tuples and recods ^boGQ5GEg

List is a basic data structure in OCaml. Lists can be of arbitrary 
length and implemented as a linked data structure. 
Lists must be homogeneous, meaning all elements have the same type
we can distruct them by pattern matching. ^2wnsLoyr

In OCaml, the empty list [] (also called Nil) is polymorphic, meaning it can be a list of any type. This is expressed as: ^lZCxwYtX

The empty list [] has the type 'a list, which means it can be used as an empty list for any type. ^BloQLy1j

The cons operator :: takes an element of type t and a list of type t list and produces a new list of type t list ^9NjQACzO

# let x = [1;"world"] ;; (* all elements must have same type *) ^ZWwCHb0G

This expression has type string but an expression was expected of type int ^JRMNOu59

:: operator appends a single item, not a list, to the front of another list. The left argument of :: is an element, the right is a list. 'a -> 'a list -> 'a list, big O(1) ^87TXR5gI

Lists in Ocaml are Linked. [1;2;3] is represented as: ^47h5XoQs

An underscore _ is a wildcard pattern. It matches anything, add any bindings. It is useful to hold a place but discard the value i.e., when the variable does not appear in the branch expression. ^R5ypeESQ

Wildcards ^r1ZPILip

OCaml gives such functions polymorphic types. ^r4OetNnX

hd : 'a list -> 'a ^hKfZwCAN

This says the function takes a list of any element type 'a, and returns something of that same type. These are basically generic types in Java. 'a list is like List<T>. ^GXqGt9f8

Patten matching ^Nd97NZI4

To pull lists apart, we use the match construct. The pattern-matching part of the match is a sequence of clauses, each one of the form: pattern -> expr, separated by vertical bars (|). The clauses are processed in order, and only the expr of first matching clause is evaluated. The value of the entire match expression is the value of the expr of the matching clause; If no pattern matches expr, your match is said to be non-exhaustive and when a match fails it raise the exception Match_failure. Syntax ^HTS9ZVlG

match e with ^Rqw3DAI9

| p1 -> e1 ^CEvkiLsq

| pn -> en ^6xvXs2YH

OCaml is a statically typed language, and it doesn't allow matching values of different types. The pattern matching expects the type of the value being matched (3.14, a float) to be consistent with the types in the pattern (in your case, a string). ^1VlECnrK

let a = ^aOrvSpxc

match 3.14 with ^R5aOhHSg

| 3.14 -> true  (* Matching against the float 3.14 *) ^zSo97xJz

| _ -> false ^WRNZh0C0

example ^HHOWvNcd

Function types: ^o3OD0wht

Understand that -> means "function from" and "to." ^cW67tmur

Example: int -> string means "a function that takes an int and returns a string." ^r92wyWgl

Your initial approach attempts to decrement t by 1, but in OCaml, you can't perform arithmetic operations like that directly on lists. ^0ZNKuqXx

High order function.  ^pvjpSiUE

A higher order programming language is one where fucntions themselves are 
considered a data type.  ^93fFFAeR

 let apply f x = f x;; ^0K0yPkXQ

(* takes in a function) ^FCoP75p4

* returns a function *) ^nGoXoRrh

 let get_func = let add1 x = x + 1 in add1;; ^jWqXMXvJ

we just said that we bind data to variables if we want to use them again. Sometimes though, we don’t want to use ^OFIx2zWo

them again, or we have no need to store a function for repeated use. So we have this idea of anonymous functions. It is ^ENCd1CTa

anonymous because it has no variable name, which also means we cannot refer to it later. ^BsvtXCH3

This means let add1 x = x + 1 is just syntactic sugar of let add1 = fun x -> x + 1. ^O5vk3xaC

So to bind a fun to a name
let function name = fun -> x + y ^PmZiMzYn

key word: Semantics, the meaning
and the behavior of your program ^1cumUuac

Partial Application ^PdIWPmD4

partial application refers to the process of applying a function to some, but not all, of its arguments, producing a new function that takes the remaining arguments. This is possible because functions in OCaml are curried by default, meaning every function conceptually takes one argument and returns another function that takes the next argument ^HRlrDbMo

Partial application allows you to fix some parameters of a function and get back another function that takes fewer parameters ^jAPdQIaH

Example ^xFypWQE2

(* Define a function that takes three arguments *) ^0pwCPzEL

let add_three_numbers x y z = x + y + z ^yuXfkK4P

(* Partial application: apply the first argument (2) *) ^vRh16ziQ

let add_two_more = add_three_numbers 2 ^IfqFBga1

(* Now add_two_more is a function that takes two arguments *) ^vgXVUAIx

let result = add_two_more 3 4  (* This will compute 2 + 3 + 4 = 9 *) ^BIlcHEld

(* Partial application can be done multiple times *) ^zOMlUUOA

let add_one_more = add_two_more 3 (* This will return a function expecting 1 argument *) ^sMgoeHfr

let final_result = add_one_more 4  (* This computes 2 + 3 + 4 = 9 *) ^eik05r28

The big lie in OCAML!!(How partail application is possioble) ^l6fpFHIA

Multi-argument function do not exist
 ^tXn1PXr3

All things that look like multi argument functions are
actually single argument functions. ^3joTUFOO

fun x y -> e

is syntactic sugar for 

fun x -> (fun y -> e) ^VxBE0uGL

Another example
let add x y = x + y

is syntactic sugar for

let add = fun x -> 
            fun y -> 
                x + y ^NhCtVYwT

what boils down
to is just series of 
nested ananmous 
functions ^CeEY6uBj

fun x y z -> e

is syntactic sugar for

fun x -> (fun y -> (fun z -> e)) ^9mU4x4W4

OCaml syntax for type variable, single quote followed by
identifer -> 'foo, but most often just simply 'a ^dGyRICKD

Operators as function ^0bOvhxio

if we write () then and inside operator, like (+) 2 3 -> this is basically
a function. let add x y = x + y
 it will evaluate to 5 ^ZSB9RcQh

However we need to be careful, espcially with the *, because
(*) technically is opening comment. To resolve the issue put spaces between
the operators. ^rF5V8Fny

Infix operators are made up entirely of symbols like +, *, -, /, @, ^ ^URZYwsdv

Defining Custom Infix Operators ^aAEPvl9S

(* Define a custom infix operator for string concatenation *) ^MtMIl2WX

let (^^) s1 s2 = s1 ^ s2 ^60kx2B8n

(* Use the custom operator to concatenate strings *) ^dpnj1Oun

let result = "Hello" ^^ " OCaml"   (* This is "Hello OCaml" *) ^Mq8yp6yO

^^ is defined as an infix operator that concatenates two strings. ^aTiJZypq

Any existing function can be used as an infix operator by wrapping it in parentheses and backticks, ^usaNxJ5E

(* Define a regular function that multiplies two numbers *) ^o9aBqxHH

let multiply x y = x * y ^fKrxQ5MH

(* Use it as an infix operator *) ^XOjHw9bS

let result = 5 `multiply` 3  (* This is 15 *) ^CKLRzHTr

(* Define a custom infix operator for maximum *) ^T9ZF5b6T

let (<->) a b = if a > b then a else b ^fNOd7Jfa

(* Use the operator *) ^hrsaT7ZQ

let max_value = 7 <-> 10  (* This is 10 *) ^JHi6mvJF

Application operators( ^iYJ3pW2U

Application :
let (@@) f x = f x

Reverse application( AKA pipeline)

let (|>) x f = f x.       Example of @@ ^Q7xqgNIe

Helps us avoid writing () ^7WoKU7ub

Useful for make your code more readable by 
reducing the need for parentheses or simplifying function chaining. ^keCkmiNj

Application Example: (* Without @@, you need parentheses to group function applications *)
let result = print_endline (String.uppercase_ascii "hello")  (* Prints "HELLO" *)

(* With @@, no parentheses are needed because of its low precedence *)
let result = print_endline @@ String.uppercase_ascii "hello"  (* Prints "HELLO" *)
 ^pgHKbe9m

It takes the value on its left and passes it as the argument to the function on its right. This simplifies function pipelines by avoiding deeply nested function calls ^BDEVTg1k

let result = ^imZ9RVkp

5 ^Pisxuucp

|> (+) 3    (* Add 3 to 5, result is 8 *) ^0qGw1QvX

|> ( * ) 2  (* Multiply the result by 2, result is 16 *) ^qMl4mouD

(* Print the final result *) ^vogmDrAT

let () = print_int result  (* Output: 16 *) ^udyC5hOV

separate the elements in a list by ; ^5uwyGE3r

Records
Like tuples 
records are bounded
and accesable by name ^f6ctK3Tj

records are a way to define and group related data using named fields
 in other languages like JavaScript.
Useful for organizing related data in a clear and structured manner. ^6FwLlpec

(* Define a record type for a person *) ^0qaaL4gt

type person = { ^ivgEllDV

name : string; ^Rv4IXPGr

age : int; ^YYo2uglG

city : string; ^m7r2tNv5

} ^4Iv8iqqj

(* Create a person record *) ^ZBPRKAQx

let daniel = { name = "Daniel"; age = 22; city = "Miami" } ^RFGVpzx6

(* Access record fields *) ^Cm2Elrpd

let () = ^DBYS5YUe

print_endline ("Name: " ^ daniel.name); ^1aVvoGZs

The key word type ^YgRwrBWz

types. OCaml has a powerful type system, and the type keyword allows you to create custom types, including records, variants, and type aliases. It is crucial for structuring your data in meaningful ways ^1z6qCaxa

(* Create an alias for the type 'int' *)
type age = int ^hyBMrNDD

The type keyword is used to define record types, 
which allow you to group several 
values into one structure with named fields. ^jTUi8uNr

Example ^J1uXmnHR

The type keyword is also used to 
define variant types, which are similar to 
enums or tagged unions.  ^LBqoQPuJ

Variants allow a type to have multiple constructors ^PeybGGRw

(* Define a variant type for traffic lights *) ^fLYeOkVx

type traffic_light = ^1TS8vXv7

| Red ^KLwtXn7e

| Yellow ^35e3ewsU

| Green ^zqbieB1n

(* Function that returns the meaning of the light *) ^WtMhLnbm

let light_meaning light = ^nHG6c1k0

match light with ^own1Dd1m

| Red -> "Stop" ^hBj5S5AX

| Yellow -> "Caution" ^We6rPxIC

| Green -> "Go" ^PjgQbJ5t

(* Test the function *) ^on0NUPIx

let () = print_endline (light_meaning Red)  (* Output: Stop *) ^iTBhb1NQ

can use type to define parametric types (i.e., generic types) that work with any type ^Y3WvWM1F

(* Define a generic 'option' type *)
type 'a my_option =
  | None
  | Some of 'a

(* Use the type with an integer *)
let opt_value : int my_option = Some 42

(* Pattern matching on the value *)
let () =
  match opt_value with
  | Some x -> print_endline ("Value is " ^ string_of_int x)
  | None -> print_endline "No value" ^sD0FC1dc

Tuples are bounded and 
accesable by postion ^ego4TsUM

Record copy
 ^4xVnR0mh

(* Define a record type for a person *)
type person = {
  name : string;
  age : int;
  city : string;
}

(* Create a record value *)
let daniel = { name = "Daniel"; age = 22; city = "Miami" } ^4amLQnJ7

(* Use record copy to create a new record with a modified field *)
let daniel_in_ny = { daniel with city = "New York" }

(* Access the fields of the new record *)
let () =
  print_endline daniel_in_ny.name;  (* Output: Daniel *)
  print_endline daniel_in_ny.city;  (* Output: New York *)
 ^N8BDvIzn

This operation does not modify the original record (daniel). Instead, it creates a new record 
with the same fields as daniel, except for the modified field (city). ^x2wzUEvE

Why Use Record Copy? ^wueUH9b1

Immutability: In OCaml, records are immutable, so if you need to "modify" a field, you actually need to create a new record with the desired changes. Record copy allows you to do this easily. ^QZCvk99k

Efficiency: You only need to specify the fields that you want to change, while all other fields are copied from the original record automatically. This avoids repetitive code and potential mistakes when copying large records. ^lznYm1lv

Cannot add new fields... ^CNO2c7T5

records are immutable ^lPEUEiCD

the with keyword is specifically used to modify
 fields in a record when performing a record copy. ^LLc5ZKRX

Function keyword
Immediatley matching against implicit final argument
is useful there's a sugar for it

let f x y z = match z with | p1 -> e1
                            | p2 -> e2

can be written 
let f x y = function
| p1 -> e1
| p2 -> e2 ^6ncLdICY

@ operator O( appenend. Combines two lists
'a list -> 'a list -> 'a list
its big O(length lst1 -> lst1 @ lst2 ^giB81sJ7

Variants  ^4Daz7DN7

* Of other data that needs to be carried along ^akkqvNh7

Variants (also known as sum types or algebraic data types) are a way to define a type that can hold one of several possible values, each of which can have a different structure. They are very useful when you need to model data that can take on different forms, like an enum or union in other languages, but with much more flexibility. ^hIwvHc0v

To define a variant, use the type keyword followed by the variant constructors. Each constructor can optionally carry associated data (like fields in a record), and it represents a possible value the type can take. ^oJr15YQa

Ex 1 ^J7pdAp04

(* Define a variant type for the days of the week *) ^dvpZxPeN

type day = ^TrYTfrxS

| Monday ^rc6sjGgN

| Tuesday ^e3LUnqHw

| Wednesday ^VSzrVxAQ

| Thursday ^EF3kRKzQ

| Friday ^1fUr5fnx

| Saturday ^pgHmLJLi

| Sunday ^tbt1nqjK

(* Function to determine if a day is a weekend *) ^1YtBDWvW

let is_weekend d = ^rRv9JOe4

match d with ^h8Xfua7T

| Saturday | Sunday -> true ^qVdft3Vb

| _ -> false ^eTNR7Cqw

(* Example usage *) ^zxZ2nCrM

let today = Friday ^Jw79vfLH

let weekend = is_weekend today  (* Output: false *) ^LJns5xut

Ex 2 ^nqfTUK3y

Variant with Associated Data ^nCLzbrnQ

(* Define a variant type for shapes *) ^o1z699xR

type shape = ^VBiXRcGH

| Circle of float                (* Circle has a radius (float) *) ^CmBj0UHc

| Rectangle of float * float      (* Rectangle has length and width (float, float) *) ^FzqsZCtC

(* Function to calculate the area of a shape *) ^KqigZlEH

let area s = ^sYGm7kDo

match s with ^EdbZAsCA

| Circle radius -> 3.1415 *. radius *. radius ^WPPIL245

| Rectangle (length, width) -> length *. width ^7T4MjFBe

(* Example usage *) ^ZK280sZS

let my_circle = Circle 5.0 ^YzFB807n

let my_rectangle = Rectangle (10.0, 4.0) ^KQaWMr2B

let circle_area = area my_circle       (* Output: 78.5375 *) ^l8h0ONmY

let rectangle_area = area my_rectangle (* Output: 40.0 *) ^GIv5M9iy

Map ^nKYkh1p5

Fold ^byHn6daT

the map function is commonly used with collections such as lists and arrays. It applies a function to each element of a collection, returning a new collection with the results. ^A9Fm9JfR

The idea of map is to transform each element of a list (or array) based on a given function, leaving the structure of the collection unchanged. ^okUJ2Atm

(* Define a function that squares an integer *) ^JcqscyBn

let square x = x * x ^URu8VxcV

(* Use List.map to apply the square function to each element of a list *) ^kEhhjuSg

let squared_list = List.map square [1; 2; 3; 4; 5] ^yoxo4AJI

(* Print the result *) ^X305Bcc0

let () = List.iter (fun x -> print_int x; print_string " ") squared_list ^mkLgWLAf

(* Output: 1 4 9 16 25 *) ^34FnROfm

Ex ^ANiLrRtc

let rec map f = function
 | [] -> []
| h :: t -> f h :: map f t

map: ('a -> 'b) -> 'a list -> 'b list ^c65YeSnG

(* Convert a string to uppercase *) ^9eZ2r3HG

let to_uppercase s = String.uppercase_ascii s ^xUyeIgml

(* Use List.map to apply the function to each element of the list *) ^AYUVjeCb

let names = ["daniel"; "ocaml"; "functional"; "programming"] ^MaiW9hXm

let uppercase_names = List.map to_uppercase names ^if1deUBO

(* Print the result *) ^zCWucDaw

let () = List.iter (fun s -> print_endline s) uppercase_names ^on3ZAoZR

(* Output: ^ruY83PpF

DANIEL ^ZbhAujzf

OCAML ^mK171aFy

FUNCTIONAL ^Uhvo57TZ

PROGRAMMING ^kB8LcfwJ

*) ^QgKlK51m

Ex ^9vFRR9OG

Tail recursion ^ut6EK2a0

n a non-tail-recursive function, each recursive call has to keep track of its context (its local variables and the point to return to after the recursive call). This uses up memory for each recursive call, which can lead to a stack overflow if the recursion goes too deep. ^eQgAJDgu

With tail recursion, no additional memory is needed after the recursive call because the function has nothing left to do. The compiler can then optimize it to reuse the current function’s stack frame, turning the recursion into iteration, which saves memory. ^sCz1CmFl

(* Non-tail-recursive sum function *)
let rec sum n =
  if n = 0 then 0
  else n + sum (n - 1)

(* Example usage *)
let result = sum 5  (* Output: 15 *)
 ^d5qpU4GP

In this function, after calling sum (n - 1), the result of that call still needs to be added to n, so the function can’t immediately return. This means that each recursive call needs to keep track of the current n until all the recursive calls finish. ^HwzhLESn

This is not tail-recursive because the addition (n + ...) happens after the recursive call. ^KqpTzs2B

Ex of tail recursion

(* Tail-recursive sum function with an accumulator *)
let rec sum_tail n acc =
  if n = 0 then acc
  else sum_tail (n - 1) (acc + n)

(* Wrapper function to start with an initial accumulator value of 0 *)
let sum n = sum_tail n 0

(* Example usage *)
let result = sum 5  (* Output: 15 *)
 ^h5wkX3xH

we pass an accumulator (acc) that keeps track of the current sum as we recurse.
The recursive call is the last operation in the function (sum_tail (n - 1) (acc + n)), so after the recursive call, nothing else needs to be done.
This is tail-recursive because the recursive call happens as the last action, and no additional work needs to be done after the recursive call returns. ^oXBrUS5U

combining elements 
let rec combine init op = function
| [] -> init
| h :: t -> op h (combine init op t) ^xVEeeFOM

Combining elements, using init and op, is the essential idea behind the library function known as fold
fold is a cousin of reduce ^2JpaVc4N

Accumulates an answer by 
- Repeatedly applying f to an element of list and "answer so far"
- Folding in list elements "from the right" ^l4LiNHlj

he fold function is a powerful tool in functional programming that reduces a collection (like a list or an array) to a single value by applying a function iteratively to its elements, along with an accumulator that carries the intermediate result. ^KqzdVdO1

There are two common variations of fold: ^Bs3x8F9y

fold_left: Folds the list from the left (starting with the first element). ^OoH8i9Me

fold_right: Folds the list from the right (starting with the last element). ^gewikDEW

Ex of fold_left ^4nGwZUu5

(* Use fold_left to sum a list of integers *) ^jaaROXzB

let sum lst = ^yO52amTC

List.fold_left (fun acc x -> acc + x) 0 lst ^oz2vFJjC

(* Example usage *) ^sgIkK0kn

let result = sum [1; 2; 3; 4; 5]  (* Output: 15 *) ^psf5YO35

Initial accumulator: 0 (the second argument to fold_left). ^aFLX3jqH

Function (fun acc x -> acc + x): This function takes two arguments, acc (the accumulator) and x (the current element), and adds them together. ^5bCZIX7t

List.fold_left applies this function to each element in the list, starting with the first element (1) and updating the accumulator after each step. ^D6RfSoyn

Ex fold right ^BM8ZT2z3

(* Use fold_right to multiply elements of a list *) ^M5UgWTd1

let product lst = ^DVHbuPWe

List.fold_right (fun x acc -> x * acc) lst 1 ^3bBajCqm

(* Example usage *) ^DTFaPz2A

let result = product [1; 2; 3; 4; 5]  (* Output: 120 *) ^NmEpXRiy

Explanation: ^OU6k3ted

Initial accumulator: 1. ^dpj8Ikmc

Function (fun x acc -> x * acc): Multiplies the current element (x) by the accumulator (acc). ^ScbnB1rn

List.fold_right: Applies this function starting from the last element (5) and moves to the left through the list. ^mxTzoQT2

fold_left is tail revursive, since no work remains after recursive call ^CA8ftMaP

currying ^OxuQbgs0

closure ^ot2Yk7zX

ref ^r0U268oN

keywords ^2ddox1O3

Currying is a technique where a function that takes multiple arguments is transformed into a sequence of functions, each taking a single argument. ^ogdqlwak

Ex ^p8LUcym5

(* Non-curried function *) ^gc2XOfyo

let add_non_curried (x, y) = x + y ^HI78NeA6

(* Curried function *) ^yfnQ1aeN

let add_curried x y = x + y ^hFYQjReQ

(* Usage *) ^s6O72aPA

let result1 = add_non_curried (3, 4)  (* result1 = 7 *) ^jEKRY1vl

let result2 = add_curried 3 4         (* result2 = 7 *) ^ZSjErxLE

(* Partial application *) ^NdJvoZDS

let add_five = add_curried 5 ^YarIzv3P

let result3 = add_five 10             (* result3 = 15 *) ^DJNAlGRe

In this example, add_curried is a curried function. It takes its arguments one at a time, allowing for partial application. This is why we can create add_five, which is a new function that adds 5 to its argument. ^i73jQyQ4

A closure is a function together with its lexical environment. It allows a function to access variables 
from its outer scope even when executed outside that scope. ^gaPh3lQr

let create_counter initial_value = ^rAIR6zuz

let count = ref initial_value in ^tETkQBib

fun () -> ^hUxATtCj

count := !count + 1; ^NlmHCiPZ

!count ^Vig57RIR

(* Usage *) ^1tjmSoFn

let counter1 = create_counter 0 ^LAhS6CS6

let counter2 = create_counter 10 ^5vMtwHG7

let _ = ^AaDhT2Tl

Printf.printf "Counter1: %d\n" (counter1 ()); (* Prints: Counter1: 1 *) ^7ChEoLHT

Printf.printf "Counter1: %d\n" (counter1 ()); (* Prints: Counter1: 2 *) ^ysukGfFV

Printf.printf "Counter2: %d\n" (counter2 ()); (* Prints: Counter2: 11 *) ^bhOZza2d

Printf.printf "Counter1: %d\n" (counter1 ()); (* Prints: Counter1: 3 *) ^xiEFt7Sz

In this example, create_counter returns a function that closes over the count reference. Each counter maintains its own state, demonstrating how closures capture their environment. ^6LAdB9R0

let x = ref 0 ^mlCvUUXA

(* Reading a ref (dereferencing) *) ^F3FZaZL8

let value = !x  (* value is 0 *) ^Ek1NrSeX

(* Updating a ref *) ^F0IJ8xwn

x := 5  (* x now contains 5 *) ^8lQlRh2A

(* Using ref in a function *) ^BBk4s6X5

let increment_ref r = ^EJzw8MCs

r := !r + 1 ^47uuBZ8U

let y = ref 10 ^99BJWdbm

let _ = ^D7468Bb1

increment_ref y; ^6wqOdMc0

Printf.printf "y is now: %d\n" !y  (* Prints: y is now: 11 *) ^VjuHbL6z

(* Using ref with a record *) ^4ysDLJra

type person = { name: string; age: int ref } ^ymq1sYvs

let alice = { name = "Alice"; age = ref 30 } ^004vsoCk

let _ = ^FvVvrJZx

alice.age := !(alice.age) + 1; ^TtRmBUvX

Printf.printf "%s is now %d years old\n" alice.name !(alice.age) ^QpFdxeDw

(* Prints: Alice is now 31 years old *) ^5P6uiylM

In OCaml, ref is used to create mutable variables. It's a way to introduce controlled mutability in an otherwise immutable language. ^7HoPJTzU

Diagram  ^HmD6u1LW

## Element Links
ehcuFToj: [[CMSC330_EXam1.excalidraw#Code Block]]

## Embedded Files
4b96b8f6e7814fb8e93bab8428b12896e8a64d5e: [[Screenshot 2024-08-29 at 3.42.25 PM.png]]
f74180aa67da426221bb2c4e5cdea14c70df7e01: [[Pasted Image 20240904183610_621.png]]
f993433f760ef0161b84c81ce4233b7ca9f98681: [[Pasted Image 20240909152001_590.png]]
8a10e8afa51ebace29bef7f2375b3bd7726b70cf: [[Pasted Image 20240911162749_526.png]]
3f32671db5863c8236f9065cf00afb2d26e90843: [[Pasted Image 20240911204822_454.png]]
0125a0ca781908582b056927bd241d413d4fb33c: [[Pasted Image 20240912140222_832.png]]
e45630e7735ec9b9171f8852412dee10f6979949: [[Screenshot 2024-09-17 at 9.38.20 PM.png]]
a348914c183c0297b263edd65c4a4f19a843095e: [[Screenshot 2024-09-18 at 10.48.14 AM.png]]
0243327434d417ea434a36e46832278afb60a4f8: [[Screenshot 2024-09-18 at 10.51.00 AM.png]]
0b5585452194a8e58ea14b365e71b7dd47d6447f: [[Screenshot 2024-09-18 at 10.55.57 AM.png]]
42dd2f6d5de13693301ca289894801a228df2a45: [[Screenshot 2024-09-18 at 10.57.44 AM.png]]
1cba9e01b3f7cbb7e7f7c7086dc43c7cbd974a0a: [[Screenshot 2024-09-18 at 11.17.09 AM.png]]
d8300e105e2eee455480cd350e54c2ec93ddde33: [[Screenshot 2024-09-18 at 11.18.04 AM.png]]
c9576cb5c5caeeb058eabb8cfff256d32193661c: [[Screenshot 2024-09-18 at 11.21.59 AM.png]]

%%
## Drawing
```compressed-json
N4KAkARALgngDgUwgLgAQQQDwMYEMA2AlgCYBOuA7hADTgQBuCpAzoQPYB2KqATLZMzYBXUtiRoIACyhQ4zZAHoFAc0JRJQgEYA6bGwC2CgF7N6hbEcK4OCtptbErHALRY8RMpWdx8Q1TdIEfARcZgRmBShcZQUebTiANho6IIR9BA4oZm4AbXAwUDAi6HhxdEDsKI5lYOSiyEYWdi40AEYAVgBmAA5+YsbWTgA5TjFuVtaATk7JyfbWgHY+fMhC

DmIsbghcAAY64sJmABFUqARibgAzAjC+1YuJI1aARyMhAE0AFQBJAC1nACKAGVfgA1ADCME6ABkAApQZ77SCXQj4fBA2C1CSCDxIiDMKCkNgAawQAHUSOpuMt6vjCSSEBiYFj0DiSHiiX5JBxwtk2ncIGw4LhsGoYOMdjsBdYamUpSsIJhuM4Ep1OtpJlMFu1te1ugkACwGgXitDOVoJbQJa07ToGyYG/WdBYzAUEomk8FsfBsUhbADErQQQaDeM

0IuJyk56y9Pr9EkJ1mYwsCmTxFEpknGDo62jtnUlBp1rR2kxpxUkCEIymk3DL+u0Cw6O3ajtaPALCTdCHO3AWCwNap2RtaAqjwjg32IfNQOQAugLLuR0lPuBwhGiBdHiDzmDPCrTYIhuJ0VgBfAWaYTrACiwXSmRneXqBRWBwe6EICwBl2YHE6hCkDsUAcIQABCADSoLKJUzxcHcxRHmU2ykESVBvmeKwLgqQhwMQuBnB+iw8NaLo7As3TdK0xoK

kQHDEmuG74AKPrYKSH7XPgYT5Be+QHpASFbGcmBQHiAzNNwCQLAK4nDKMZQFgaiySgKawbEqEi4K0eKHCcwSEVcNwIKpH4QDssK/MwACqQj6Axi6ouimLIWyFxuvSpIUsQVJoOWAgeYyzlbK5HLCDWu4zqOCpCiKYoSvKtIyiyCXFBpqDOCR7TaEpBoJO00zzDsPBGiayolnEkzdJKPALAkrSURRnTtO5HoILGvoBiGwZIJeEbjkIMbeh1CbkBwy

a4KmokChm3lZm0Cw7HmCyzK0aoFuRVF+VIVY1qJvnNQqYS9m0Bo1TwVFSWOnKTtOuTYbSS64CuH7rpuCrbhFjFvbSV4DcQd5pBkWR3QKuH4QZ80kQkkrat0iksWsDFoK9zG0WwbHHagnG3AqlycFAQKEEYZQ8ClyL4wAYk9qKmqgUWHlge3oOCACyQLgkOqA3pgT10xylCfIzWys+znPc7z2kCsJUAAIJEMoLToMElxTQqjRQOYBBy9WivQEKeJ6

JkuBrEwq7I0xAq+tWawEILInC2zHMFlzPP6Hz0pCFAbAAErhETZSEkIxm0SbAASO21m08TtDxfT8SUx4JkLMlMIMisWgdtKyRwIwcGMaDLQt7aql2CpqZsmk8DpxynJj2PB7S7ISHAVn0AaABWYFku0eIomiTIsvi3rsi1DJeT5vCj6SA8ucPbnvWF3K8uMlvCqKsDxdK1TJQKaXOPaWX5TqPBdAOHbLaVBdxEp3TtOdkyGp0UlFlPbVDfG6CBt1

oa9Wx/WDXGISo1xqTXTJmPsw48wzCUnlW0kwdgJC2pWaskdUDam7Jjeqkp5grU6FdCcU4nz3WKI9Z6X1Ua0g+svc231ii/VvPeIGRDQZ4QIpgpYNpyJ6nhiHei5CWLo3YoZLiDcSH40JsTakZMIB40yFTfQNMV4KmllsMkkgCKoEOFjAalRmgEFQPgGUQhogIAAPwAB0XAy20XnDWnB9GGOqMY5QCBUAbBRLuVAeh9BwE9gRZozBUChFQPoAilZQ

ka3cDY3RnBmCWOcLgegbASCBP0H4zQwRUAEjYfzCgdsmYQDURorRlwdF2I4A4oxJiLFWOieUypTiTFuIQB48IXiDC+KiOUwJwSInhP8VE0ptiAnxMSck6cIT0mZOyWcPE0ttYKy2MrVWWcmCRK1vLXWXs4AG3xsbHkpAzaoBRpbUg1sKn4Hyao9RUBNGBKGTEi5BiqkuJqc4axDz6n4GeY0lxzTWmBO8Z0/xsSgmpLCWkAZ+jPkjJcGMlJkyogZN

cTMnqCpcCex9n7SRaBA6iMgHRBA4cUFM1aNHWOfFlGlCEsnNWqcJJoGhinJock85lFOi6Sqg5S6N3WBXdAuBOjVz0ggCGWMjImS2DwSQ9AwKXE0AAeW9r3RyM9gpzzxO6Me4DfKvzVdiDVW5F6fX5NFNecU2gqXRdvOUu9lTtFLBqSUpYT6Gm6P2emxRaZTG6PEYqtVrSzAfnlXoh0ArtQ/hAL+XUwx9W3BGoBSYUxAzAbNbg3K8z5TqpqA0CCT4

CmQbtbgDqMEfm6Dweq3QjT5oVP1G6zDcbLgQEck5C8/omuORbBU9D/qMMfCDHCrCxXEU4bDHhtI6JI07bQglgi64StxuI/2UjFyU2pvgb1UshYSAxGw5Alj1CuLWHjUgETmghP2VEE2xBUCaBgEE9pPi/HlNyVcndXSED7syJWTRHAT1ns4BetYV6eQ3rvQ+oFz6JJbpEgs3WyyxJrM1vgODQl9YCkNiB02L0u20itv4W2270C7rOF+w9v7/0go4

EBo217b33twI+4FL6PZe19qwHFqA8UIx5MSotUcT4UqKPHQSSd7bMrTieTO/R6Wsvzmgo0kwKKk1UnytK2wDTCtrhxBdjdTI8H0EYYgMsgQIF+Cq/uQUDW4lfuPOak8w2tX1ayQ1bbwrULpqvWKG9LXSKSrahUe8HWWn9ZqZ05EEhljypfXgLpGy2nbEpx0RodSvwTRIaN3VY1/3je/RNY1k1pmmjqumjpGz5XgTwOYSkdgdB5RWCOTMS2HR7ERT

oNULSwOk5AOthCB0PSbS23DxQqF7n4d268vbAb9rQPOFh4N2FQxhtw4cPGp2tonXOnTIjV2ZAkSTaRsioDyMUaahm9sJBpKRcEL9eBqOaFcdgdR1RexbgFkRiAV3cDItu9YW9j3nsuPnud2WmylktJWTJ0g6yUNg4TOhhUmH9nYfG3hs5BHLkfa+z9yxd3/teMB699FmL2PLtxaQIOPGiWNfGOSoovFhNUsTugNID3iD4WRYhlliseBVYk80XO8n

2xP3a2qKiqn1JbFwD3VSNd9Lzp22XUyCBJDYCEBTT4bB24WacsyZC6insiDRbSLVnkSuev8k5qzLmbNuaXmNs7xQYrr29VaxKNruDSKC+RPMuVy1lhqgORqMXoHaGCzqOGcxSZbVN2/QBGXnXOuy5GXL8f0CJgKxNFNxW02Mv7I2bo8DKqUTVC6GitJC2oIddIo6H5NRVS2r126s3iHIkGzhmdEBRszg23QybAMHzAxb/NthREliOnaKqR0ZZpK8

KnRAHIOQRZOx2AAfRvAADSemStwBASDkAoP6L0GxUBgVYsSOcc48Tn4VzjWkauCQGCOARXA3B+KQH0MQWERI5Bv7fJAIQMIBVewEgJwE4a4DcIfcVRXF8SAcMHLSbFmAiJ7cEawegUIYRO/F8CAeAlPRA5AyQAfFNcnSnf/HAuNSbdLT+S4GgpEOhCgv6BVc1HzVAJlMgq8UgDYUgJAqAJ7IgtMEg/FPvTgpgKgqNGgy4OguA30Lgpg7zWmMmEhV

EDIJ6BAUEQ4QgTnNAeuDCc8N0dwMoZ8eoC3MAVoLCITV8Q8alMTSHBoWTRWBIUNVZbnQXMoCYYNU6P3CXflbYJIWXEVMVeuSVCQIOOAYkZ4boAEboHXZzIeW3E3AKOzakPVa3OIkeO3DtC3QUZg13PzD3NAL3ZUJqA0PMCtciWqWrZae0WfWkWmJ+X1Yqd1ToDoKtWqc6NLPLDLLqH+btBggBYadPYBQrWwiAGaCeVadUFsSqeBIPciW0AtGnfaU

tCUI0ctWBPBWta6PrYfRtVQobTvbvVHPvP6fgqAubQdBbMfJbLhOGVbOfI42dDGbbLA8mPbMnXgQ7NdBRDdJREHYWNgE/cWHxWoN7PJD7Y/VxIEnwY3RCRmVDCQBDZlGHeE9PBHe/PZE2Q5DvChJ3dHG2THC7ZmAEyE12aEvEDFNjbFAOCnfFCAQlPjVBMlQTenOOJnZCFRfnTgKTLabOVw8YVaXNQvYqbw9TXASYLTeXZ42kpudAQcUOUOZ4aEG

8eyXGVVVIkKWzErGPAKWIjUjIjzLI53C1OmN3YofzT3O1M0B1BYbKPKTsThd1Jwr1OsO0bKRYfKGBJSWqSYDotPKNbomEuAvo4gMQjPEBbPBUMY+zAcRaOYB0DhSfGtCvRYumdBFrTBSrSLd1TUfBXCbY2cVvGRdvB4rvSbDtXvaQk4vtM4wssGUfcYDhaGG48dYoSdEsm/KU3bAmd4lTRdORddTdZRD7FmdJVEMUL9T4H9a4I2Zge9NgS4RFb7I

gIgWAL9ZwTRKAAAckCRCFnK4zYFQECFCEA2+2ECgFxR/VCSexNjcTYDaXUC0UPWowfOYGoAMRNgmiCUeUsUnNcSPJXLnIXOxzHNXPiSQOvJ5CCUCFQGUDYABKCVuSBSIDwEIgvVAl8UMXKVQHnKyQ/XiVDlsiTCgtcQ4DYFuVgvgo0T+lTiqEcGqA3MsVfWHNHIAonKnOsCiD3Jwux2XPHPiQ3O3NQF3PvS9kPN3JPN+nPK40vJFEkBvOIDvMCRf

OkoyGksODfMJU/JFHKR/J/X/LFGwqApYr4pcHArksgqzxgrgpvQ0SQs1lQtCXQo3Co0MtwrYXwsIrGmIuOTIqssotuWopYForWGUAYvgiHNgzhyVghy52RKir1h2QwwxIOX2JxMgHw3xLfXQBHKRRApgDYtcWnM4sAsXIyTyrXIEp3NCBEoPKPMEGo1PM9gvNcSvPMtcQUvvLkqUsrGfK6o0o/NIC/J0o4F/LEr31gFcuAtYrAtkpvMsoopssQo6

WQtHzQsIAwpcpwtRQ8scp6WgtIvIusoQtQECuyXWBCrCvJJJypO4G414WpxJVp2ZLAAZ0sMQmsPT1pWcMkzQDVG6wYHsL5LQFOlVHmDyi2nLlFLAglNFVv2lNMlAISEkDgGwCVAcksz13VXiOKFjySN1UcwZF1Nc0oWNQNK8xd03mtVlAtMC3tWokbEi2tEHAHCLGtBiwmBPjD0dHOm9Nq0NG1NajEMyx6J+mDNDKGKzyK0jJKyU0mGyhmGoiqLL

ErQWMerQGaxN1a24EL3qkWDhiyKbwbQGz2OxKNXbQ8wrJwP72rKfDfHf3uC2A4HBHoH1G+HwGcCECGG6G+GNj0CgFhBvHoBlzINEwFVQjYHQhfEwnqFrKHUW1HRW3L1bMRnbK20wNpKO32xXT7OOwHN+NhMJIgByqXLytvSPOJG6r/JaUmisG+TDMK2wHyqCTKoAv3LEp8BFFcSwDgECD3HPQzHUA3MCXQN8FcQHskDPMsVwBoIQF0Xot7sgNcsg

y6WaG0HQFBKyqLqmVLs0HLsrrEqXCBlrq4wltTEbrQBLtbtEsCA7rECEswB7t5H7rUEkCHtQBHqDlQHHsnoqRnrntCoXvwFuRwuXqozXrmThPisRLpWh2QxRISt2VoxStNuijxIuU3uLpboMt3pCArpUoPprv0XrslvPubt4omuvoQFvq7oft7rTi/pfrfo/rHpfp/unsuFno1nnvCEXpAY6Sg04HAdYyxQ42pNIInTDhTKZJjhZMpSsOZxQjQi5

x+tQCak5JznkmpADVLB1BqIODUyl3BBhsCN03fEdudtdvds9u9t9rIoDqDpiPVOJpxsSK1JSMxus3SJJq5EyPJuNJLDyOpoKMtPSg6DlqrRPi6FZqWF5yyO9T1u0B2Auj92tPaydMtwZCFoDOT3/hDM6MGKTUlpGKjMkhKIWhPjVGKnawfhdFVv41QC6G0BL3gSNCklWi1GWN+rdWflq1zPrX6xIWLJoTStLPNod1QHfwThJj0ImyrOmxrJH2HXH

1vibENFtGkTbOGYESePTvcgmigDAjUhCr/2wNSEHyOQgERuRtRroJkXRkAM91KKqz1CKkHCamtCoj0eKGUFwB2V8jDzWnygtBbEcJ1CUxmdpAyGIEOfOuqHbNCCgC9H0AURkHOFhGSQEOnRGeyWhxlnDooErFwBQchfWDxbQkJdMgmiUYFDgAxbOLfCMPqEULAB2DfFbzAEZaKENHiwqfa0HCqykg2NgMaeaeHFyibGaPBZfDnHMNkcZ3keQgqCq

GpvUYbJ5MBs0baAmEWHKYvjLgMc0iOGMbhuCPQCGCMDJDlUmFgvoGYFBBVEuAVWIFaFCVaE+EcY8Zty8ZcdajxocwSKt09bSOBxG1JvGcNJyMpvdyCdQEKLNDCe0A6ALGogNELmWnSYgG9ShkSaLArXay6CknaH+tjyye/kDPIIQL+nFsKdARzwnkn3VFOmoioi6GmCSzqcZN50bH7CkkND1FynBs6dQEojqlWhPi+YgENoGbbxNpLMOLQEmdDtP

HqFesrIYXmaNuKDrKWcaOPkn0QQnc2axe2aEW0KMgsJEw+ugC+qhxUZqh9JgbTiBpNNaIdHgQzchqlxvGNc7KVy2CshlmwEuCBBgCgCFXRt10Hj1IDe1Vz39Z9cJqcexsgE5Hc3Db8ZYICa3hjbjdCaLfiCZticUnbFOnZpqhKNbCLdiewSrV9IGKjQQAS2aJydT3o+Idrelrg66Cyk5QdSmC6HbH+sr1JVNIEC1raCojjMlYNq2ObwLMXCGePbb

XWHLOGzXam0H03YALjquITtuKToJRTq2bRh2bPZgLETeM417Iei+NO08wioKV9g4cIbrtPoyEbruQfR7qFDWXvTWFQG86jCegUXossQJaYFcT+27rofPTxwe3bsMTEDAz86yHfoICDksQYfUDPIJxlAuvI0C+XEEoe3UTMF9DXt0q0S0UY1JHvQ4YIiN1ct8WgphXsW+UK+C+OY3o+yc4i8yGPvY/c7856QC5/189/VG7YCC+RYurC8rGgqi9oaf

sAzi6ruoeS6YfS4QEy+/s9ly+qHy5/Q6/0GK5V0SXYFIAq5Gq6s85q4QDq5CCgEa5wua8KrKT0Xa6JGm5C+UAgcip1nBxVlirgfiu2UQawyxJLIyvQZ65aT641iIbc7zmG687G+hz8+o2O5+9QDm4i6CWo2i+W+o1W4S87o27UGHq2529Yb26ezy/ooK6+6K8CRK/O/K5x+u6q5G9q6xke+e4XNe7qQ+8m++66+J0pNEduppKpwZNJTpxetZIVZp

XE0fYZV4B6HUefdJiUgrUdFo/1cl00lDh/d2b/ceGwDAlDl+HBHwAACkPWoPnGMmzc4OBbEOg3oPQ2fGyazV5Co2zT8jY2QnnA75LRFgjRlphwmoqshXnSTpBxytZhHClMY+3fPR8mGOmPJZejK3+jI1BupbaQSnLUHQNRC2qsBX3UhOpGWwh2lgkn8wX5NiCE5PzjjayFjPvGVOLa1Ora5nNPp2IBt346myx07iJG+FO/Wy06zOXi7nLOSYM2js

TsfjHcBIPtCAfEJp/FGBPPANyMhRaXWAzgslEBKgKc3YcLWunkseQrLFLF/PN+Uwd/HsDBHKJlkxZ7CBLh70J6KA27l6ricDBsHdBCBdEjADdPt38ChVUUTFQuk/234axd+Wiffj+kP5sBj+KKM/oHEv4Llr++iW/tUHv6gRqMCA8gEgNf7ItrAH/M/t/1/4R0AB/DE/sAPCCBxwBQQe9HTwO70VYBMGUHADwRIxUkSIPAQaiUSqI5kqKOKfulTQ

aEZ4BW/cgYQGQGBJUBridAZgNP6cML+rlfAZ9ym7LgfuxAx/goJf6Pp3+gST/qKB/6oA/+jAp9MwPvQgC2BFAyAVwOgFuVZkwjUnJxjuoT8Hq9TaRhezZLK8Ri2ccYK2E16atWCPQesEVA/YGsBU3wE3rP3hpbBCCkgBIAqkHDQ0IORNZDnSF9ZuMCa08JDt6xQ5htIoGHXIthx3i00rS50PMAgmWil5+wvOCdt6knw2kjQbYVaMtDqh2g6Okaf0

Ix2aLMdf4eBKthnwL7FMSsGaWrDqFTZzFmiSZBrGrV4BN9NamCEdrlAfjkQ+m+ZNvoM1nbSDRm3fcZpbR7SnEtOQ/HTmqz04tlDOk/JTptlM7QE5+mdHskv1s6r97OfxCQFgCejQkAA3JYmv4RB0g2XD/iQC7p/0sgX6YDKgEwCoAAAvLGwf6ZBf02AUgKvkwAAAKAAJTABMuiIgANQkiQRHAQIE91IDUZMAliM8HAIKQAjgSCACkWCIUAQiJ6UI

k/C0g4aVB5A6I25EiNRE7BBRmI7EXiMJHEjMAZIikVSJEC0j6Rf3fgYskEFA9hB7geBmDySpIMpBzw3EucjkFMjSSwQNke91iQcjRUXIiwdCKEqwiBRJAoUSiLRGOjxROIgkUSOoykjyRlieUTSMRFKivBN1QQjLykby9Xql7BRhyVV5clLU/1XklEItDlplINoEUlLnt7+FtMpvPTFsCGA3goAFAI4AkCMB+hchpQkNs73JBFCYOJQj3k71GZod

KhvvCmr5hqEBZaQaUOWhtFJglhQWhUV0AqA6GF4w8FaSfDgmrwTsS2Gff0DwEuCTAEARoFjpQSmFI8ZhcHVoZmiTFFgFoyw6vmsOKjFtxOdMa0PaUiz/Up2Oxdvs2mJZe8zhPeXvpcJtq5A7aZBGUgwEIAsxJgVkMCBwDJDdBlARgb2BBB2A91bepADfJBCkJTMpc+LCALoRjqLMR+y2fTmtlTqvCgiOdLOr5C+H9lvig5P4egFGrX9UAAAAzWBY

j3R+IkiTYOCSMYHAMIvkbcgex4BACR6KAJYn0AAlv+hATqiig/SuVGM6BM5EuVcS4iSJmAEifiOkrFIdyIkJgBcgPQHlyMxEinkEEuBr1vg1GXQSLwMEhU3yuAUEeaNIFKV4AyGSAd3U4bnA26fohqml1Hq3pQg5wSxDiA4HYVSBqXNYJ0gC7b8IRqcLLhPT24EAzgZyeitYBgCWJGY8k/RKijXqhwI6CARoG+X87KU8AtwUieRIlEEjqJHVOJN+

kKregfQGYaoMgEZFbAiJRk9KXnEylUSaJI3eiXaMYn/YWJYQDciEi4koheJHgtQQuUEkTQrAyKVAGJIklST1AMk++sFKeSiVlJFU1SfgHUmoBNJQvNrjpM67VB9JS04yVxlMnuBzJD9SyTekobUjbJzDByWEBvQuTIBgGCnr+i8nP9fJLAfyTlyClMALqYU8aVFO+QxTUAcUigAlKYBJTeqWiVKcZEqkUTJR2UxSvgzxhogI6IVEqXwPgbQNnCcV

UQQgx1EQ9UqpyQ0QSQKTlThkgGMiVVMonUT1EdU20byM4ZNSMULUtQG1McAdT96qKASWl2EkDShpkk6Sbci0SRSaRRDJSVORmlZA1JGkrSUZIIFM9VpygdaSpJMlwAzJ96CyZUCsmHSFRD6E6eGDOlZJvQrkq6R5I4C3SfJsNB6bt1uTPSQpoVN6TzKeRfSfpf00gADLUqApHJb5QmWDKym3lOp0MwqXDKuoS93iGEvwbLyeoyMFecjd6lGJvZ2F

uc6adVi4UTFFtiwbzCGgkO2AQRkhbw1IRIA3wLQhAxIAEAAHFSxqpDGo73yG41qxCHWsaXLKENj7cTYvDJG1bFU1ahHY8YOqAbZVQlMhYE+LfHZpVp1QikJYNqCLDOhBhAYWcfOMXHjDcm1bTPBxyL4lZtQ7cpqAtCLZM080HbJmAtCHYhoFojoUsPsNb6FlSE14udmWR76d5HxG7QfsP106j9E6qEk4R2WzEWduyVnHCbnTwn511+hdMlAtNNnY

AxAe4TqTUDsD6IhJ/UzJOJJIlvkCW5gV+loncTXpLEZ5eqThWmn4yOA2gUqRID/nfAAFQCsIPvVAXhhvkECkSaRIkmwK5KT2TzkgtAzYVPYaChchgseTYKEZUDIQTAxRmqixB4PZHJDxOHQ8jRWwPBQQt5AgKfQpClmZAtcTQLqF8CuhS0joyoLbR6CgWZgvYXi8RG/s0xo8P8GMlwxivcOeyUjkA1o5aActJELZTFoCwcMTsNIk/aaRoQ6cgOWY

wkBDAdgYECmACC/DKoyxdYsua41d7uNq5FY2ub42bH+NRO2wQPrh05qLA1mhoRLOWn7Ds0HQloVsEmJdCjDJQ9WSsULQnkLjNM081jvn1XGpoJ45TKBE2FbAnwMlWRYTn2HVBNh68DqctHzTUbpkPwjNB0M8xk4t9rhJ8zGcpx3AXyRmV8gfpeK3a3DIY9w8fsnSeGW1n5KQrslhN4By1HQtUGMmkwQQRCc6K/fCQXQKRxB/54ojdvgxOk4VoF9G

OmCdVYAM9Kwzkj9IPkoVkiSJWiyhO9kLqnL8F5yzTpcq26uUbl4GVoPcsO58S2Ery8Se8s+XHLEZXC5GSIN4VoyJBuowRfqJkHYzN6vyrmVVIuXkYrlC5EFfejBWAEIVXU6FTKJJEfLfZOizjG4v0VByBMIciMcEJsLKM1eT8axfJikjagx2BnS5inNwAsxXFeiy5qZHzm29NAY0BIJcHoAO9Z4QSwoSEuKGBRAlNc1DnXO/nZE/eTc6Ni3NSja0

NQrYfUNRDFwVoBwGbWmKTB6DxAmopYVUP2GHAdgx5GWIpVPJz4TC8++WcMoX2KDF8Gm1oMPOmzVBcpnQe4+pl0s2FEQqo9UG+L02b55kj5CnY4ZitOFjLzhD462tfOmXadLidw++ShPuJPyZ+GctZZ8K7KHKdVKiCQOqDOVPkxKR0/ejyH/5ErKFtK7roXXrV/LG1NkltQgDbVArrlEkuFT/JVHwZEVUOHhVsjRLFAkcmJEZWjmxUfYe1tyPtaKg

VEDqh19kkdZ2u0XeCxGtJekmGOepsqleHK1Vm0Eiw8q3C1WYcLfEdBpjNIQwMVeZwdoSBvgBob2KCF4I3grIiqrGjXPLmqqax6qsJaFG97ocolmHGJeaWCZ1DeAIWU1UsGdALQOl/1G1Uk2vgXRZgSTJJnvLdWfwPVJSr1TPJXE1sIyC89cdDCtBTBEEhePNJGtQTnQa8R4xWraGSyuqk1/TPNUWTTWW1526ayZUwhvmzLUy1xMfv9SPbLKy1jK+

fm/MX5Vq86a/a9oXVGr1SKZlQGwXj0fKXl2p9lc9OotcQkKCAlichQNOgVr1JyWidIERVGm3I7ZIlTfnIoynEy7kuOAgMEGIBJTEKhOfeu2vkVf0aFr9PHMECJb7lLEA0YDFCysmGwwgzwIOGykCTf9sKh6QaimFS7GaVp+gX0TrN6pqDZBZC4dcStHWoAbNLPM7mV0GpaICWBESxI4AJAhUhAhwSsPciMmBJx6WScmfaKxhEg3Yr3QyZgtfLBbF

FClHyn5plCRcOA96JmaopPyHpAIKCigNRmYB6BEAY6rvN8txk/pNNsInTdBT00tUDNKFIzSwp/SmbitrMqBWVoq0hIQgXlBzUJUaDOb0goM6qdRKBlebzgvmqAZ1MC1ULRttCsLSEAOkHlotmQWLTeni0IBEt7nNpKlrIrzdvJ0OFQedtcTHcxKl0grdhSK12TP6e66zTd1Z7VbPOdW25I1q4bKAWtzANrRtM62MM9tjE+5P1oC6NcwRCi2heNoO

p/b8es2/ifNtcSLbBqEdVbetoQCbb5knC9UdwuRWzrxB6JdFUuoNEY5N6GmnrY1Pm5Hp96nE+mYZsAzZbLtMiihVZvK03c7Nj2m5M9qYCvbXNRM8GZ5x2k/bWpbg/7SVo7Wc7Qtf2cLWDpOqOiod7SMaLDqS1ALNEC5JHUwBR1Zb0dOWrHXORx3CLitu60rR8rN1aISdF3MnVbsp3NbWtbSMEf5O608jetS4AwGzpa4dbPdt5CbbzrelzamFto4X

dhRW1ZJxdm2ikvSrKDyaT1awwIXKzeoCQr2Src0lerQRZEExNitoMVC7mrR5gz6gVAqjfVz83x+gd4N7BLBsBfgHAVoHACGBkhMAxIduN0Ft47AZY3QCmIBs8bhKQNE8NPuBqVWaqKhOqo0rBsCaGrIAQWGqPEEqz1giwVUfKOzSLZy0829oHoK23qgPswNhSuccUqXGTC/S0wypfZlyhZQSO0wbMrmmHATsmlvkaYIkyLz6hymZ4otkO3D7ahtl

q0Q+UMsU6Cbz54zRdh9WXb971OVw58S+HtoSqtgZgT8d+N/H/jAJwE0CeBMgkIRB9CjKlhHTglR0sIiEq4o6DqiDgWmGzIzumpWUZyghF6sOtSxjE85Y+Ucp9lEOjzrRq0ehoVYbwFSwgl9mc9ANwa/E/i/xAEoCSBNIBgSIJacgJRBs1KgbK59+oDeEq1WRKG5eqk0m/vbFGqzQMwK0Igln3OglMvY/JZm3GCRZJiUxB0IXmDQJGpxfpGcTAc9W

i1c+eTBAxUrrbIGKOlTHoB0qIPMamYiQDsLaHdT3x3CerGNeEOhgZLtQkB75rJ2oMCbe+Qmhg8zh4AQtji67KZfJwuL1lIY8h81S0yyIybe+ah+TTiwOZHM4WC7N8BgGrIXNV96+nYJvu327799h+4/afvP23M8YD+R5rVhgRtsBSt8EsPlC+Y9Zfm1IOIA6naz1QpIpMFplK2YMYB1gMLOir93WOnMtjpkPMQWKLEljzj9zGcItALBLBKI8wIA1

JAQRzAEIk7F48DXiBzElMB7IAy2DMIrsWICLJFii0IjotgMJZZY2SwjoUsSyULWk+FyJYwTtDtIWlsBltovhOWLLUQ6y2lYIQeTRoAFqLkoikwqjohjKFaDqM9BETmoLUJMDZaytQ58rExUshNicrYxx4+MRq0n3Dt8ovODsBMHn3bAAQVh01hAFDiTB247wboPnOIAQQjAVUUONCHzksxkWq+TQHVEv1etr9wS2/aEof3+Gn9qml/dUOblhGP9y

oflmX26EthGNMMGLKdETZKR3SubSqI4VMNZH6OORyeaRvyPerCjbHYo5xwnh1Q3jFaRYDENJh1RqjtON9iGhqjWgSOhbUg80U2hzBjTPGg4cfJoN9G6D+4DY6HSGPEnZmox0TXxtvlqtpjOoeM3MZUOyb0J4q5Y4CeOYgnIWYJrYO3CgAjlrTQgPYBiYuMPMo4gpO+PAl1o2hazGJn5n81QBy18o/chE/yu1bdBhjkAKFqubWOqHSTb/NQBSbpbU

moguLfFvSZOGMmQLoOkshyZmyzgGW/+ZlvyYQlwXYC5ZkcRMBdBCkEEHQSU2SgbN6gmz5Z8ViHKKAysY6GhtU5ep0PjBhSOhrXgE0FYthk55h7YP4rLhy5Yav7HMRIG3O7n24+5n08G01T+n7Md+vIY/qg31yncjckI22JpqtyrSwa6iPMBdCIJJ8RYTDcqGvh7s2iubU6EiaI2Z9Rh2fAs+RqKOUb/VkAQNQOHvPNE+VxUNoxrwVA4HVGh49hLV

hhjFQBlyanox33TVCaLhOasY5yw4NvirTNpu0w6adM7AXTbpj016eMvYFQ6ijSQ/BJIuyHC1yEgsNJoXMLG5N4qj4e/OU1fzVNta7KvslcEdI+p9FbSYQItnrBNEJgigTgrKtrAKrCgi6jVYlkzdQp9VsgS/2VEIqZdSKzUaDznWQAF1yDKHkVowblXOBlV82RtPFn6DJZ+PG9H1aatBjJeIY+6syrphGKw5Yh5CISk1OKxmiOpuOXqfdLlFVotf

A3j4VwDutMxkpF+R+s/Dfhfw/4QCMBFAiQRoIsEcKg9DVIaq/TKqgM2qrEvBmJLz+6S1hwjNyXwjw7SI/qGPiRZSw9eOJkUV9Sob4ymoFsMPLTJQHpx2TUpcuLMtzyqNAakrHatqiUR/cuaRMiQacspluEh8KYMlglYIJMjR4qfLMFTZ1QqDg/YZTePKFjNBziVj6iOb+MiaYLhw/NZMYk1Ft+w5ad1ATcWXrZcrS599XSH2afngTEzDY2cyBgXM

OAzwKyDAGIAUxOgN4VfO3FIALAWYaiSQECCdZCAswh52E7Tlqw9AioymO+N0OaLXmsTdMN49MEcL6hioNUBWm+f+PQtVjetyZobcyAXMngrwD4D8H+DAgwQkIGEPCERDu3LjZoRaC6FqgRq2mjqjaIHdvNEm/jhiAkGSb/NosALJwmkxBZZNgXSWrd4WxAGgv0tuT8Fvk2y0FP/5nA1NsO3TZBaRNRDLNsPGzdaI3XrQSpsi/3sjGmKVe31NXiWE

FUT6hcC0JsvVHaJ3XRSAGp6xxZeucGJAmAAEAaHwDtw4AEEC/R4aDNCXQbIlwM34cg2NjobwR2GwasjOKh7USwFM9PujzOoKIMWE+MVHiCDgi2CCIqDerVVZM4j2AKuCTfgPFnzLa48Yj3MTZNnb4rYRwqrcgDOWNhONdjQJxIinQlMAtvjULbPmi2Sy0thZhMZ3bzLsrSyjW6e3LWYT3i3Kg5Spt+HHKtg/nTq8te6uhVfpt5DEaV0oHmDYFria

R/fUfp91Ykm2g/JvWEdiy9BoveihI4UpSPEkMj6gSNokcKPCeyjsaJLsgaoykZ06uXWhgV3zrJBGKy2onvUeizMFS17R+I/ar4waJu/bxLI6/ryODHijmLio7pWHqpe4jRZQYrl5nrjFh1kISdZjm3rtaeoCiHMHawmncAoIc02bwFQZBLgXQT4Gacfvv2vDYNsDRDY/varQzMNuDXEuD469E2lTCYAgkjzwPai1IfefFnqi6gA07YAy8LXLa4FT

L6D8mxZdGJU3KI3+vUFJE1CzAK0nRohymRIdidMY7zRwu02WeTtujgtvswcQHMMPArE58Y7SCnNzKi1WVx+aobyta2CrCkBI8v34dZFSrMiTRzlp+7NX3nHjrR7pLhYcLrHU6qOTOvsf8LF1Xd1xx9hEdeOInwYk+tE6ZWnrWVCT6CZRfXtanCH5igw5de1AUP978Q5i7gDJB5OuL6AUEAaDgCSBvYVkKAAleRBA3PDaqv1qJfLE1PAjUl7+w05w

7B815jQnmoJ3IipnwHCh0otU1qhqWvbQz4m2RrKW+rhiSB6kDqEbBzA4YMZDsMzTrO/VXLH4Jto+siwTsLxZzo4b5doP0OThjD64Rc4k2sObni5zh/JoefUgP51akqx9jMdpwLBtAn/t849cBJNBVg8UIC5RU2OQXdj+HA4/GtOPldWK1Xe66W7mOvXX/H15tfeK+CYnu1vvSqYH1ovPqa929hvb2G0XExeUAtvzUJf3WN8pL9xegGwAQQyQN4KI

uCABtKES5T9ip6/fBtsuzan9up1y9CPw2ozZoJs1aCROSg7Q0+kV4sCaYfH7QMfZLEM8uBJNsAkoOAz6pGgYPFXvkdrE01TbwI4ETGzeVJlIMjyKId8FYT1j2c0ODnIzfy9mv76nPZbNwgtZc8yu3WJ+6tzvIsfytLpCrfD4qwI/HVbByddgzpOWzUcfYQPolQAQNel2hCkMI11GdqLRUYzIX01yD1bug9MDy2HeyJ9tcDnIvyLiTiQMPo9yj6Sw

4+3U/JlaIDhQWE7JxQKnMwn2TGWtt8RulDgUBMAZmSYBQBgD6AZYBoUEEIGeC/AjAG+CmOWz7iQd23zLiuZWOqc9vangH3VS2Jktw2EN8l9KDqHVAnxONkdp+BnHAenQ4gcMBjVMGmLRYEHRNstmu6LPlLN3JR6i7MDDy7DlMChxYEe/VoDhE2rS2B40UNCTj2NSbWqEpFmDUPjXM7U1/2fNf63xbzOJg9m5YNPjJz4m4iNMcagg07XHDuGkR9zd

qb4PFik0hO23vspi7VfSfNk9fzMeTW+TiAJYANAKkgQRwTQAJc96ViWXb9q/ey595BHVPP9gPjy8Q37xhx+FwNHfAdQjgRXdUJpspiaIauJgGbbM0MJlcmW5XG7iZ5g/sxjjfc/YRqLasE6ee0EbGzBFE3tBKZe53ZlNbsSi+HOYvAVh9zLdjovubXVz992rbQkOuf3C/Z10Vbs6vOPsFm4IMwFxHQj+uHUlgFJOOR2zedzDIbY8kCQ8hGgNE86R

rs4bZAu1BSQH+EBB8bAwfPEiH6gCh9I/Xd+O7bn+g61E/I96iFH8XuZ2wegXQ12x4h5RXIfFdqHqayusLpY/gfoPjWOD+YCQ/Efkekn7D/J/DbKfg1an0XoYlo+4XW1hF8eska979rqp4j3m4K8qN2wscnF0Lj7ZWqSO2Tlr9V84s1uIANkTAOdFaAUAqAZTrrx2+SJdvgb3X6Db1+iUDuNPCNkPg0IRMzAq+aoPleA/TYquKIeUa0MkpqjSubPq

D9dwUw29bug1ctVUDq3tBFR8wGbZyw8bbMB5b4pYQ11e4i/8abvt7o5xa5OePf0rr75sm98eGfuRm37+57+6U3/u/vfAsqXpRCCt0cKm/HiuVUsSr5UAIwKH8rP5mIxm6OXbai4HRa/TSApSb5BQFwAwAlKB5TQC1vwDQ7fQSrHLej/ejba2/VdcaiVW7/b1pqHAfv4P55DD+1K9EMf3twn/OAp/TAWf1/QX9L/b0q/9f6hEpnHdt/IOQawV9BcR

u4LpNZCK6Huprt+B/q5RH+12L36n+A/geQX+vug+TX+jVLch3+D/jP4bgz/ov5t0K/qiAf+m/t/5y+abtLw7WhHsvbsq6vsk7A0phiV7po/YtRCOKwqtgDVur1hACUQzwCv74A3sMHSA2bbuU6ye3hvJ7du+pC76cufXty7v6/9mgBlgctDmhJMbRqvKOWXTlqxWgfSpyi1Y8CHaCDgkfjGjR+dnvK5FM8fnVj4GK0OpYbQB3kzZrC28t0oxykWG

zZqg4Xk+60OJwne6XyZfkw7nOqXo2RvubDrX4nsNXjZzfe2Er94/C/3oXTcwSjp66MUGPlsARBYTmNDRBDnH/7A8zPvLpABeoi46gBBSHEFE8uUkQE+CJAQR7K+8TgdZ5e0Yhi484ZYKk7zQQ8k1Bg02TuEq6QWYqsq1eLMEMBWQdoN7BierXvWI36nblU7CB3jL27KeYZv7yQA8GkHyIaQpNlAQOVaDaBnuW0LTCl8JcE2SGgvNiXhDOIwu0y2e

s8n6qbebclRBiu0MJHj9yWLhn5YuteMWiZm5EOaqOBvZr0a3ed4sc4PeHgTMrPeI6K96+BH3gEGvy6ygfaBBn8i34OcsQS9qoAxIGpCuUfrqCikyxIoT6zkRsHSJeicIZCj9c2APIDpQ5WqUAE4s9OCHz0G4Nj4zI5gFkgohkSAL5oA3nMQBgCkXFtKIAuOuKioghelFzh0g1OkB7g0QLCFcwH9C5QU4QPriJHAMABUgKI2AMSGOUpIfiJoA3+AC

RUhasltxvkvoPfRiAcAFhTyhx6GsBqAriD6BCgiQV8pgk4QaCG4hN6DhRQhXlDCFIhWSAKFRAiIYT7IhooeYDoh65J8BYhT2DiEXUPIQSEr0woWEC2haIeKGTclIXfSMYSEHSHXADIV1pMhRICyG8g7IWaGB06XNyH4hwPvyGChRIV6EcUdob6GSh/odSHMMcoYNRuAVDMqE1af6GqEn8moXADah8KnB4pBGyEh5jWEABNYZBvfFC56hNumCEQhR

oQm6eutUhyHwhloT2EkhdoWaCYhtIc6FsQroQmG4ihIZ6EDhPoeSFEgWYQ+hBh8oSGFz+jDOGHyhrIcwDRh1oZyFxhWFG6GJhAodTDTh3oWSGoAmYdKG9So9LmEKhBYUZpFhHiOqEGIcFOWEtu4wddTy+6bki7FBKLqUFJW5QQW5amFaAka0B0gU1DKQlUIwFEukhMb5n2K+p0BWQFMJoAywmAKKq2+vps/awclTj4YKeIgZJbpU9Tu76TBmnrfC

+otoGHaGmS8ms6JGXTEXaqglUCfAHwvOIt7ho04iRo7BFGnH6Oe0gUVA4OJYNMBnBKZE/Bl8Z1mqC5o50BsE2BjKNHgpsB8pd4+Wp8i4El+wmu4FWuXgZJorYXwaWqa27wo37Ug95qvK84XxkaYIIIQUcpAeEgHLBJ6QcHtQ0MkQf64r+psmiChOuQd5Q86zDD/4jYu/pZHORHkd5TGhLPIFLORAUW5G+UHkfT4huwLuYoABfCujICKMboKBZBWw

FZGk+tkS5GJub/k5HfIIUZZTuRW3J5HvhfsgUGIudJEr4BCKvjm7/hZimEInQ0iKBF0wXQN8a5Q1nPoxEuv3LBEtBZLhABqgzAO3BCgMADb7Fy0nvwFgaHXo75MuQwUp4Rs/brJYe+Q7sOwLQVoGjbkco4q2CCqNqsOL9Kp0PMKrEWZqxHZG7EXoG7BCrtxEmkyrqtBR4JcE2BV8h3tGqkO7CGzb9sSkHcGpqRfmbRPBpfi8FqR7wd4FV+Wkbc46

RGdHpHBBzfqEGt+EgKCD5RaANYgnS1XATydh56E9o5SNeggF862iNDjI6CUnuHQYO/rqEFIkMaPTohMMUCpwx6UfQxIxkMjzqoxb0qUgYxkeljG+AVGBFGTqjPmG6pBYLnFEQuHPnG6F0BMTZHQxpPrdzwx9kagIaIyMVTGtYaMbTHpaz2tjFckqbsVGK+vGGQHZuK9kk6j6TUDQFUeZQAa6NR9Gtk6EALAefboA0IJ0BwAFMN8Dkg7hkNG4Ro0X

J4FC7vBNFe8wwdNHiBREbhykRJqlWZrEyJl0BJmpfLmiDgheFVBEWLEYLTWeugbK6k24znsFGBMMI2D0aYrMrQ3RlgVGo6ukkHaDymw4Ds5GuTgTe7vRmaveJuBX0WJo/RGkbcT/R9rj8GvEimj96gx5kfl5bAi0ujBPQddAeRpIQDOtSQClwD6AaI64PoAPYxsiRSSxolESw3oa9NPTBSqAAABUUFC/QQiRId87NxeAPoBtxkyJ3E+AdXL3G3I/

cYPGdaw8Zf5jxqABPEqwkerPF9S6gAvHChzMYDz/+4brFEoe8UWh6c+BSMvGtxbdB3Eawm8VjDbxnaAPF+SEjqjGjx7OMfFBIp8YNTnxZyJfGioi8QrFHqoYj+G5eSVqR4qsVFnnjVBdMFVAUQ/LHJG8oRLtrgdRXDl1Em2ZthbZW2NtnbYO2kgE7Yu2btjbGDBPhmNEDBTvop4cuBETNHqexEQjZVo4TGZ4R2Aru0KaWYfAWD1K50KqCVEWREt6

dQUflHFoO9nlxGlm9mEpY2kLoA2xJMwceJGHeRoOqAXQVaDdaUQ47unEFwyYvMCfML0dd6KRflspEDGCkNHaWubBvUAhWCNO9Z/gAEEBAgQ4EFBAwQCIG+EUWWhilbSGSFp4FlxitrN79glcdl5SkSCUPqcMI+mgl3mGbPVFVQHSp8b/UDHtsD4ARsW+LOACwEIAligIEcA8AmAAaAQQxIC7QJAsIBQCXAkgEXK8Bw0Xb4CB2EUIEsJeEV/Zuxs0

VwnzR+oLIHQwetMmIVE1qpJCAO7YLVj3sa0MtCSJ+0TmYre9BAUbHRhgadEPwWUCRDUQxUEVA9ylBqnFV47qBqBKWitD0BPwF7viDsavbA2xKW5iVeIJR/RkOaMGdiapGlx8tml5xklvlVCmG8xl+53O3EOQGaGjcRrGJJ2seMD/6FoAb6H2UuPoBZJkqmSDvAOwEIBHABoIbHoRglvb740zCU7Ei2LsVUJjBsSoN6aestOVjjs8ZCODUQMWKpZN

MVUHlAs0DoJKA7OUiV0QyJq3tHHyJscadFekifBK6qWt0UYmoArNB0Bag54vn55xDwcX53e97uObl+zDkhJ/RWXh8mAxFan+4Ahrrsp5vOjobSHHofXAGH1W1gAdRMxMQRIAqpR6H+jqp02jZQcA2qSxhJBVYRqI1hLPnWENhzjk2FJReqViFqpZ9Man48ZqTjGJQH4cQElRPeuVElBqvmUHVR9hNSADCxbpdbR8zZh8zZOb4ZczsWLHsvqmQCwD

LAwAhABBDPAe+j0HKqWEf0E4RDCeilTRmKfqoDekgZ2K2giTIXi7ecwWaokpD8E0wBeQ4IpBs0VntkYzJQZHMmcRzKYokZxloCeKM098Ie5bJpKBcHsakEQHj5gFySa6WJZrh9EqRJcSl5lxtriWoAxn3g35BBvAC64vO4MegAKoK8d8hAoyhA+F+SSELlIYhSLHLKYU56CuEM6g9EGFMAEYWHou61gJuTsS1GOuShwE0DeiZarlI4jU6TSCAI6w

aAH+mjQZwFWBECecAYDrUh6V4h/YLqTSFtI4XJjxdWnnLjgb+nDJAIUAUCWcCxpEHoXS7p78QenBAR6Q9InpmXOuTnpqIC5TXphenenMhj6bTJ3YL6WRnfSn6VHo/pLyO1R+wCsEBnGIIGT2B38EGQogXpwvrBmGpg1CenBaqlJjpaIqGZ/6VAGGVhkZAN8WqJ3x7MYAGcxwAemrNhBSPhmrxTGNBkupssuEDMZFGZemAY1GV1q0ZD6aloMZz6a+

kYhH6ZwRsZOFL+nOInGawDcZMFLxkcU/GeBneIUGURkwZpAmJnwZnWj1Sx6MmRBlyZUAApkN2sabh7wuX4aVHKxiCd8l+JvyfEmXQ4afJi42eoHqAVuopGwAQpWwO0DtwzwBTDEgbEEx70JLSXbGCBDsVXIyek0Wwkqebvh0m4c8pktEh+dgSGiUQMWOeYagSya8nK0miS2nTJ9KbMmFm8yfPKU2cHHVA2kZ1mXhOglvkggpk1gS0a/UBUJnF+x8

kfs5CpBcapzFxYqa8Fy2LDp8HSpdfp8lAx66f8GvyiqWEE6Ze6R7JGZ2IWOGhSS1D4jKEXGC5rUAB1FPS3IFOM+Qua3zrpnfIyMUGGjhuIRbIfZwmd9npAv2WRT/Zh5ANBw55bFLoM+qmdalpBGmY2Gd42mVsCg5z2fBmvZUOcdSEZQuj9l/ZFSADko5GsOkD5B8CaQGpZqsRQEZZFQW3J1RAKfNARqOoK2BQR91nnZsWARNXHGxEAEcBAgG+EYC

gg8AEayIpbXg1lVi9WbHi2xzsYWkwa4Zr/aDuUgXeaSg0cMODNsHYHVAXeygSaRVYDNBMmPw/+hcFTJQwlsFjCsiTH7QAJZtRr1sTUHmAq2DbHzaJkh3pn5SRGyls7kQfOLtnXu+2aMqHZEyvckLpjyb9FSaF2f4Em+NcX8GbpAHg9nCwf2I5TGIaIAximpZFGwihZfOuFyBAliKiLMi0JPji4iCQGgDAY+IvxSsST/iehuIVgArAYC+XFiH3pvo

AVFbaeMWnnUYGeV5rZ5ZqULqlAPSDNqF5ZPiXkmiQAqJKV5v6FAA15LgPcotImAQ3mOA0QKRQPKoVFZkd5ymdFSsx0UffGoqbPk/HcxmVOCTp51gJnmQCWqbnkn8EmWFJj5xeffSAimSPFwV5VeZkDz565HXnL58oavnN5G+cTnt5LAAzlROSsbE7By0SRHL5u+hhvZHJ9UbynI2hkdk61JBwPGki5b4gsBHAFAFADtwXtA/Y1ZaKQrlMJeabVmq

5LWaMHFp4wY05TBOyQ/CJYgrPqADs7NH9SZo3KLrRFg/LJsFZ8HEWTZdpLuUokWgFUM0JFwiwH05auLljvJKY9fPNmTpkXtOnRes6fd7HZ30dHnlx1zsulVxCeQppJ5ZkTWob8C5CFH+chOalqNqQQC1LrkrAN8SfkU0lFKkAc5IgDkC8oeuSYZcWYXqmIqABIC6pn4AYUIxoKEYVPZJheFlmFriBYWb8lGeJlKSthfYVMABEE4Vf0imdRhda7hZ

4UWpGOdWGw4tYZG71h0bs/E8xBSKlqGF1GMYXo6BPCIgYhlheEVt0E0hNDRFjhYNTOFCRW4UeF69AeqJZhQRm4qx56ulkARMBVqYTAIEVzncpHxv76OE2TgqqEJ8mm+JAgLMACClZQIPORZpwGsJYO+qKU1lkFPXmIFtZnCR1m8RMwI0SF4qxMSmDi4wLmhko4+KmyNE50BUY6BWWEdGdpJ0d2kFwbubLQKG47JtDiFvuRtmI2pqqRH8pgyntlvR

YeeMqXgkeQX7WuHwR2D7u9UBEkypq6bpE3ZyeUCEESEAHLCCAQTkFkBUNMhiK0St6HBT4AliEQCkgHPHArBAuIq0BSSPdMBjv5AXKBwT0iRcIBr+yOfdh7c/nC3F6ZOUhwAvp3zqiUHkEjndiYlBqabIjcV4N6AElhAESVzcyhGSUUlIUlJT+ccALSWAYFAAyU3ogOZlETcbJWDmKUnJSMTo5kUXvnqwB+az6OOSurkWn5hdDyXol/JYvmz5YKA+

gil+JRwCElriJKWkl5JaNxUlE3AqXZc9JRuCqlKOY5EalT2RyVclcCaAUIJ/qb+GBpVUdAXYuXKrUzZZbhDaAPmVKdk6DRjcGgVaFb4oQCfAxICmk8AFAJ3lSeKue172xyufmkRKGxewntJ2xSEwNQJqkVAtgfNmq6mGHQlMBOonxrvYOqt2QUpE2SDig4O5+get58Fs2eMSHJMwXaDZoDARylDpJ4NhZ+5cwBRDKY9oLIWF+8hY8GFxzwcoUPJZ

2T4Fx5JnHCXXZtcSDEKpW6cCHYgFobgCYAX6I+nBgKlATw8AQlGUUIAnQMQIMxxiMNTrkBRWCrIiyIgAB8CvqtZCUj5b+UAV9AG+RPkIPgYVgqphY+XBFQlJ0BSSoFe/TxI35SiKoi9cEBUvl6FWBUQVPVFBVCUMFUEVwVz5YhU4VKFRwAHoToZWBvZygDeVoVpMsTkOlWFY+WMVQYabL1W2FWxVYh66uFloVsFU+UtSXFcEjsV3zr2FXl9FdBX3

lwFYJVd0r5ZRWI+csQpVflUlchV4oLFeRXgV95QRV3lAlfBUvlSFf+UUVzgGhW/lGclhWdAmlXhUZAOlURWqUCACRVCVZFchX0AxAhDk0VUOZJWEVtUkxV4lGldxW0hHFTejCVL2bxWqU/FcRWyVCFT5WiVwbizGY5GRTalZFdqQlH45F5QiFeVulZFX6V8lRFJchn5beU/lRlepXUCMlS5XWVHALZXSVDlVFUGVmlahWqVGFUZAWVVldpURV9lY

5VyVhlWBVuV1FS6HFSmXAxUiVWIcxWlVNVQFVC6LVRNVcY0le1UPltVZZXTVIxAlmfh7Rd+GRlkBYqyxJZHvElYu8BQ2ws0TYNk5o0Quc0FEJpvpgDvAYEJ0AAgsIAPEcAtvMCAKoPABwAJA7cJcAUAzwKviLFINjmkrFJBYQUBGVZa1mv67WXWWqg8QEsCK0cwLA4JlJuWOyLQBuTfAqWdUJkY25nUP2U8FMcQ8X8FJxRWiJMLZgWA9AqxOIVNk

iTM6AkQMQlOVcpUwL2LbRRybnH3BgJV3ybl65n4kJeq7H3zblUeTuz2gvSRURZZH7t8FRJaWWr6XMoSC4hUB3KcV6DF7qHA45g9HsKpBup1c9adRpvtCAUw7QJ8BkgSBOCmIpBuBoCBAmES7zjEnXhhGsJwNRQVqemuXNHa5MNU0yEmArieKCJbQF3IhqzREkzKQFWIKq0psfiOXtpU2fcULJjxQ0xI2wKRHx5QSfKYbEO7ZRUaJYCJlwg0pR4jl

ALKl7v8Uh5zNbeKs1c6dzVgl6kXzUtgRbCgb7lLwoeV7MT3DODd2ULGLy8BliRAAGgmgA/CaA3QJcAJACABRDUQ8qN0AIA0wOGDN1elpoDtgheG3XdAuAIaDEA7QOWxraBAIYRvgJhNXZgApFizk/JPRXGWYu2vgLiJifQkuVzu2TkYDFZEgBBAb4kgDsC/AAIEcDH2BBWsWllSuTqQVlQNaIHVlWxTbWdJdtZzQhxjhLaqsa9UEZ7agiTORGXRj

6j7Xo17qrkb5mk2WM5MpONaOX2Y82T57HwRUM2xBxnKXXyomGZpZ60gjNa9HrlwqYoWipGnI+4visBKLnhECqEEBq4mQKHBDA3IC3BDAF9T8wuKohnl4SGkdCuwyGEqXfJ7lGhZEln2TrieV3ZZ5ciWjU+kP8glh56Fog86i3CLHuSYQHNLfOwjaKiiNoEFhQSNvlFI3xBQ9GpI75dJFFGGlamQ/FH5XMSAEvxe/gYiKN9CmoDiNCPmo3CxGjbNI

wRrRatW+pZUYYoBplUVewsNUtVk6JlUiE/C5Q7WHDWtRPhJoCruExeKpvipDeQ0DQUAFQ00NVkHQ1WQDDT9XG1iuU0kK5JZZWWP1INRrklpf9mlAjJcQLKapsu3jkqC1cfLwB+2jYD3JLO0MNdF7R4ca2kTZAdZA0GBM2ZZYlYiCCGrJ8moFVj8s0MIKoZ+ZWKWCMWNNmjbXRQ7EWCc2czn8XeWAJTg0HZHmDYnUgdyfOl51ZcXzUBNeljCWXZsq

WGg62cdicwbm8zBcxH1J9WfUX1MJgXaxsKZszTDy6zKvJvMldicVVNFaFDDK0Z8IODR2H5gc1PyP5jNyosX+E3bpqLduSyQW7dsZid2rJpIY0sdLFyb1APJghaD2yFi+CdNOoN02JYfTanVFAzbPgYjNjhGM31Qi9iRabV6sfEmpsGCWEyTN77CaYhN9LnGnC5WZaZDvA7QI6aSAlwFZCL6cub0HLFKKQDXX1mTfhHZNWKRMG4cEwMKbQOU+OWiX

FCRjaqf1kNa0pZo43rlA3FItBA1reftdA3tNcHNPiZoLzP7ZNQDoCg1+5HKEXAz4q5c4FWJIqUdkEN4qcEmqFS6ULXaRZddw7ypAjSnnbpUgPFJI+fJX9isSZjY5q+FY0N85/80Pj63UYfrSI0BR2jaG775+jYfkml7PsY15FaQl62R6YbTaWRtgbZ3krVPqWAWZuFUWrGaQsEhrEy1F1kLgPwUWLOamG6SSE0DlGZQy1wRTLSzAGgq+ETD5iBFJ

8BAgygCJDtA/6t7A8AnLVfUjRjCWWV31pBQWnkFhEWDWIa7hJsp7yHRrrzkcgfpFjZQKtlXwqW2CSq0jOYtEHVtNUznBz00XKL017yqNpmY+5zRE0wp8j6jMCc2tUKQZSt7YB3UzNvGgX4WtM6dnVLNvkCs251T7uCXj4D8NUzNlJddPy7NCRPs2wsetpbTfNEHfCx12v5gC2UmmLJbQgtdJmC3pq4FqC1t2/iemXFAPdnC1FACLQPYCmyLfUDmg

JREe3xkw4Ke1wwohu0yXtiJq2A3tpEAkBEti9SS0ke21agns5lqAMVltbhJgbtYawTS22gB9egAQQhJXAChwCqMwBAgCwMoAywIgC4ZCAzgIZjK1dSRk19B/1c0mA1IZiMFTttZYhplgZTC6Bs2jhEWDnJxxb5DM0UDkobtOyNlu1Y1UDcHW41V8HEAMBSyR0ADgaoI0opkzzBqDhYfNog3G590W1j65k9sHmvt+cUCX0GNyfF7ftNrSdnPuqhRs

1ZWBDsB2PEh5ex3lAnHSCTxJvDhUHPskrpUSjyoKRIAhN4DasCZljbY7QswmAIQAGgsIOKW/AGtSzAUw8qLV2fAvwPoCX16nRWWadvLdp38tD9YK1W1/XlQU4pCNvAhZQswLVDmeybBaCtl+kflDRw+UI2VQ11uQ03jZkcQylyJrTRTZatE8OWhZQOwg6i687ls0arC9TIKRh4YLKdDvGZnSVB+5laHaB4O5rVF0s1HaJ+2qM8XawY81i2A6j5Qt

ls0SCq7yTs2ZdotUGmxlNUdynnWOviTA5Kt8CXDCdPAagUNtatawG4AEEJ0DfAtvMwDggCwMk3Ip8HIN3DtE7ZbX6dL9aK1xCiTJartKZ4ivLgOReDMGIIzoOWgDs9TZkzTiduXS2jO6rU7kOeIdc6AhY9eMM0dKu4ka1fFtNe4RVoz0RF2CpmdSLZ4N1rb91rN9redncNsJSLl8NG6boVuuhdOm1+t5GJuRrAm5GCH3cypZwTfOBvS1JG9JvWb0

DRMhNG26NCHljkcxj8UY1aZjqegDW9Quj+jG9nJfb0W94Sjm2KxEZa41Rl7jVAUa+avKRw+Nv1G071QMwAkY1tCCKJ2XM2AD4DKAoIPnLG8XLdmkm1uaST0NJzWeT0cJlPSEwWgy0GHg60rycFg0dlnesJ4GeJg3xe2pYNRG+1hltsF3FvBZq37tVSrmg+eD8CnHJkvetX7HJmMK80CckoO6hvdoeR93AlY5gl0qFu5VKka9YPVr3AxOvfXF6Fhd

CMCkYqAL7DpA/8YNSl6bsNgC123VBogKoqBHpkF6WeBFJZt+kvVZPaIUQo4eRROmT7tqjGDLJQygsrI3qS3znv2foB/YDDH9fWmXrn9oQJf23I1/e/F390FAFFP9B0lbqv9ITu/1m6riF/0bSnnKwoqNQsnNKWO/3PqUJVWorak5FJ+TDy79ZFMAOH9rOJHqn9XiBf2cyqALAO39FPpZSIDQFS/1ZtfjpgP5RH/YLE4U3/TNL70KkvgMADYZej3J

Z4BSypZdbOYBHpwuCQoPPsbTlRDXGBWVsAhNBPWE2se4JqUnEA+ABTBewhPY0mF96TffW6drsc/W5NWuZ2KQOMgVVgB4q3aZEN9jg8smI9ihrfDVYXBUZaOde3ZM5WWnTaDRbOHQBq5KBl3YyRj9lwRJxzuMNR55y9TNfM3RdRcRHmrNv7epEOt73k60b9CJbr1KpH2KwPfIjFaJmB9MhEDqv0+kIEiAENpVuGMAxAOZp9SIkswBr0FMCqFjQVQG

IAaUijcKINME3EiLvlbCK/7NQU9PVYiNPQ+0B9DqACSK9DAw2cCv+JYKo7eRO6Tf1FDtEsFmlDTmXAq0KlQ/co1DBjjejc+LQ20NnUnQ/62IizohMP+c/Q/lX3kB5M1BAVYwxcOTD0wxMOzDtwyaSEDE6rfHpFpA8lXkDSbeaU6ZKwz5UlDtXEH3lD/rVUNQjKKPsPG6yKM0OoArQ0WEnDIMo8Ooilw7SKyxjMXMNt09w6VVojvQ1cNTDMwzcPzD

i0CAVSDfqeH1yDq9dD1jda9RoyXWn9eFj5ZwndEQ6DiaVsDvAPAEMAwAN4D4AjExZX108txPeYPjtArW0nWD43aWl1guYM8l2gidC4Mm5owmRHtmReH/p6gPg132Dl02ft1990ZHgaJ9eUKmz3G3ubOW1RdfLPZF1phlg0WJVycpFKFS/TuWSpseWv3x5vDZv09lCmvdketd2hb14MDeZbKBtmIr4BAm9OmgAiNC5IiGoi6lQABksY+cPCOgFW8O

v+hKu7osKNJJKW0Kj5DSSjamSJGPnDMY7mPxjiY1pIZyeVXuHvDaY8npYw5lVsMIK9yEZCLD3eXqk3c/o/cjyhQY9I0hjQgGGNgiEY4o1RjzonGMJjSIkmPqVKY1UU/o7ahmOf09YzgO5jJJRqGDjhY4BUljY42WOYVk41NLTj6Y3WMhannPXCfDyQVamJV2Oe72aZmQSY2tjtWr6ABjnYzNpkx4jXnChjHVh1oDjtyEONFjn9OuMTcs413SkjU4

3wM1j/4xCM5jc43JT5jK4z0MjjpY7WNbjgEzuPATBOngL7jiiiUhNjFI+dXrV1IxD3IJOXeWzQ9nTsoOGGnNog1ekwneKQcj1hhADgg7QZMBAgxIKHDdAUALbxwA9AGSCOhUAJGCaAFAN9V59SxS/ZadYozp1Q2fbjWXl9iGrzjzAjQtDAvdprYMmMo3LLU37stoCLjaBY2bbncF3fdjXOdMDXWAdgDtUrYR2HTgM1CRENbvYdGStsZ6BemCI6Bh

q0wCV2YNAqYkP2jMXl90c1IJWkNPeqhQD1SFYdoew5WmvSLXL13RcGmFe+ygV1RCOwo2UvMwnTLBp90IAqhGAAdNdXhKQo+KP9doo+WXijw3ZKOg1BnZp4dg+Nbzj2TO9dcYytfYIZNRMokZmRaj9uTt2O5iBqdFnu8QFXx4mDNj7lRDR4qTCPG/NAHYJD2DW5NK9qQz+0+TK/a6OOtK6TkPHlW/aeXut55egCLShQ9ZWB6jgF8hPjBMqlpIijah

OMiIoIkZDUSgQIlqAQbSDcqiU8XOgpYhJEg6UwKOmmygqUcPlhQkSlwCTIiVP6EGE3Tflc4AAVt082Ob0y0ysOrThsOtPC8xoelJDju07mPwV9cEdPB6p04EjnTy/t1LE5X096B3TPVHfS4D56C9NvT+9J9PMVP07iXozx45amy6cbcaVRuppRQMiKn6kUVAz+DCDOWNy0uDNkSkM+Fl7TLUrDNiUJ073QdqOASjMEzeJRjPw6v/ZgqkSr0zFUfT

104TO/Tws+3repDKuKpUjcThH2FtlARrGw9m9RGkKmSfIKop9OQirWn2Ug2+LWmUAMoAQQMsLsAmDdWWk05Tokxinq5wrdQWaeYapaCc2VEO1h7KzafDWRGjg8sKBxzycA2bdy3k00VsgdT316TB3UonOe/qAcUCupYOEMrOVgcd514DqNMAR2z7T2ZDTXdq4GjTTo392cNq/VNOaFHo7kPb9evQUjQgijcaEVhKHEsMQA1cwG3SNdc/l4nj5M67

3qZF47jkjMaVSbE1zgba3Mh9jOUUEbVeEzEmVAcSdx10wVQXH0fERcAcXzleCcE07ARjNRMWmCwBvgwABcjsD5yCQJ8CrQ9ADeAIAncEYDeA3wLLlDtxfSO231gbA7Nq5rvgVOSTrs2LhLQxduN56JPs+U2CciTIgiG5tqnMC9sDnTpNOde7YGos9uyWDQww5EA/C3R5aIkzpOvYkGhjNbZnqBLJlHLP0K9Gap92xdtiaOY/QoJekMhJ4kfUT8q6

XXSRXZNI+FN3svHXD3a01EMCxALpXegAhNl8/W1nVkxaZDewQgNCBm23sHACGzvXZlMijrLrlOWDRadbU2DttWlAWqBNZHbnQ3KNxom5HYFlB/Ud8MmJVoLYBz3p8jTdt1qtjKf4P7B27otBYGM+B4MjyEvSF3UWQ8taCWqmC0kPz9Wasr3JeqvRNOaR5C/X7wls016PPOC08iUiNjGCKITcjGECJAi3zgEvOiOwMEuoAoS070GlLvWeNu9hjZeM

Op149FSmykS9EuxLkgwr5h9qs1QtQ9IacDQ7O8BTMBlgATbAvMLOBDsDfs687V7fAzAEIALA4IJgCtA7UVfPm1pg8JP2zQ3eItOzlBdikyjv1L77ZQpYGEyOTqGhpa4GWUDaC9iGrtDCjFmk9Il6LzTXz3NTIdblBkoqZnDCpslfRW2WL6zh+CkwVEDryz69i8NPZ1joyr1ELavVw0lzPDVIPa9Pi98INxbzpqWecmgHHaAq9klEujx3zu8vp6Xy

9WOf0vyweRVeqRcQM/Do1n8PUzAI5QMFIAKyzxAru4z8tt04K16lFRI8x0XM5XRWLW0jRS8OwlLgxdCXJJ9lhoNldOwPgXsLqtdhOi5zwN/w8AG+DeAdgNszfN2zY7ffOTtZfVIuv1Mi86DkdiPVFjRGyJiHixzM3StBs2JYPqDALOo7u16jgagJwhqUhb03Jx6fjXw01nZrsthY5y7nMOj+DdcvjTLo+4tujB5TNM6FFc/kOF0IjZoDOiYKv5yP

ls8ZoChLYoqiKPlliDavp6k2Jf5gqpVQ6u3ouIvONaI5JeEuKNNq6iJ2r1GH6tOrFIgiKurHPB6ss8Xq77o+r9VlGsBrB40Gv4icSyQPQr6Qfal45XvTo1MStqxNxRrzq66Jxr7qx8tJrbdCms3oaa4GuBIwazktJZKsxAXjzCjMdbkelHnx0c5fQnM7VtKciE35yafeCAAgnQJgDfAqEZgCr49ADwDvAhABvggQkYDLBWQjDR0tIpXSwN0iTvS2

JN6d3K9KN5NJ4E2zdsMwO2Y9A/qIt2bZOngJETA7WFVhrEMq41NDlGrVHP6jdYImyK0+DrUqtESoxEOkoJRLZaTNDRi6iVM97XVC2gxU3n7p1kXXP1Z1OC3F7TM+CyMYFzri/93iR9oA0bzm7DsFNn2K5j83odAJgRvLKfzeSaN2VJs3ZAWssJC3gtTJqBbpqeHQ4kEd/dvBZItfdrATOActGK3DybTP2y72tHYBsWgwG/XzlL7WKx1L1uK3l6H0

5wAfhS1W9oMXtmD65b7CdGYkbMJpNE5oBDAxIDeC/A3QEMDQgQIKuvn1zE1ZBwAKsJ0C59G6/LlZToi5yul9Ekzyu4cdoBMBQIgnMpCed+vCbndCeYCtDnebRnzSTiIDZ/Btp4cy03DlvfYGomLkoD51rCUW4mpfFFRLPqnFOq3Q4jTXk2NMV+CtuJHpzAPR4tXZMLZyZMbHLCxuwEiFmlYkdRQHFsmELLP/W1Y4mySZwd/zf+YUbwLZvzOUZwN/

i8gRuOGUKgkQUbhEIcgygm5d089HwYJvvlN1qTwndbHUrxs7StviQgFrUb49AFAAr+jbkWzMAN1WSAtI+mz12tu9SZ0u2zZgz0uk9Eo+JNSjgy0eu+Q/TQRzimw9YHhpKDfatBSQ/9bmh2KUwEnMK5pbCsuhbay87n6TU+nlDZQoBstCdmTUGqu960JTPZ0FodvWCBNhyycV2gNNkJ2DTdo7qvuTuCyeA/dLizcs7s+Dl0AWqCRqD3ujKQgUvR9f

RbzgUtMvYxFSrwneuszb6mxaZkgFoPgCdAJwKxZCLhBTZtm1m6yX1ZNo3RIGXbGyl2yF4F6wKRisZHN54VENTMcuQlgWyHPLLtxbKuRzYCyVhs9eYGOzTA24glirZawmqCJsB7KmxFsDxggg+1o6WWDvGlRCltKRVrfnMGrmWx8F3LWQ9NNaFTy5krJskEYKT02RxfNNIlgjjuji6aABpri6zMlj5Z6umqlyCh2uvdrWAIVLP7fOQIAHsYDrej5w

h7jQwNK1aWum/SR7nnBbqx7G4NmtQrmRXmupVhawns+cge7trB7Qg3COZIGe+HsI+qhDnsPaee5kktra1dIP5tbjerPyDvRenAOBc80XVs2Xoyn1oRam+gVJpLMNCA8AvwHnKWGAk79UF93Sxyu7rjs4/M5Nh67YPUgWZBqDqWYkV0AV2j2+FgAs0Cw0YLO9Uzz07tyu/Ksy0kDgJyo1ZRAJEfF3U+wi6MZRPFtdGMG/L0OL8Gwv0EL3k/bsx5xq

/cu4bjy56OIlYMYtNFrq46dC/oHIbiLTxKPDzq57JAsoBP+WutPHz51oUiLTDuIiI33oqIpuTNEJYKb3+c8B6gAo8yB6geYBmexgez5q+POSr47oBdQwAWa14VQHPQzAdrAcBwgeecSB83soHaBxFwYHsIdgeDSeB86KEHbTiQfUYZBxQf8HVB0UN48tB8Bj0HlwIweEgzB6wcQr8VYXtJVxe2aXwr4OE6KoinBwpU7h8B4ge+UyBy3sHaCAMIdI

hoh7geKN+B6gCSHxBxNyyHTezHvVAgh9BTKHmQKofqHC1iwdYTray435LHa6vZk76cEoskTl1lExNCzEcJ1z7Y+4y1bAvwFeDEAocACBkgdbXtsadIi9zvy5eU2dtPzjmyEwkQVaKoFVYDfA6CT4S89/N6guFkaDUpayfKZo18u6A15mfg+Ftvrgau4QmeNUPMC5QyWBGqHe62VYuMoT8EkyK2Wc1d6XJaO2luL9duxw0ZWxc07ulzoB+XM+7EB0

I0HkGQI0v7Uje4BCBAwQOgQPT8pV1Yjaj+HABZIWgE1pPcVOpJnUYMAMIBjUtCoxifLEHYZQHou2o3uR78jfsdjQjXNnsnHqQOcd30lx6I7XH2yHcf2AGsI8cXUiGeQdvHR5B8e3oXy/OS/HMI29oAncVd8Onjvw/oc0zOMmVJAnhxyRTHHn/mcfWAkJ0hnQnb5DcdwnDx57BIn4Wa8dCA7x6/SfHmJ5cDYnWSP8eqEoR+3ttrsg5Eekt089CUUt

elqMm5swnaU6pH1XSEStAQIAkAUwBoFgWsrN9eyt3zK+w/ObFZRxvvSLWjMKYbQcwatBwwik8eJVHBGg+3QwNUH1lLLXR7AYgLhi3HEyTknC8zmBRyRn7P7REIggeEu3lbuWtSx3/sZbqx5X6TTGxw8u0rTy+AevL8bs/nADBIxiNiH3Q86IJAfQ5gc7hO4QSOZnRI6vir4AFRI5MnDypCepc5GFuG4nqhAIPk5pAJYiqAu/PP40ih3BojpaUewN

CsSBw2nuZIJ1TqGb0peTdhnD4wx4d5nWZxyE5nY5wWdFn6JaWfkSbEozKCn6QLWcdIh6Q2dKCY9BNAoHzA+2eecnZ5rKh7fZ5WFpFhJ7ms45+a73OFrg58mfpn6I6Oe3nrBOOdmhk5w+f5nmI4WfFnfEkKDdaFxxWd/H1Z8udJ7dZ+udNnW562dhVh2lUPrgB5z2euIR54VGd6PW6PO4ToU3ivULavK80UtIaDDuOny8+pghNQIGn2XALMLCAb4Y

ApMAJT8+yk3EFRfQdvrFfOxT3lHUk9aAzLBxQ3wZw60YClNgibNxwkQWi52CLuy7qE1K7ukyrsHt6FhqBNmwuFR3D9/6w2Q01okUK7omKOwsepbly/qvY7hq0XNRnNfsLVlz3i/Gc79r8dRjvLoe5ZRQBIkm+QhtSPqlp8lq55kjKSBUrDL0UegCfi0yOUs5I9gbsM6WtStmlMhk+BI2CoElD526scASIhmDBRNw23R8A6pUvEmXT2WZeHayLP5d

WXqbTVoLkdl59kOXU5E5dFSoVK5dsSz2Z5dpA75ESW0yfl9dgBXD50FdOlIVxzzhXjkFiMflQugeQxXgZQXunnRe+ecl7aSxABvxemYldHoyV5VepXv0jZcZXlArDmOXMMnlftIblxTqKUxV95filhVxVciSwV8Yd3KG16uOhXDV5FeVj0V2+TtXbe840pZY86heQ90R1Ii0L2s0LhFQcZEHjJ9Q6zsC7blXWj1zbpkCxP6ARwNCBGAAIHkcMufA

dfPanR28vsnbJR/usObRp7ytaMCw1UQl4/cn7ZTLHxFUf6g+oGeLqJErNK6Y1rp70diXE8GdY09IfoxFim4uOaOlYqcxAhVod8GevBn77eHnpbqG8FavipkLCD0AAIJIChIAIFACggOwMoCfAcACxPdAvwJkKTA8F+lmeNGEAhBOJJWc4COACwBTBCALba0CkXbAGBCr4IZLgA3gmgKPvENSVpLeBJ5W3a1uLFcXlugdvwZWoWrqeRIDXSfFgSBQ

+BIFZJraPnKemE+gVxNwTn1oQSOPl/nJ7c5niIt8623gBDvGsCTt+Lqu3w5yWu+3z517d1X0d/7f+38F23Nkzw1p3MGNCbcflwrtM5+CpcdtyHeO350uHewh7t/HcJ33tx7cx3id8KenXMg3tZd7rOZ40axRK72vXqWylXwR+VSyE25OdS11G2s3sPQCfA7wAqir4QIJIAAgoIDqAUwocEYBO2kwLGkZTnO4UfjRep1ytQ3F25vu4GSkA7VG5nWA

a4u1vAEpbV9vKYsArQ+O9jdNgyDj0evr+NyJZzAeuVgiV9+ngkbEOYfEsD7sR8FRCUQkiT1P2Ko4l2bOTn+65OLHH7RjtftyG0l65qaG1cT4OHxtwhvJQU+v1aF+GzB3gtutrB2Is8Hc1tIdvfCh3MmXdhh2odWHclY4dkAIxuzYFW7yasbxHexsvgfnbp4P3XxqU2SmuUD56uokdU0df34m6TtS1d8BgkT4WZGBud3OwFW493pvjLAb4vwDFk8A

CIFqdEFo7bqfg3fS2vvOzE3fNGCdvadqClgytjMBVE4DjMcAsvbPonT4xbEFtRoh0SJegL1+9q2VQALJVBAGVbRYEj9acRM2PqeLgOIAPszRnXf7ivepfOLkDzjtGrptyaul1Zq5bc7HCZxaUwyKFC1RpAvoCJRW6EV98gEAvHpVruwuMZvRWRLcSfxH9cT8wOJPQSPgApP+OHS16lOh51d6H3VwYfZ3KJVE955OT3YV5PjV8k/YB8XHS3DzSF9i

vnXkm/rfFteXVrEt3KN9EZYGWRCn3vAafWzcc3XNzzd83At0Lci3CqGLeyPXO8veKPe61YOGn698ae/U47laD5s5UOkaM2yizqx5gf84WyrEn9UM7mPz67qMBDWpMGqrEzqAZ53w4fId5y0msedA4IKBnVgx4JyYOBR8d8NBuePsG1gvXJiG8s3gPXNUzdaXarDA+G5962bfOtYHdDhoPbNe+abmEgF9c/Xf1wDfkwVzfCa1NaJrUod1T8IQ7PGV

dl81EbKD9+aNbZG4C0tbyHVRt0baHVB0d2mHZSy9P7JrC1FbhHVQ9BJ8Lf/jZsDz+O61mlqgZxFAnG5mhpMnz3lDfPXD+KfouCg+miltdCzx04IVfE9fMWITdVn074+7mIiqLMPQAb4lwILkc7/Lcs+rFqz6vsGn6+5s8w3wy4ZN9idj1gjURNqh0AlEnhIphjL7ZsHOc9B0WA1X3/PQokudDTGbkHVnzBeubQBy+P1EQN8FkqSsdNwoW+Ptu5pc

AHahWP1E7pqy7tgHeQ9bfoAmT9E/3anEg09Pa+T8k8v++OADdd5GT7U/ZPsT8W8JPTT4U/lv8XJW+lPBJx3OJLXc8ks9zWMsm0+RrEHU91v8TxoilvTby0+uIlb+0/4enTyhfdPHjRy+Kv0kRS0eoxNcjt4XmgzsDorqPRwvhNpkO0By3X4IrfK3qt+rea32t7rf5Hwo0JPbrx28DenbkN+dsitFR/u7q7RUGi1mdnm+U284STA7WVp6gf2Dt9pj

7mYunFj26enR0x6URekHCFhZfzyc1d2ZKLRJqCmqZS8F3w7JfBR6tOCbxuUIbmhpLaJekLysfG36G6qBQwZnQi8i5yD0CaHNxQInZQAFzJi+/X/15c3Hm1zUbs9AjNJ2D9FM/RsY3m4wBS+x2VLyRs0vDdnS/YPneLg/0bLLxC1svULSQ/d2XL+Q80PTLER18vzG7AQQffLDqx8XqNfkpFALD8iY60yH7MC3wcrxdcxlV11qw9rKryEYXQWzkxYr

zRvoqcmzpkFZBVgtvL8DtA+ACS5UXRPbZsr39m4+8uzCNlK9NMOrHonccuF1++847coIUVE4EadDaLceDmZXP+i7t143Vj/WzJmAL3DD7ePp2tmU3rd7TX0RNoy5M5zalwzfLHKbxGcveju7pfZDWb9sdutvuxZHoAaiIopyys9CjP1PjgpTGN7FujUhrAByJxL23zt4gD6SnWiqUonnJ6N/geDc21+0KHX3fTcUQ70TnZ7/X+iJDfGAqgHi6431

/STfHJ8nvHg+Jypm6H54928Xnvb4CPXI7XzxJLfQFCt/ixfXw9oDfpqUwDDf23z5y7fypX6VTfh3zh6KzWKzhMRHZn1ez4rhXon0Uticxq7j4wnY0FVdzn6IqEACqAkDPAYEGBD71Pn1uvZTYN3e8Q36zza9PvzF/njv3qrnaS2gyNx2AFgOJp/VtgIianWfbbEf6+4319xl8CF3LKLjHBvvpq7jHBX8HavNgcbEdp1QL1/sXLFX2GdQvqb5kN1f

zu/pfmr4T0ZdbAkMddptIuUVYdQYOjpFwLcNbxdStqAXFWB3fhb7k8SOgQM5xt0XWvydVnlJ4BcywYVfuS3HZx0EBWlHFAfSR6SE1jCAQ9t6HslnijaJR0tuGfjGwXaUUgfq/3jt5ReaWTzr+Dqev+YBdfK38b9w8ERYXoW/S5xLqoANv/gywnDv3P6PYzvyb+u//MoVQe/tyF78ooPvweQlPVjpCvlPZ3xnce9V432/kugf6FG3IX2E8cSOllOH

+na9FLr+IAMf5NRx/VdKb+iU5v3lICnAF6n/p/5GJn9/S2fxiUu/if8pJF/Ne2PSl/66uX/V3ebZ0WouSVkEBEAcgIRMErHNMu8TeGXoOuavOwOWxNBNK5wtbAd9sQDEgFSTwDQg3sKUgb4rQKvgywCqNCDcjwHEs9L3Fr7j8lHta8VHkMtYsM54ZAiMdwkiOxwHPqBYyAA1qoOkZLnkz9QPul9bnnNlg1DDU+bMXAqUmZM1hKK4jIsHFI7NqBiJ

mh86YLTVmInoksPrg0QHmC8wHlLZCFkQ1sCG+JlACzBSwN7AjgEYBB7poAjgJ8BtzJoADQClNzYgQkQ6PO8lGKlZF6pL8W+ibtBnME8QOuD0QflH0pahd1e9ioMvSPM593MJ0HGjq80jjbceALBR7/jCk//te9sfgo9AAWs8JFvSNCfq7NnUNKYFAkV8BwDADdcox1zOizQ80B0dfXsl9kAdc85VmgDb9HqBVAp8ZTiiS8pgFG9ohpgkH4Drw4EF

QCFmk4tk3v49oXpGcgDtGcQDrGds3lbcPWjLBSKDNpOJNUNr+NyUsgXx5hAO1pMFB1cO3kSdKniScMngUCcgcUDHkBv88lu2sFAVEceHv8kBntqwIHNp57Pvhc+bmn0jAMoB2gKCAKYO3BWgCOtMfodsl9qYC6LmT0GLgetbXvEo5amHhUaimwQdkn0Q8K8xJLjDV8soXAkAd0dmfoG9/au+t1aI6gVoBUQKmPAgZyk49IhjTV+WOZ5ktipcp0qL

9f9ihtCPm8FblusdpfpsdUgY18a4j6NIDpkDOAIUDcgRVI2Kj+geeEH1iBPkCAQTUDsBiCDXEGCCZCBCDjvrvkc1l1du5hd9UGL1d/gdkCigTCD3pnCD7uHt9OCIiDHGrm0GgWKcmgRKdF3sOxWgdZ8Flqn5TPMJ06EtoClTugA8ksQBkaLCBB1EYC/qje8cflMD73vj8QAYLsxEtfAPXkOBxIvvcCwLHMOCjMA6lPT1z9gG91lsG8dksVBT3JrF

kTIghxjmcV7rrExektmQfnpgh7rn0kGaqV9UduV8ngRA8grAkCavu8Dksn4FM3rL93iMq5Dki0JLfO8ZBVL4tmvo3EJAEMhvnL6CkQTo14lrAwKZmQNYVp71erv6CSQaH0mcl09t/qD90LlqYVynPNiiHvsYlCn0EUk58PrlsAWYN0AbwO8AZYMSAcnNyDF9ryDJgTzt6LiN1GLtDd5gVX0TRtgkh9qh8aIqoxIdn400mHyxCwAqC9gUqD/ti5YS

iOO5qbrrxTguIU7oqQC0bmswi3B48X2iL9gHmL9ngVV8iPtpckgR8CYzo640gfL9K5lsAQOBlUbEIiIwVNoB9wYiJqMDOdZvi2NiMJeVryjuDWlsfEDwZgAjwQBU0cpX8ynmUCzzmiCerg38IAFuDLQtoQUcleD9wWvRbwagBjwfUCYwbO84wYoDR9NRF9qscsabMPtnrsIDmQQj8JADwBQQMwAzkHxZCLmMC2VqDcywcUcgAU/UNnlYCEbBJFe0

i2BHVJMtHmg306gmShdaHvIjuuUt3ATosczNz1FQX9to5umhS+KIVPZhEChwaECjxBhZ2nOElogckMtyhL9qvg7tbQRm8Qng18DLjm8PWoTk3QpCF8quegtwsO9bkCDknsgpCjQkpDAMCpDmBqUDU7p2907lTNE2uGD3wfJD8QopClKgKdVIS0UMVohdp3kD9GgXO9wIWS0N6nJhHnAJF2PvzlugSqQEIVmCJADeAjgO8A4ALCAeAIQAFTqa8Ttu

a8+Wpa99TvhCCfkF81HrmgQsF7M1XvxxBfk2CqIYmxPmA+pREvl0fDELRmIV2DWIYcChimUw1XH7YU6hcC5LgXBefkmwMzCn4SvoA8yvtbtQznOD4gZL91esAdEHo6DXWj8DBGn7t08D+hMjiVRsZldJrGq+lvnORgRoa5QxoZtIqcvpCmfGnd42sZDM7qZCrvgmBhoQCRRoRopHkLwdEcvFkAfh09HIeSDnIc0DR9DRYopkyMRcPd19Zs9dW9pm

Cb/p+oreK0A1AKHA6WgvczXv/8YoWYCrXvFChQRvcN0jM5IIlExKfs8xJQRBtFgSF5XUElg79IVDtJigCWfr4CRLMcDFDPIE5AtVC4PqggRwdG9JIIXUW2BpNJwdnMzQa1Ck3ozcXgadlAnuoVuocTsvgTJD0gZAc3hjehomqiBfXDcNmYf1wHob/4U7ktDDIStDsimGD6/htCWcOzC/dBrAuYWaQjoQ5CO9lv8/wvGDCloV5+9ldDdfKhpQaBV4

hHrGkr/rNsnoegAOAJoAwIDLB85MtBHrFZtuWsYC/PrFDV7oF9VHtrkA5o2AOUHMQ2iKfAQ8KhYHQHYoYYG+wTHp0dP4EVDEYfsCItlqQiwH6hZTPT1HHjVCJCk90Dio5M4yEJDHFikNyYfODXgSbdqYckCeoVsd6YeuDLVgUgntNNI9oVNDMPALI84QGCY2no1loZTMBYSZChYYYdNoW2dC4VhRgIchdgfmdDKQb3s+wMq9brjrE1JjN0kmMJ0i

sqI9WArCAAQD4p3gO9Ziwak1sIY7F/PjMC17oRC1HkfsTRvRETIj6gQ8Fmgd9hVgpQUphnYU6cfYQjDvAVftkYa8ZfUPRo+Urn5Q/Drt6mMt0HzDTZ0jFK15iE909aBcVI8LHCf9rECE4R1CxIYAcgnjTCHQenD1lKmwrQJHxj7nY8dLLJDIDtVw4AD4AeJMQB/phvwekBAiiAOcBSZiednwaiDzvm+DhYXGkgkPAioEQrNMVsdCZYTiswIedD4k

orQxtsjY5ao9113hSssilrCGdrV5iAPnIFnjLA2AO8ARHqbD8+uPCJgZPDLYQF8CIYlDtclVhcwG05Jypos0WiHgVkktAcvk6A2jJslCbK2kcbn7DuwWxDgaIDssElVAdQUP1BIr3pc0EOxgIq9tWiM/CfHrODLQY+5rQeJCdLnaC9Lr/Cwnk19djoNCIALGFsRs0ABYj/0rwkHAv0KRR0YjLFQGFhRRKApRLEItJMtOYBnKPbJcSsQAFZPtDHNB

/R/slZIWYd8hXEdgiicP2cPsI4iPys4i0/tgNquKT4PEQeRpYsjofEYjEDyP4iOAIEj9mMEjDEKEiZoVHsedO+UYkRzDxYZki4EZAikkcecq/igiKnq+CqnqScAodpCOAC4iRBjKFR6DkivEfkimBC5Q/EWwAAkZjwykWrgKkUddtoUJRIkU1c6kWLCGQgkjmkcH0pYbksQIU3CiES3CGRqGl24e5CTirowdlrw8hHia9t3tf9d3tmCEgF204QJU

Ax4TRcd1jwjp4dbDQAYJ03OposSXk2w74cosg/FMBWNJPg2es8xOwYoiSoYGo+ape14yOnN2Unl81hAP1i8JxorVNWgYEEOwwDH/MGoIYjsFhaCCPonDKYYuCv4anDaYauD10ju5I+Ca1KoEvJpgKAjkSpaVI9jehDEAPF8IJtMg2mwd6UaoRGUU9BNACyio2sXDnesGCy4aGDK4akt3wRyj0gFyjmUYxg+UVGDAfgQjYwXLCFGKvlOJOsApajHw

MEvUoOCga5hOigU3rju9dBlsBV8CzAFgLCBLgN8AeAD+IZYGBASnCfNngKHBiQANBaluwjBJjyCTAdwjfoXFChWgMtZ4bbC8srslBChmZO5BjZsJI0xrLHzlnNkpAvYR4CtJr4NioQL1g3m05ANorYI6q0RC8OMdGmNUw9aGAZHSEOw7HkiYQgfcC5Co8CYurQDeAFjt34QuCYXgOxi8J0JyPiFNm4Qq9W4SdAaQR3DrrvrRHrsJ1xio9CbkWV0r

IDeAdgN7BugBBBB2pFC73tFDaLuWDpgZWDZgT6iZFv3J60tFsMnAgCrToHhfUBW1jRg+pObIl8haEu5ugCu4DzOCj40T2C/GgCw8sgTCBWDs5nLPAgT3BExFhMoDdnM1CSYSGcyYZV8K0UnCqYem8EHiSivvLNN8of1C/FvYj4BshNjMjhkG5kBjUoq3M23id9q/kkta/iksC1hGD2BtBQPIkPMtkWEczrqBDFUcQjJTp+8VAYmJhmv01lbMJ05P

rQjdXhIAXQEMACKLCBJANoNnUQvtOEaWD3UfyC8fhYCBdoDCI1EyRk4l51oSh3dlRrn5FgYD00bLadt0Vz1d4al8mphCjA4dRDF4cpYkmFyhcAVd0aajAsOlNx8iYfMcHgTODcUfYlC5mscLEZJC5AaE9OMH+jvRgNCWvvWFeYIb1wkN84V4jaVD0HrVtDu28DIeUDOkZUCPsDZjLMWkAG4TO9dkVhj9kXSN4hsrC3CKIUAerZZhOkndSMToD0AL

8AePMtBmAJgB0poy4voebCijvWIWMf0tJFtWCQmJgYzigtABInEZOzCHhyoImw6Cnt5BwDlAdgSB894aJdWfuEI4gPewBIizRpyufDUEO312NMHEImO2AvLFOCgHuaDX4a+irQZ1DavpYj6vr1DHnLSj7EffktdN85JsRFxFoWzEhUTCsRUQhj3wTNijaiddN/oQjfMY2iDkUu855s1F4zOciqESwsdgBj9u0Qaj/hEcBngJgBoQBkcD0aOj+QeO

iXkR6irYXwibYWlAvSOqAH4MVMfbHMRkbh7UbSIghUUfRpDcmHFo0QGBfYVVjLHgfDfqCRBisXM4LzMlD4UYpjSDG+wkxGu8P9sL8esaTDjEXii30QSjdMUuDhsTL9rEUZinnC8sFfhIAfeqlErejn9w2i1JwovyigwTFF+YSlUukZvQqcQzjZUfgjRTnXc1Zqzku1iQirPq2jIYEjd7Op3cJgGn1fgEcAyQDFihABvgZYPQAKAGBAIJM4AIIDAB

H4LqiZEIliood9CJ0bhDzAeljLAfwiZFt6QoHLUotUek5xEWblbFqHx6lMpgwUZDiwPoL0yUChoqiBQ5yIod5efq6hiujtk1MQpFi0WLZcPuWiBsR/DGImN5MDFtB9MRl0KPlRsUXoRsBPlR9fmsJ8EOkC0GXvswmXlh0pPhniu7GQ9YLEp9Ktip8jbvy91Pi7itlG7i1mH+jKtqZ8G0RrN4khrQ4jkLhgeqW5KjjS12wGn1JAJ0AyQO3BlAPaAk

hJhCQblwjGsq8jp0TPDjcSeA4YKosGAvs8Q0Mq1KIRWhfUAaZUaiIlovgxCkvqHNvtrz0DFqgCjFgphLQOBFyUkkokcS1iuUoph74OBFsUXnM34SHjK0YkCiUcuCUgaSjf0WTjcJF6C3nAXo8cFEAiSnf09qNTpB8H6CKfB/jcAF/j2Bj/jbIHqMoMciDTvrBjVoXX9RURgj38X9hP8W9xxfLRJSAL/i9RlO9tkY3CnIXsjtsURMtZsci2gKN5+W

LBDNXtRA0+soB85AO1rTAkBLNvdjJ0XI9b5kxiGCWljlHt6ix8b9RUlNHBZaI0QPYVetVGJ2ACanjZ/UJX1pVtvD/SGHNN8Wl8kYTvjUNIsDWet7EVslokaaoQZZQbxiMcd1iWoc+iccdpioHgTi78UTjPgY/j1lMZjPQXYizMYrdxfHjgbJPTo7SoAwRiP78tgJYT4fEFkm1KrJv8WJRGlkAw5sbG0FscScs7t0j0AM4TukK4SbCR4T7CV5iTob

zi5BgLiRtjddCCQISFnHrwdnDW0OgERdJwBBBxct0BwQKZhrWO8B95hgI5pO0BHPvQTrNrrinscxi8IV6iMsXMCssaXhE2JzYVkgt0/keU0XuvCZ3SBRAG8Mmin1uJiX1v7C+jubgfcMZ9C8M89syI4Rn7lIx2wJ+sMDGsF+wHsVSDBdEdaDSjC0WuUA8dR81fHh9OaroSAntA9xWO5YW8bIDo8Ug9Y8cRte+NB1E8dS8MHk1tyNmJ9sWIy8aNvH

js8VBYFPnnji8S+BEWtQ83icYQhicXgo8H04h+rp9TCFMSFvFURZiZyg8Pmx0l7BSC8CQSt70fAV/iW6hjMakS/CGdjORv8IbwGBArIKrghAKMC6MdRd5HswT9cX9DqiUbi3semhUzLs9HjOmw93H9jIYZ0J+aJPgksJMlvYeIQhLndjeiTc8d8S2xE+I/Ai6gQ5xCq1jMEL2wjOl50L8Xqs/Htfj30YSiU4ffi04XTCTCc/jAQuYTvQYRIbuKTE

MpOcBNCJAJaWL9In/K5kmkPVxqRCeC1dGqSR8ucpHABkh70DqSl8t8h9SX8hDSd1tGcSiCOkWgi2cR9g7tOqT8VBaTtSfFI9SRxleeA1w1sVzjpYTzis3DXjNjHv8wgFLURklhdQ+FK0kwUdicCIsA0+lZAXAM4BoQCzAjXtCBQ4EVBu2mbZ8AN8A2AKvh57trix0eUTb3pUSDcWwSaibOi6AuWkqUisD+ikrDGjnKNdaBHg/njIC5ETmZd0fuiW

IUejlEaVh/ATGQtFsQCgWODsL4TM4dlE2BNlixcszEeJKOBRBC6mKT0dqWjNiVfjCGuwYWblsBsAKvgFgKQAz9KHBnADAAzkNgB6ADLBQ4IQALQMSAeABhCRAeIZYJOICzEW/d+HnVgymrKTv0SIhuHuR4/1nhi9TIu1ecMGhvIZoN6oOM9iQNCBWgBBBz6vBDL3sItksSs9nsbwiEoWSTgaO8YfPHetImPzVADGWB8DJ/Uw7OotmSWDiMsD2ThL

o7jt8UYFcwK+wZyZFhlaJejVnFylWND01p8MuS2oSYjbWlKT9CTKTDCSuCf0QqTxsWZjPgLhAgfPI1BKeEAfCaXC+YeXDWca5j1NCJTs2mhiRTuEccCVtja8ZKcK0BS0CoP7NDQK3iqJqiSaJjLBngMwBvgJMAKYOCAUSaUSzYa6iLYQhS3ka9jQAc1FwmDwkZiEHhyWo9tUTCmZ1Emg1ehHDCI4ortSKTIT4/I8Z5CR3UMLEoTybmcsnumhomyJ

3JmKS+jxfhTCkusnDP0Ths5ScYSeHIqTfgciUnuNCQ0ovP4aqDBRroA1pv+M5wgYG4gX8PnldKASCOBi+MMBFZJ5Stvw8pEQopobJTvKLlS26HWhCqTPRJoKVSogOVTruJVSEBtVTNZHVSQMm1pRKU6SoCV284MT28MQe+CsqUD4WqQv42qQVTzqJ1SSqeDBAwsPkOeL+QGMANTz+jVS1rNMiRqeEAxqcGSsCd5ilKdGV5YRZ8TSBS1qIGoEk+K3

jKLrpSLTFOAD9PQAhgJ8BXrlrigbg9jyyXyCWCVUT+du7EssbzkDHhwgPaiMdkbtCV4TNJM4yO5sRMbotfKRySfATvjsARqBalGi1OIVoj6mNejI4VgC4aTFSdCYQsnyWm9tmh+SvFrxSGYUI1mqZZQUQFx4Dqd1piYG+RKDm5I76FiJHuM7pD0JwJr8kxIq6KIxoEZYhAOIQo26LR8b0uZQuMM1TEFJwBMBlYBvJKix/RBEgIKO0tkkTJTsqd5Q

6abVTVtP7BmafIdWaY9gjyIRBrKtzSc8rzTPCf7ABaRwAhabyARaTbR/JMlJJaYEg9HDLTGMMKB5ab3kCCDXVWkU+CnMS+DXSdJTcZDTSWuIQB6aRNxRGDrTvDqFR5IF4gDaZzTKwMbSedPFxe6ObTtAILTAFNbTRKKLS7ac+QHaZI5naXLSJpBeheCOZRlaZLC8ESGTFKadDcCdh05Nm5DGRvJgPnnso6Cq3jBFlcjtYT2ja3LuT9yd0BDyceTz

AGeSLyVeSbyU8iCSUPjrKSPj3kYLt5gMJFbFq81SIIWAKfnesAEXzQ9aFEweiasst8f5TTopko8XC2wk+CLtmyVjDh0p9iU2Pew5av3JSDLqwzxLIiNCcTDVLtjjFmqA8y0RC9tiSTS2jOfB3mBmwo8RQtzbv5BwOhcSE7Oi90AKmTnAOmTMyZcBsybmTMAPmTCycWTmPnCYUzBotuOBW07FN1gyXvyQXPIHk1LPdspIPx848QAzjmqzcrINbxiQ

HAA8oCRceAObFbeMp0LfDJ1fITZwrms4BFoMBECHHetZgIjshXE80C4COIWemd4h6qCwWOhC9a7FcTaXoh0mYGnjgLDJ9aNg8TiHniBc8ZyweXqVs2Nl8SuWCGp8KRVhk+GtBaOnFgc0BygqUUkxPmtKxlTOGSwfiowHAXPMM4MXBTEuSsWFq0A15s9TavJwADQLbxpcSzA2FjBTF7nBSAAZWTiSUDTp2pp53jMAZbOqollNq4NjPDO4w1ECw9LN

5TEaaq116dIT+iTfd9IpaARdmWA5MTxDybv/DgsHxcAPuWgAmlykK2hHxN4YTStMcTTBsRJCv0T/D5STw4yIqRD5Aj6g5nFtAzCRE8CkCI1HAGYAT8J8cURCGsKdEoJbRJ0zkRGJSEls5i/aQETN6K0zemR0zb0F0z1sWSDoifK8VKVSCzGYFi+wGOwJWF0DgKW4y9UdcjzsegBMAJcADQAqgrIEYBZYMPSmCaPTvGZ6jfGYVMEbNUQtlnywwWDk

pZ5sosenMPU5JgC85gFGjGIevikaXEyJMf2TSoTGYgWPXg6juL0MmTaQsmbU0rVFBsT8XMQmzKlgViW+1E3kTT/9qHipflxSH8TxTqmf/Vq8Gao80ZqCqafYiRGoloyKDxIMRKiJGMAoApmWsBumagBiWRrASqeSzUAJSyPVrGkICYGDnSTX8YCfBjLzr1ciWUIASWQyyH0Myzf0JET5UZhjLqS5Dp5ksyG8TrFPOvsTrGUmSnUX5CdYRAAFUBwA

jABgIKYIrdTmTqdCSaljAaVWDaiYhpQDL6huaAwsMnPZZwHF0A10Q+ZtWDAgmzGvSfthvSEmTVjilqazLToQYxClolwWW4DyiNzQ8meij9csURlLn7i5mmsTPouGcb8TaC9MRUypIaNjx8dizp+tmhSIvizM4bm8oDoEBQkOXBBqIyzddFSzQMaeCM2ZChs2c6JGMHmyWWYMzBURJThUWtCq4dU8RGpmz9kFwRS2XTJ82aKzQyQW1WciYy1eNKzf

yULgTRuhZNQBq9gmq0AqVq3S6EV1EyQDUB24IQBKIEWVSyb9TPGT9CLmS9ikKXZSMzOjTwaJ50Q0BT9Aqan5asOV51oHLtCKcFtJCZftqsdDjuUrVgw8N6cBST6zEEJCz/WUMc6+CRAVkhRMEWe90X4fHD+saYiymTGzkqeTSjyiYSamTizk2Q0y+KSqSIALiI6WaSyoAG+RG2dmz8RNkt0nh9hoOfyz6WZkB4OcWy+UKQAkOWEtxqTBjJqVyzpq

cup3wWhyBWZhyxKFmycOXhz22RXS5mdCSFmU2iFMBgkVmPGokSUOsRgWn0YAN0BYQMQBoQEoIKut9T9tgwTHsRWSAaVWTgAewTkKdykAOk6hrLMBEM5i69YbuqA7qW8wGIoaBVQI6ypCX8yg3j2CI+Ls9KoGdZKHPyTvWTeyH2X6zcmc+y8aSfdsEHMd/cZpi+sXFT8UQlSP0WTTKmalSjMSByk2fUzw7BBy3nCI1oOfBykKo3l2ma4gSwKoxkOS

rSWmYo0guYeQQuW0zbRBFzOgFFyvaY5jeYcMypqeiDSORgjAuc8Bguc6JEuSfhkualyELnh4zqVESwyVXSe9jtiWOeYzmzAt4aduLi6CeOyyMVFiFUO0AOJuRBVNuZSOEc8jxOUSTLmYazayUcCLQLu5+5JX0gWBT8PUPEBi4JGiAOmzZtOeeyocTvjnNt2xoaXllH9mZyIWZZzoWW2YYmF7ZfcTfT1MUWjHOd+znOXjjXOdKSkqfaC42STiFIN5

y6mXizGmeTiNwRIAyDs8BPOHghDyJ5wwVBgdvnB9yvufBzfuTPEtDtzDkET7TUEVlz0EdXD0AIDytEN9yatE2tQeXRyMMT5iJWdhiqQZF8+2W4QCNGfBVQa3ieua1zIsZOwDQPKhvgAkAyQGOzAbiJyyiUuy9cfqzJOf9DpOeuzlXKH5I8BaAg0CujxysmxojMBESIMeyvmQrtYmU6z4mUojSoYDiWnKIV2PtdFsacfih2Pvtk2IC9NCU+j6biUy

UWVGzzESthCdrGyDMdJDKaWmyPWlCRMkFfwKpDZJ8uCJTvnMbyUZsRJzeQzxLeQRz2kZyyK4bWy4CbDyHEZPkdBGbzN1C2d7eWSQZmTsiLqZH0tqpPMdqtPMjuTjyTihnBHSAmSgmvhcIKeM8iGeCASGWQzQoZQzqGTwBaGTqyJ4ecyJOT4zhuRwTuUowVisV3JUah1jwHH51VBv6gnVP/cCoaJjY0Yei9OQOSBwFlAxTB3Ve2F/VDvHy45gmJFI

8Aos5yZgh/Zrn4wvB+y4NkYiH6aWjPJj+yZbIwCuojuS9yQeSjySeT+6ZeSEgNeTbyXrdRAQEk2Gqp8ruXcJQNi6AjInWj06F+SSEWP16on88w/H7ZW8XTtieSyCraPnJZivnIbwCXSaeQUd6eRUS8+UNyZ0YXy+bLIF6+PUQtlE+pHtnfBdnuZ0KmMOAy3A7jkafvCuSW7ky8ZKw/qOgZlCaQZGLNmhBwF1jb6Rpjesedz2oZKT8cbfiBLocTv6

Yi8LbqTj/OR9gBOQSBAkOuQ8WK4gBoD2hYkU6UVrhLS1aaVUKgACRO8o4SJAFQLUuLQLoKAwKa1gNAfLnNSVfvVYOBbdBHeZDyXSdDy3SYXReBTQK0/gIK9YUILmBUSVRBSPlVSrPROBajza7lVzlKTVz/MQQS66bjzEEE0I/Gq3iL3lsy26TsyIAAWUxoNCA2AMeTs+YPjfDGPT8pmuzBdi0d25E2xoEOIl4Wc8y3nsuV6NIck+bOfdWgJfc40U

3zSob0I10QxFcbN89xCj2IyUmViFoM6pO5LZMjltUwTxNfShfiry76doT1eT+1Z+ab4KYL0zPgM8BYQJMBvFM8BGOIAowIEMA4APnJNAEyDS0TIzHyX+ztecfz7uemh4TEjscwFkps0P9QmmRTiTYocAuZMKVQgESF1qbhQKcJUBGuEYUVhmvQFBa4TLpj1JSAJ8tEwA09grtUBB6KVUn+NWQrJDiVJ0FZIZhaAJ5hYEAruCsK0kPbd4uBPROJC4

geQEUDw6ducvNE+ULlAo5Kzo3skIGFxacY3lzhWFU3YOBhXaQXTFacXSYEfILxhbdxTpNMKyqQCKFhfTNW4ssLxhU7J7sCjMJoJsLyANsLarrsLuTr1YWRIPgjhSNwThTegzhc4IjcFcKURZMhbhfI4DAFNwMgAgBnhdHtXhcFFbaZ8L/zkPlEAL8LXCZTo5hYCLblCCL5JIXSlaUgi2kdILneVJTRmZQKoRVkiNZLCKeqfCLDtIiLV4siLqBasL

0RRsK1AFiL70DsLlAHsL8RdCRCRTZRiRYjBThXCLyRZcKOeNcLg7vjh7hfSKnhYAQXha9JWRR8KQnF8K3tD8KOAOm1eRWAJ+RcCKCIKCKPadUBcEfZCKuWKz0ecHy/MQStNRuYyJXNMQdEeLjX1P3DRcvgBreJgAKAO8AoAGwjeuS6iSwW6jc+YNzV2QDCtnqHVhxAt51kjuIxWMjctnPbDP6hUwtlFpzxCcMIxMb8y+ieLyrLLfACOM6oNAuQ4P

ijjCwgYCjE+vMJimU5y8Bb+zUWa94deQByPOZizyBQSyzMYDNW4qtM0gEqF70EQB7bvOBBpDcADyE7ob0EMBUQPPktELSwN0EW8qXOYAnRfRRbMmiKH0OuLgGHycKkI+MkIEToueGTEiRfDIUOYXRFxavFlxT4gJqLeKCyFuKuIDuLvtHuKDxZ5xjxYUDSAGeLsABeLQqFeL8cIxh/xUINHxaUBnxSlpZJJEE3xZWzmcZJT/hutD3eV+LmIPgwVx

X+KoRZuLcRNuKYMmiArJPuL8AFJIjxd6BIJdBLYJU+lrxYhKoRchKRKKhK09OhLXxcaL3xXZDyud3p6OfoKMeVsAhtgf9CvNWhbqfaARwE6BW8SOi7+YhCWcAqhcACfMEAKvgiGdb5ngABI+bhvh85EeTTsTmL6Mf1z/qYWLEKcWK7Xtyl3tk0w0WjTcINhgtXBtO4YFlWYsrAvDV8fDCG+X5SXWZezUzAtlBCtRBVQBGpmsaSg7QLGR99sA4HzD

+TcYb5gk2XJiRxYHj2asHiNyY4ktyY8AMjiqcFUJIBMAKHBbeJcAhgGBBwQJ8B8AK0ArIN0AWYL4kxagbcd+UXiCBTa4CNIko15N0L1DPMyZGRrF5Nm0C7qeEkiaq3iUjsqz26RAAyhWYAKhVUKahXUKLeI0Lmha0K3+Ve9LKSlj8hKwSpOTWTC+ad5v9KCwRcJ7V+CZ4QoHM6AheuRBgehHyGftkYIcTAKL2atyB+nMRoHBtAdGCFLswEwz0bvd

cqUWtEubBP1yoLPpISglL1ibm41ydPzEun+0SbowV58VOLbuXry8NicSqXvgzzmPpgVtMwBHBc4L87Cx9GGS05+0iXYvbEPVvGtgRePm0BcGacSv3KRsRPqIzALOniHiVnjpGY3deti8T5GSVt3iUoy1Pi+AwpYkw95A6pFyVHhaOvAg2pjaBHBlXxWmNXjqud2ytTI2LlmVPpdohG9W8RFClJf5D0AGfg2AACBoQDABWgNBSZpbBS5pfBSV2RZK

WeV4KSIPeZHSO04Hujs5aYHO5P1uRE3isDiPJX2UL7pW8dOW2LJMeuI60hdE3UNz8wqf2KeplKsk+iWAmoZjitCWrzRxaxS/pRkNJxc1LPOWNj5xZBzRqCRK1xWRK5wFLNORa4hNyOxKCQJ7oOJA9oUtIhQ/sPFwuznaUouL+KI5fbcT0CMMuJRtp5Gj+hw5e+QNxVHLYQcTk45aXK4ORCMLdCnL1RYvljRfjwhKNnLq5VjAHxgXKJdNhKjSjWzY

CctiMEWHLW5f+LNxRXKgwlXLbxVXo65axL8cBnK1hi3LVxW3LAxihLC5TkthJWjyg+d3t+ZYrBDpfVEgpcQCFoEBSyuq0B2dhLKVWZMAhgO3AAQDLBwQEYBFJUrKPGSrKvGV/yixRrLAYXd1kmXho+VGKYxjg31BWDd16lFo8RsqDiheURS2SX2TohVZZhTCZ0qIKEN8wHLzQpVyl+5J5ZK0p9KI2aJDNeZ/CiBd/C7uVUy5xYbzIDqNR4tNhQHC

rEVBqMgBcUEASxBe8LXlFidMgDxUgKvHK7xcTlbkP+LqBJYgKQlSERuLr8kJSwp6FbeKi5a/wvKD5w6ih4UKFaSAzSbR9ZofQrSqowqpFYFU25aVUOFaHpGMNwqOJbwr5FfwqpBRlzfabIL/aaY0iFcIrSFaIquMJQqJFdWQ5FZNUZFW3KrphoqoRYor5wpwqH0Kor7bjYrJqporTqWvK9BZ2yV6gmD04C2iEif0V05rzZD5TYyN+afKBpb8AyQB

QBwQKHBh1i4LGMQWLGefnyf+TJym2GShS8PaAFuiQT+sj7hjPEZFAUetAzZTEzt2h2lYBfH4APraRdvHArxCrjSvimURipkJtMBSdzViWdyRIfFT/pfMpgZVYjcFcHL8FciV/QJHdURDkBWgCCJRiL6A1/OYgIAFHLQloNJz4i6KAVDcLX0go5LfsTl/uWwcBlQSNhlaMqLehMqplTEsgRLMqCntlFbaYsreBmP8Y5SjytFfNjq2YtjXef3L3eRs

qHzlsrJlTsr6hnsqZlWQc3hZnTTlcsrvhViE1lR4rlZiJLvFWFMFYSoxm7tZ90jM1FFlomTB6ibD+pbYLbeN7A2ggqgFtjpTjJfiSzmW4K1ZTZTPBW/LYmLZLrLA1BvOladexDolQ7G+9gsH0IluaUqzpfH5IsHEAg8AOBOeaqtXnnVDlbIFLdlqgqc6ugr2KYQLopV/TPFkBy0qRQKwAtzJgxtNUmDvRRAytYAH+t2N5/BhL9pBYrZ8kXLxVd2N

JVRodpVYFJbGkTxn/IqqlZIaF1FYKVu5SGDblX3KeWe+C7tODMNVQtYZVTqrzHHqrFHEqrXFSqrV5UCr15ZXSDBVvK6wP4qTBQ2R2zNXgWoqsBOOV9SIsffz3UJ8AN8NwFlAH3i8Sb595peJZklaPiZOaHwbSDUdnUJkrFMDFgR2J+sIHKjVXtgjStuj8zRebpyDgVZZDRp50jIp1MwqVVBSDPM4DWrcFR+SC9xSXED8BXvz+VV0qRsT0KumKKqC

kOQriFTEUvYINRfmIgB1gGTIbUBuQ0gG+RJGtXLqAIpIoZESAMRMhKI9INRbxQINlkFPQ0CWASl1QuR+1aTFaPqtN0cNIBbuGKUCQGvQq5UTNx5VCLL1YwqjrtWAWBtKVvnP2rDFUOqsEaOqJkHRIQqLXszgPoBp1Wo1Z1UBNwBjur8eCurq5euqIcFBR0CcBq91WYr5mIeqSUNCK11a4dGMDeq25ahqJ5RidQqAqhH1VcrfCTcr/CfhLqns+qSF

a+qR1VCxx1bKBJ1b+qa9LerANaXpgNdYBQNUhqFGirBINduqmFTBrm5Qer8GEeqJhTeLxheeqUNQBUr1fbd0NeMK71VhqcNYCqtbB2z67j8lyZdPM0unPNmIvTZ6Iq3ju7vYyuokYAMpc7ZspblL8pYVLipaVLypSWSfqaJy/qThCkld/zk1aADFyW8Z+mqF5R2MsTlFgghu2OMSpWvMBOVTSqI5nSrToq6gWnAfLzgTGRUNLdFaNHdTBEepZ5TI

2CwgXEYpIGYkm1d48cUSWig8c/TSmaiyGpRK51YdgrQZVINKPmuZYvEc0oZVsAEAKpL1JZpLfgNpLdJcoB9JYZLbmFjKPhiIksrPho/GuskEZfAysEse0liW8xJ8DjKIZQbZAGV3hWgL8BYQN8ABOZG40GZYp5aBTUoFtTcOUG1rlQIjVPjJVhU2GkxUZVPyJ0PjKU8fS8cHvcTJGY8SyZQu9SHpTKKHh8TVPsVsONh0AeOJvDUzOUtVEjhZS+Co

sxEtaRrWT0BaZedqXwBlBJ8AFrqUk0Jc0CFr/8BnBdkpgZZJS2VU2LzKDBZvwTEGqjYPgyNn2BgLqoCEzYVa0BvPpprTfJ8AKYEbCdgOKUjADwB85MwBngMSBbeEYAKYMoAkkDkd4lfmLsVc/L1ZctKZOTK8SiFdEJ3Pi0jqg31laBWkh2Z5rGSUUrfNY3yy1R00f3qpZgIg+Y7FBMT9xH7NHtZTUwaNFr5ycTciDtyqrli5z/paaoBInA5lDNOK

cFUsYukCx8q6jB10aHXVLgMyqqoLgAx6gsB8ICDRYmJoBNADwBsAAaAEAO0BsABsAtIAaBsAAtBiAAbrGOHS1p6iyBOWPPUjGXzLfFb0LWObTZ5gsOz4+TQj4fpLL66gsBJAO0AN8DLL52WZq6eY/Ll2dTrcVZZLcOHaR0lXmhaPHA4PtrTBloDxxU1XJiEEPG8mxSFsrZZyT6VdPTHjPu4mOkfimYLUrJjrwAeaKAY1KQlrw2Tyr2lf7K33J2ri

cT0qTwOlTTMZByVhf4V34pZQBOfRBEEbOARlTwAgRJ0Ao5YcA8tEo4gYFhK2DiPqiik9lx9aaLoEdPqgRLPr59Z5wb6L3QV9fxKTVX4SKgVKLIRWqLR9Xpkt9ZPqd9Vsr99QvrAkEfrjqZDpT9W6qZNcCq5NaCrrqapiZWVxc8HCMk7oWQTLkdYKJ2ab5SAENqRtWNqKdVZScVePTbKYLtaPDaRyIlqBz4K2BJQYcESOMLr8wH9QfXiArT2Rvjlu

U7iE0Z00eaCL132LaoUBX7kVgTo859O3rWlWgrrliULWAtprB6rpqcpXlKCpUVKSpWVKKpVBIenmIDDbhICJxT3rA5bOLelbYjmmaog8AngBOCFwK5vnIbP0p3k2WSXChmToriOdlyVdBgiKQGv55DZILTqehivFT/q0LmCqN7JQiADb5AH1O0wF3OLjNcWGrlJRABuAqUAbwECBxZffKkscnqGeQtKDWSkrbNVMBEapnEDkpssrTm2AlogcU/cH

SDAPiyThnOAq+deuJ8OItlVXOGp4Fa8YlMbMZUbPZyw2UwbO9Yrru9VX5e9UYTJDQPre1clFw2jhznbtBR+/FkiIrsQADDfnT5JBpJX0mCKxBbSU9JEEgQEm9IvjkCYERn8pF9dBcbSW3QJ6IyUXaYlwgBHtxGtA0bD0A0N7JIQBtABLpqFKpQ0xsr9VvgdCyNZ+RkpMNDRoLQpjQhCKCkJkC/dFwQqja4gajSNw6jQ0bBRTSJmjcKK6dGFIkAlL

JOjSal70D0aQqH0a+Nd/k14iMabKAFxxjeqUpjaxlgVkegFjdoAljTjpQ9uLE1GhAiQgEWF8GLvRaTq/Q9jWfr8NRfrCNYESUShUbjjXoBqjdCKLjaxkrjVgozlK0aR8u0a1pE8a0Yq8bqgO8a9zmEAn/KJRvjV5w/jYGUATU5kgTZogQTWCbAVKsbITabJoTZsacdPCa84IibA2iGKhJe6qTDXzifFeYagIr6qVBrAhgUirRxcZ3lHDZHrSAAcz

RUEMAOANmL3GV4a8xfAbU9Yga8VSWK37mmqKsF9jb4LEx+spA5cscaMasJzzgFWvjheSUqfNStz6VRRARxM6ok+InM0jTxEUcebs8edkavHh3qFdZdyOlQHLiBUKq5UlIb/0a/iChsCNGzm0hGlrQoC9BBLTxTQoqKogBmhiDl4zRucLBGAJX6CmbGJWmaiQielRRd7TtFVDytDTDzqnoUMYKLma7jsmaKfKmbfQNBLQsqKb4XJ4rO9pKbf9Tw9O

cgM9xWGEMMZXHzgKSMQVTSqzJABBBLgBVrwQDLAkxXGqsfvqbzJWnrX5caab2r/MHVPTYmwG3r4akPVv9JdqQWOpYXKV2TvmSLyK9SjT4/DHwrQFYyHzCR8ybpcCmYIKSiIMOBE5hN4c4qaCChd7LcBb7Ll+h+iijdxS10k/iyjRIBJADeg0ACJrbkDerg2qBbkNWhrhNVu9x1O3NxRdASXeearLvu7yQLc0VwLelA4LboKuzafzp5rL0hZXeZOz

OMS72uLihAGn185BvhngPnIoAJMBLgOyN5zeMCElVTqlzYab09SEx1uiq4b4QC8sDGRx6oDT1pgHmhRko/BvNWFtN6SHUMnMViM4Ae5MYdtBe9LWqnuvjtGOli5bRh+akWUULeVXVKtebcQ/zRiyALQbzpDaMKIAHdoVIaIMKpEgSTRS4qepDNoIpOYqx5bgAkBm4SaRBYIDAFaILqLQqntCsqnxRgMWpJZQ5RTtJ70I8KXpNgAMzQjpqMLbxEkL

gBBNW3KtED5deBQAAeT4B/lfY1t+LRBmWsWZ7Qyy38a6y1oxSRUOWpy39qLWSciDy3naDRDeW7iW/kPy3QUAK395GCgMik8n55fziRW9AgxW/8VxWlgWJW5K1lm9LnXKzLlVmuQU7adK3lvOaEmK8RU5WphWWyey1YhOOWFWn3leUQQAlW+ijqKcq1/KjbS+WzX5ACKYWBW+q0HIEs2bU5q1RWtq0yiwJDxW8YVJWlK1YTTs2ywsSUcdUPlcdKkF

C9LC7ZxQqANHYNVkErtEIqtEnoARwioHbxQFlSYCfAHgBHAdoCSAdsAKoCgAKoMCAUW/vGME3VmJK3w1M8kklsYksVJKSGqpsFo41QfXLpKQBz60CjxQwNYgEGx010pYg20q102nRO9aI1D5kQ08zyHS5yx2Kd16omdpSiFHMhPdClKI9bG2MGnAVfSpdjJStinaW6D5KYKUHA9CQ2fk1qXeqtoBOTKw1oIRiLhYXDFmGEdlqdcJW2CoYDEAJTBD

AX4BfqOA0JqyGxJqiemAwzTl74hWg5fdAwFo+GoN4GdzlLVpjTEQ55187IzEU9kmtiyvWnRFWz2wwFFwIZ1TAC+83UWQDaQRCLD8qNSYGgp82YbNsAj80NlBm3I0hmttVhm8Q0Rm/LYutMoDOeUxLJQhgLYaDBpGWt7noAWEABi1Shgiz2n1zQtnZ21Fju0oun525O4Q8is0yCga16KiQBF27DK3Gsu2YE662bY261Mc2rm60DBKrydCxhC8XFGS

5W3fWy0ydtSYBggfAC4kjFXxq1WUGmjwUcWxDRz0yS5NE52qx9FzWrQAvBCbHBCCsA+lHS7slgKqIUJGqpRKYLmgXrPljz4n00NMaXVbCOBBezCcHHchznc25g35GxdLhm7LVHE+Nk9qkOXKpA8gYUW0lUi35j7MORy2YmShF01DLtDPkUCDAk0qdIMWhUb9KeWwB3ZjOqTB6UWYgMQxCsSEbQhAJ7AoKSCjZaf9DkhHO3+iImbRcRk5UMRAROSP

WH3ocSkOSB6S4iAAA++IlrOyDqIUxFHYVRIEIUmtNx0XBCctnAEgE5GGi4Px2LCQVAbtLl3odUeyZhH/VmNKE2Il/XGgoYItZROAyeUHAHbU3DtoYs0NgdxdMYG1MlZEASIXIniIJNtxraQBDqm+LIQIIHmjGgxsF908XCyBrgEwA6iGDuG5yAqyJzLZBBAOmqIHrl5AEOAvvRoYioSwoPBCewq+BXCFIssQn4KvKgJzZ0zkVvFcCL/t6JQ8xtxs

D0AIrAduDpcAedvoo0Dpj00jqyRCWhD0KM0gGKDrfIaDtfo0tOUd+UlPQODrdp2FtCchDuf4qFHAw5DvDAlDpoddDvUdaUW84LDoZpMhH+kQFU4d8TzsiIujwES/0Sd+VyEdnnBEdSewUdxcskdLVCMd4MyO0ggxj0PDuy0fTrUdrEgOV3wC0dn9vidujowloSI5OhjqLpnnC3CJAAFmPlBcAWAGsdTWl34pVXsd0TuoytMlcdNvWLlOADvCgGG8

dkgF8dxsF8AlosCdSdzUNAqJwlvcu5ZaFuqemuBCd39rVFv9uhw/9qid0jvi0zgjidbtIgdpdqSd+zAKd0TrSdCDoemSDoadOTtkobkkFmOVyKdjRrwd94NoY5TuIdG3GqdE0ECQ1DtodQFyEdjTuYdEihadIhFCRpVQ6dxEqUdV/F6dkDoWdNMh3I7MIEGIzq7oYzuidkzoC07ukUdPdCRd8zqydYQCWdKzvxdJdudCGzrfIWzuRdFglMdBzosd

xzupkFAjsd4WQcdOzqudAOWNgtzo8dDzuowTzpedqIApFqAA+dV1vFNeFvFtAesltxgpUG47BERlhvetwTVJgafW9gzwAoArOxlgRlO1tk9rYt09pXNVkv5oiflW6wEW2UQ5sgAsrWW6CyxqOTYAKa0Aqdt55r81sOOzQmu2w02uwFJ1wO2yMCw9l+QuwF99J9luOOjtBRrH4elpSpJRrftfSvsR0jpYYVIDYOjbv8kyJv6tKFr+dM1IwRrbvHou

FputkYphJ4PwCF0tpGSTNEiwXtuHNZXQrQo60Do4IWhA+OqDdT8pDdpRyNN4btaYqgWIBbYC2U+sq0YkDjEiB4ibxBiKbFJ0rTdZSopt9oBW6BUA+YILJoNkvWPggUrl1XNtLdX5vLd44owVab2rdgHKjNpRvftH2CodAXDBU+Dr9+DcwA9cACA994Ir+RA3LNfVs0NnbpI5Ohvd5YHog9hFX7dLdsHdbdrpGsfMj51hsDteWXWZ07vA4qOtYCCQ

EwAhr2YA86xa5nhp1xH/IG5VmpfltOtABfbAo4aJle2Szgp2rgyqI2UDdhFBmTd3OpjR2o28l7YvNwENRJeBUCwQ68lF1yOIXKxjxIW8uo0uoZsrdXQrjtP9O0KIqr/dhdDA9b6XvBBbM3oWntKdSmVw14lI7dkorRNenoC42nqEoh0LLpYYtk13ZrMN11JLARyL9VTrveecp07uxUDT6rQFBA+ABvAzblIA02x1NNHu8Nn/JXdD7yQNBtopS7uW

UspUz44iwX0ieu2BYLTETk9fWPN4OJbFJautl/zPLVPrN5oJnNkuh9K0YvP1psWnwyhalpLdhQrLdL9M6FultFtFNPU99brMxtZrSdHoTqtSEC5RvyBBk+wtfSIZSyiDAnmdfkRwo9MmKpmQDCtCI1GoOjvmdisj/OZPiXCMenVkYGVCorRpvQuIlU5xoCCQoIm3iI0mRmMTvGFJVMsy0s0zNsB1H+OjpB8Lx2EAg1GBk60ilVygFod2ZvfiLXqh

QWeXgyHXr/SLiCct7l21KL6SOV/Xs5dg3oXIw3vh4bZqT2k3s5d03vxmWIWy0C3ouoy3sGka3ulkW3oOd8Wj29GIgO9McpS0OOlO9/nGVdV3ofQN3ru9Rno0NlZvg92htjcGCOa9dUla9z3va9PyDe9XXt6sC13CAOpR+9//AG9+UVcogPq6ppZpB9azqm9e0n5EGf0h983qBUD2Bh9BBCskq3pTMCPrYABEG29+OGR9jt1R9jDCn+B1sx9azrO9

BjpgyaUjokmqtu97Zvl8zdoVRrdsMFBKxxhpS1KmargTFsKpPgafVwACqFIA9ACBAcABwAS7pT1YXsFBYboz1yNj9QkEXJSG0F3dv1GwSBeDfYJozEiR5rttTEIy9Z5vPdIdSTYC6P3cjpHOB9euLQ9morigeTfuJAJilx4ikKd6zfJD6M9lqvI0tVXrS1H7s6VdXuFVnGGTMTZUNA9Nk/uILCAt6SwfQAzLYOES2b9DmOgxTvOQtpnrrZ6Jtb9a

HqN9GHpN9isNlN8cie2QlqeZU7pYWJEG9d7QDt9kgFDgXbVd9PhsTV1mv1tqNtamJnSo6PKUz9dRBz8LnjFa0WwyUWlJPdUfpINZFL813nndlfSndQ/ER/l3tpQpqAsCN8wCDy4duBeiWsvxv0p/N13K/dM4oMtDXoztWcK2A0jrW9bbpbdRjpADfbsJ9VbJM9eEp79m9GADKZlADRhoUpHqoY5xjMddR3mlOgCyj4ilut9tGK+tNEyMA8xSUwmA

CJ1S/tC99Hpp1pJKY9ECzSZjHX+JVpxvabxmSw2GkB6YflTdmXudtIdSi9uvAuK+7ncs4hSqO1lnG2F6ziEA/LawwDmGy8nolJ77r5V0bOU9z9pIFhmIUg5Ks3hi5XwpuQpMxAGLMxAHpADRM3Uqhyqedr0h+YawHtuMxr/Qv8RADAKui5WwF0DiAf0DuY0MDnLuiA+yDMDU5EsDiAesDaXI79SFqI5JPurN6JrsD1EFKdBgbIORgdCkJgfaGUMg

8DwQa8DZXI7NdroHdm8owDA0yItebCtU9QQ89jFoIDjO29gGtpPq4IEdtwnPf5IXro9iNr1tEXtRt/uEZlYuBL1YBmDRqjCDQPFx98960m8J/q8lp0vJtIdVeaV7sJMU9K+Md7qb1F0X0ZaRiaVt9pfdbSoftbwKrd5fp/ddboAD6bIA9/fiJm9cG+cSwdKdqwagDPzrNVXbpy5SHsAhGwaMg/fvFZg/okl0ZOc10ttJg5PxZo7j0n9OBCqwo63b

gC/mwAnQH6Bp6CGAQwGUAVkFqwjdABAfFnIDZQZX9DHuoDgu2bMhTXuMnWE9mqXtaJb9wTiFptWitHk+ZxNuI0XgM6DpBp7B6GmD9qfnxapbmjqqzngW2aDWSDAWIB391el7hEVo6hLyFWAtO5d9oK1SUtS1GvLkDI6BdQmSqXJKnvkB6AelNisGw9sOsTE+YGUgMvRpaPACepOQdq88pAVQZIHepDuoBDZksoDy5sY9oIeUwURmWEqoJC8lUy6Y

euw7ActU0CufodN0Bl2BvOoDhB7T12SfhnwKfjCG45Pl5Slp3ExTW3NN9pyNtIajtsgYFtn7tmDCdt/djXsg51519ck+XbdcHu79bvOqe3oYD52BM9VxvoU1VIMz99UXSFbqCUGHrvwuFqLT63QGW2VkFDgsiE0AN4CMAFABDIoIHn99AApgMsEk8C7PM1tHtlD5QdX9lQfDd4SSdQWoen0ZS3ERjhBOegPUQKZeAqxeRjRD5/sktC2RnwHcko4Y

hPv9qjFo0L3QY0rTATkmQu1ozESPgL/vtDEdtpDX3R+lF3Irdi6RZDLzA+2gqvjtSLxWMgnzOJlLwuJQn2EZBMtTxO2uJle2tJle2ralFMsK2in2UZlD0UZnxLpl9QHzwexWIBYBj/0gJI0+8hgUWKBkVs4OuN9EtuHYFLTvgaNllBoes0GPADsZooa6ibAE6ACqCOAOwAJYgo2LDSer1NOtud87Fs99FfRgWMwWa1tNUjelEP5Un61iM60EeM9P

w76wH3bDZ7p51wbwkR6Rkqw1SsGDpAPcIJcDUGRbupDLSsdDCnqXD0wYUDxKN/99XrwVCwY9awRMRiw+QElXkULZwkf34okb9DxPoDD9yuqekkefI0kZDD51LDDg/v/DI/txc50Ar4EDiFDmzPpa+qIHt2ADJAUkCgAaSE1xn0OC9KEeDdcofQjCocBhlp1KISJgpqQpE0Du/rtU/QmaE2CC7kRNv1DlWI7DEluDeLNArS3tmwB5DjZVKOI0Co4m

oi5XppDEwfvtinsftsdsUDkZvdD8wZjNypLecqZOONtFGYGRMynlkyuIkp/UmVIwxvQkyq9gKdIgA3zmyjNFFKqT2nyjycpx4Pzj2hxUYgAQFXKjbAEqjMkart/gcGt/7EqNuUfqjAFQKjzUaworUfajesC6jn+rn4dnvwtWPIwSmwNlM2PIVtCYaVZ/dpompADLAvHinZEsOo9ZZNLDlmvLDwIZRtVkrmCxWInwm9gyVf2PQMdGiIj3kcI0TYpS

+lEa6DQUe98piU5siOJqVvPyaO/jT4tz7sq9r7uq9YhsKNboYBChloyjMhoChk+XfyEFoAqN3uZFgSEmVwg0wUvxzbOpiublCInYF81sp95simjH4uyC0MdtKRM3hjI0eRjWVsw86MdEyQVWctXlB19uMcmV3UYlFsAcDD6Jut5MMdKdJMcajSMewGOcMpjwWWpjRVrpjIVDxjgkoSDX+tQDoksH9yqM4A4SjpGjepw9DUS9mB8oyhNbR4A1PIMj

2zIHt9gG6ApIFBAQwHYBEEH0Ax9S1locDJASZplDh0aBDVAZOjuHGTdNnR2E0xBXeK8LKw1TFSZ3SUUwhaqGET0c4D6btj9OjArSAvyWc38vTRkxApq42wiwVDie6Qx2XKyvLYjiLOw+E/JS19AMZDLodW6Q7KBS5frkGkOslqF0Oil9UXmWISvuDVHo1jNgoHtQIAoAdUDx10IGJAgwMkA7wHBAkgCKS2AFKyocG1Ne0cXZpQbLDVsflDIIYcjB

phOeEdiT8vU2zVW9xv9K2u0YDEQMs4vOj9VEYxDdaXhD8hgtU1EWcsDbHJqXtmHkvYlIjbWJYuGSk3tsUfYj8UbyNiUbV6nlncIqQd4jGuuXMWusrq76rLtfcH11bDLeYBuuhgLSGXp/dWwAVEDEACX06AmgAWAeAHotgaM91BhCK2vuqhJnIeupMYqIt961ea3tiFDl/wj1KrNPqQwAggwng3wSd0sj+0c7jlsd1tFYbXduHHsl+u0SUT8ATkh2

O/mQ4Bu2TYDxc5UBhVEfq9jqIeej6IYHJcWo9Nnpt2EyAprVvP1GE9R3e20gdbVzofbV8gdq97IeUDHocEjkB3eAF3t/QljX0QI6qJAWLpztv4qX8DWlnombJKpTElJUR1xZKyoqIlHJ080zPocK/6Dni0CUiQA6sUEsSDFK6guz0p03ky8emrlWZrYOEiZEAUiYR4STwgRciY+OqLEUTbdA2A7NNeU6ic8w6pUWFS4t++jGVuQBid9AbsAvinNx

gSwoRfV/rhEFViaVY2OjsTPVp8DldqZjgsJZjm9EcTRYWkTrie848ic8TSoVf8PidUTGIn8To4ECT2iaVdbx1CTevxn8ESaMT0SZMTcSdBQCSbFi1iZiytibCd+vt0U4sYlNc0eY5WWtHdzNGAiQmyFD00pLjEBtYC7E1vshMD7RFsb1ZR0etjwNKmCR8CaYkTDdm5HChprRBNUWNpT4tTRpSQH29jM8ZejPYNrMa0oocDsrv94cPzw4+CWyvnmP

9dSui2mSrqOvCfXJ/NoETOlqwVF8Zy1/eukig/SXKlaXG8mgZGFmdstMKCDYd9AyMkQjHxjWwAvJNYChTJ/RhTtkO8DkBMI5RkN6jNdvQACKbydjLo2ksKdFjTjQ2xA/u72ZwfI89eIVjj7Xdl/YDDtdwat1GYMgjpviyl2ABMpbAAWAQIAtRmoDYAcKUboCQHYmzgEWTCNu7jdkd7jJYo81XNGtI+tAxt/BP44OnnY5CWAL1b1q3tJ5udN4lp8l

qNPPcM3m14jUAY0pCcK9XnhdxxeBr94pgNapBmIhqSW5VHkz5tfsuXDiPW4QPIfXDgMUGT7drgKxK3EitqhDiQod2jUyba5EAGmAlwC1ZhYZPl7cZLDWCaWTIqdDd9kfFThNz188gVhg6oZnmd9zIgO9ylWnhDEtv22y95uDW5J8E5V6TIHD8saz98agj4LbDGDDocPjToc+TMdpBjwif15//ohjxlusQclBrAkeladGWi6s2PDtJUe3ydY+W0Q2

AH64oKDsxsjUYAaUWAd9EkCAPxpmFPlu5KNghQQrafxTtVlp9bmT34kFF7TpSH7TIRKHTQQBHT3lDHT0IgnTD6CnT3EsZjXfuZj8kfRNTabnTIugXTHaYuoXaZXTY9Ez266YHTlujSAw6ZV+0FD3TXBCOF3VI2p61uODEYuSDXIb7AFLSYDjFiDVK0bAj9mKZTrATZTsIG1AcACE5GCY7j1keXdtkajTYqdOjrGigQnckApitnAcOLX4iFWCO6Z5

n49TpviNRoYng9NjFcFptbYg6QHDj5u1oGThYuLRKpDzSvjj1AORZkbKZDmCoFVuvJft3asHDDfqg5s8Wyt/nDJj5SDB54kc3oZBzEztkmv4UmYQtPMNg9skbPTFqowRsmfRj4mY2kime2A8lJru9rsY5Q/s18fZus+0eGnJRXyFDmsIQTA0p2AwEhgAsIGJAG+A8NxQdmlqGbd96GdXdM9pIilvndyZRCipuvAr55aSIzxn0iYArA4DpycYTpUL

Q0S0VED6iI7qyfof9tBrRaATQe2r/unBHEZkDVaaU9QiZSjG4bIF0Zq0DsZsLoZwxHV3cVXGUY1K5Vbw+wpWfgRdXAqziIiqzXzqZxPcp2DCHrJ97vNqz38S/GtY0wAVWcwJxhsMz4CZ4eQuISJ4pmrwo7FAj07r7hxHtFyHAHzkbADj13sFIAkyeQzYafczy/pwTx0dWTJEWWEUDln0K9M1A+90p+LuLB20Wy4QCywizZ/sCj+nIWGbbAMSzoFv

9p9sYzxiToKoUfeTn/udG3/tBjBWdETDafBTs8UFj2AziD1WcLogOexjD6GIkIOeazHLNPTmSfPTm9HBzzakhzFUhBzA2ZQDAyYddwGd2xRFsT6rbHOBCrKt14eveuKrPbgZIGeAG+EzJ9ACJ5oaeQjDGMp1GTUWlzPOjTWGe4uIdv2lofEFlX72u6s3Q5QY4nvgSIc8lgnoCjGqfpVB9rjmPtnoj5N0LTA4vfY47hJeH2cXD/CerTMwdrTr9qEz

Gnpi55FFFQvjp0QzogCW7ODBUPQ1EOEaynohuaqz3AvQAZwxcQUAF1zecH1zijTHiRuedEJueCW5ufw57fvRTnfr8DckfUznWZEaNubtzwoVREBuedYq41dz4mfdztrv6TQ2eq5EYeY5PYgwSYdjacEySFDYBt9TJPJYBbAI4BXAJ4BfAIEBsICEBQqdYtnmfC9eCYqOw9SqaYNCaO37zh2TYMcGbnTQWq7zO8eofr5wuYYTnYeoj3LDwcLqibAp

EJVst0UvdQz1RlmTmCwuiLsCMgVYz+fuLdcUYBjPNolsNqa/9+/NuIntSxcTqdIFv9OReBG0hlRtlMgd/wf+oUOf+r/3f+n/2/+s4jCVYiDxeCcQfUDoA5QazEtxPHyDsC9U5q5xPy1O+aTspkAVQFsQt8FrBmz2BCPM8DK5QrAdeSEyXUsnDL2saTGOCB8qUssCFfMgjM21WDzEZx4YkZhD3werL1QLsn1kZx2vzxt4Zpl94fe1pHQoctkom8HW

H7zaWZfAjTHKgXclssjZV5wb2p5MGUGEi9kxWS7ZgVNohkzi0pic94iVHzCCF/D6kYwDdefzjbTinpiput9Dhpsztgq/zU6x4Av+eLzjOb8NNmsF2721b5BxQhpi5Lz9dRGzY+LUZJ6iUQFV2bJtUWasshk3pBAXlygic0tDCCt0RqGiWcrNvSzWOLnzCUaCsrBtFyWecmA7AM4B7wG4BvAJW2BeaLzTDSEN2/Ppw7DVL9T9t+TAmf+TGuc9Dbzg

kcedwFO+zpLeQAghCU6cmR8jqb+tl03O5SfB0xrsiTkQZTpHAHmKC8VZC0lEXg/9r0cgAEwCW5Dz+TIuL5GnGoAWIt7O5AYjvRIv1WZIvL/FLQTXZ/zVFjzE5F/ZBr0AoswJIovZcLkClFzgAVFzotr/GotbB1rMEauAOQeVxD1FtV0JFjE4tFsqmiUbnyPpCRxVFiYvdFoJC5F611uWunKdUEovolcouVF536iUViTR5maPf6+z2XXLxoQq4XEH

3LRY6pqbNT+5U0SFge03gIYDggZ1hFS+C2uZ5WUbZigPLJnuM2xivrxkRYECRTMwoGMByUQjNCWqRmgPMsjMZYU90+xmP1BRwBycoHPVbcp2Vcpa0g3wJNiK5scXZZpKM1pvLOqe7XqmE17mABzaElXFwNrAG8ImOEJyeIoBIHkR/ALcJ6ZXpeUI30DmnMwsIB9F3krBOXfgvkB/iO6gSTVAnEFgiG42HAfOF0lyIOMloUskUeAIjxNktDq6kJFR

7ktUMXkuL5AUvoldkVVcMUvLq7EFAg4bTSl1Q2Pg3q14amAPw5v3PVPOzG7F/ZAKls5UsllUu4UX0DqliqQN5HkurUViS6lpkvCltUmGlmy1QgyUsdaM0tXFklMnBoDMQJ5z2FdSfDrJBlVCh0c0fFmiZgQUwBZimJVEe8e0Lm1CMW1UEs7ZhGyPRSV62WGm5gsFeHumgTgjsFeQsXXyNt5hqYi54T3riQ4Jl4mQKmc3EukGffYhoVPxEl781fZj

il8Z9XV/JoOV/ZorOZRj7CMa40uVaZqSFXRiqeI0PaR7OdVeig8aUSqeVhtHnR5/RP5qAAkpsIS7jTYiUvVDZiTqO1qSzlg8jzl1QhV6FcuNRtcu+UDctt0WmSYUJgCpJr3O+BzFO+5/53omicuAgqctHl2mQnl5f7HIc8sQjS8tEUa8sA5BP53llhU7l3pNKzGPNJB1nLkpkhEkQW6nT9PSz/6+MNgRmG2zZt8QhAI4AswNgDwIa7FQ20OCOAQg

DggZTqwgT4D8TJi1YQ1wXyFpG1XM5+aFlnWg09YepLasSLiIxaJE1d2GYGsj7tB9vNol2eMDki00zuDJyBq15rYGVZyLROoMlwfG0XBxiOKtOdwmgx9HqWhOPJa+kPJx7jMuh44JcywViZxrHPXUiY4KxoCOH8ojEeez63rRi0wdc+gDEgCda4ACCNBezBNAlwENbZlZN+MoiGJkKvNVYCVwHyv7FcEivhJ8KQqzAfVMqp9L0dBjvM3Z5vlxYffE

fR+jPhw8KlfFWxZOehXP/Rz82TB4+OJUn/2Xxv/0CR/7M0l1Um2aRqOh553OoiCPOBIPO7OSS8q6IT0J+AT8guZR3OG550RDIc4ZEzbA6WIMlCqq1JCFV+qth543PEjO1ZlVm0XiVKqt3HH5jdO0rMNVjCo/g0p0m5p8vssiamvltTPvlk0kFVoihFV8PN9Vzzj1FyqsmJxpajVn9LdVn8qXg6at9V6Ctd6RIPoe7va7/dahRki6Hp2hWOA4+Myb

21WMkYlMsWmPYxs3SYAlS0gBkgGFKSAKyBAgIwAcAhVDPAMkDQZhysoZ+nOLm0vMe+lnOitC22wOZYEFsBviB+eskZmB91B4fQsumwwtU2AF5VNFLDoaHtgWFhsiNhhMjJJI+A0J0gEymd1AHwK1OP0hcPEl21P2tF1B5ZTlB6VozP/hwtNCF7cSeWSpbW+8LGvV2rx3VX4AfiIwDvAUzW08iylOVruMuV/MtuVtR5M0CtKc/HoALdSUFyc19mVH

YvUAGPiv1l8Kui506LcIbKDKWKVqZQOS1Xor3Gb2R8x5+/eMcZmIGAxkv08Z10Nq5wTNUll/FjlwujzFHAIQhZGNorACvpAba7ESbPaTVyz2iHJW0F2zege1i6Ze1ncGjxX2tVXT8YVSQOs7glqvEjUOvl2sUXpJuHNLY20vomiOvL+KOtNVmOuR7f2sJ1xvZB146vTDVOvo5gzNwV+TWHa9u0BY6W0y9fiK6Vjz2p1sc0DSoEDtAa+XYABID0Ab

2Cr4cEA+IBYDEgZwCr4QnXNLNuMAlh+VS17BNoRjDNglmdr7SqXmPqXJnbiTi7c5S9rxqQx4XFD7ZkR1EuRZzvM9gpSzTdYl65sG00fFQHbj4BYS6g6L7iB/kgn3e6m011cmL5vstzKGY5+2bZQ/ZzfNbhvcM7hhPH5a/cP12LbW3EvZgoFvB4MmdAvgNotpsmXDrYFm8Ona2qUEFooCtKb/QC8zrAuqN63ivQHVX1/HmCFSn70FgHXqWdGmezM+

uOqVBlgAc0DlpM9zyBEvVQluAtQkyEns1jAPLR+qJD9S056WIUN928A1+piIW2QGyAigOQsWDeisF8mTmuoEzyxGOx4LOTe20wCGrApP1lgGWpm1l46Wn+gwuH1gckekBOJcoZbLvFCKNPdfRlRU6+1sZ8YMOFo+NcRjKtf1tT05V0cuQx9ADwgzghoAUzCnhVaaUHUqNwmqrSZ6HCjKu47jfOOxvEABxszhEbTkYFxsPi5AZT5UrgeNhcheNrqw

npn3OLV7t3u83xv+Npxv4MYJt1R4aHuN+UKeNyRPeNlSOVckFUOe6Mlc5qlMPqOoK71Tu4FgcZ7EAb4BkgO6pwpQRtiLYRv+GwXZimRaD70gjRlEWfHKLZIyNgYhNrJEzre7WhPkZ3e2UZrbwzOTZZ3dBLOCB6iEJYTMzBYy6FN66PB81NNg9lt90kl7iO5ZsItKButOcYbvNHdScqnwdj3CZ7O2wMfRAywbBGnaeWJwp2u1lI05vnNnVKe5uasY

plnFxNvYPVPY5suJtP53N81JEp0kGB8tSPd7aWOqo0fTX88xmZxfeTmeGlo61jPP382EC70YAj6SzoAboYgDFk5wCYAd2im2AQH1Nuzay165nzRb0juvBZyrdA9gDNuN1Fem0hHdf3AuqesNl6s9mqNiKulQrG1Y2D2plEEvB5KQ7z1KOWgheUXC1HT2Z18f3Dk1stOzhw+Pzhl+s6Yt+uwA1Gqwl8ksch/3XY58IGU7Ej6ImNgiwqtUBp9UODew

fACkAZrx4VrFtTw0VML1kiL4teQkNknZaMBpz27uKVYfM15jIlog3Fqg+v0t8tXhMdCyFsSZtaJP05DJC01zdFZtAxkIvJRzZupRsGP1p6xvGWoJEyJr5vnoDcupjI7h0uvcC8OsrOppUKQ8xtktuWzRM7xNRqbgXh3XSCaBQarIBvkJRWvSKHz/8YiQOaA9Dox8jAIc14VbqzThoS4x1H8VgADSQ8t+tAvRBJ2/VF5POCKdKBG3KdxAYoIBgsSp

zQbSYB2eOy/IiUdGP5O7Nvsa1ax5aZHOMamWLFtimPjW8wM8gESBsav/FsHUNv5Jlaj7hBP5RtjHQxttHRvqjdAFt4tvJt+HLqlSRoZtrvypccduacPNsOK0UCJt3X5zttGMLt9vzUc16RVtphA1thiV90Btuz0I8vNt7RPeUNXCoQTtssCCAi9t5kUXUftvESQ2BDttr2jtiygft7EriCiHMzt5HRPt9dRltn9BLt02RId3UoWltJMqZnqNvl+J

vVPddsHt/XTUYSNuAapp3W0oQZ1Zo9sWWk9sgyQMrntoiWXt0Ak3tv0JgCAtuPtiy3ztzqQVt99s5t8b2mkgLgYCetsv5P9tNtinwttpJ7QUYDtnIKyRgdnts1ylmnQdiqSwdgsLDtsa1tIMdt4doCqCxg6jod/jvPtzqQ4dldsYErZGG+qMtdsjAP82cxli7AvXzN9CtldO0Bp9duAywPjkAgH2jFxtbN050yWz1vMv6tgstdJXqY4mUIY5fd0j

xe7VyNhoeo3BEY57KQXnIhzvpQt+1t61yS2XurBDjiKNKEWuKtVQKIx7uRixagO7p18FoNtGb1v21rSuhF98l8Riv2POFpzPMNQaKGCfBHNm5sbtyjss+wJAHfUSh004q1k+O6RGyfdsSZ89ClVG3MOSNiAjDUDUYd3Tv3IQdRMAdhWGyYKSKGwu3tdijsXNhqgzXbrtvHXrvB0/rso6VQjLd5mTESMbuhrCMAga2dumdzDvjWjhjT+A7v3Sc0vQ

ey0vGe/0MvNxD1vNtbtlZzrvh/Qsq/fXbtIiRa0Y6Jbt+SavYnd+qzjd3AgXdkzvizXmM3d+bsZaYHvAFaaORlwDN2duVvnxqlMBeBLAMg8pso9bhsk8zAAUweABkgAEDMrXVvD4+euhdt+oCW/eSf1VtiRoleHCRQqDUF9pzh+3srKNsKsCVs5MDki044mM9aPZ/CxT54hxKYv7VHZhg12Fr2VF+u2spxr5O8ZzKtDl2t2RFsRPIla3lW830NTF

01UzFrJMpI9XvIB6usXVtHuOevOPErL+5/zNIyQtsykWV2rwgSaJWwgIwA3gW/m05yWuQ13MutJLzMYRwzoRYc6OwOYYmVQF2E+4cRIGtJ+ARAo5JkRk5PXZjLvBvZPhKrVoRvsefFE1301+5RqKqWPdyVdmXsq5niO1drKv8RwrNgpvKsiZ1ADgEOag8xgTvdUQIBk+a9tMIS5VXNuHmzxIvsWUEvtmdsvs9gSzuPgavvg89OtEdjJNZ1pauocu

vvKKBvszd7K3qAcvut91Lho56zvnV0lOG96MnG9/s0ImSd2udlhbOgbjly4y4DEgCCANdcnvuC93uw1kJiaBRPz18EvAg0RfuZQsiAtOcn4w7BklthoTnpdxstVKIIbnwfezzZUQvhwl7OsETMjPMViPsZz9nj84v3p9nLM/JrPsK97Ku596kvps0POr4Efs9gYsm2QPeLnDe9BGAF3Mp14kZcN0HNa5p41QDmpIwD3eJ+SJESID5AcV11AcxNha

s2l3vtWrbqtYD8vuwD4/qBIfAeoAJAclVlAfTDNAdV1lHsbymfvfk+Ikue0rDg0S05kWlVvZBq3u93b2Bg24sThQ7fsIGynty1u2rqJHExe2MpYTu3yvTuQPtsBkPuC5xn4GhoT02yssyA7eklay3sW6NyXoY23qaMdNPuaV2XuO16VsiJ9KPBt8FNkHd5vH0L7sbdi+h1ZqGRF/TdU5twaQ8AKSQg5y3MF9xwdhtyBEuDg9udO9378OyvsYiXEQ

+D9vtopx5ve50gc990jvomhwefd8NucAVwffxRf4RDgzvRD3we6Zpu1T92ztSmo3vcDlQb0aTA1o3SFvoq4Qem+ZZ3lZMCA/MD6FIR53uBdiNMy1kLsyDstINCZTCb2SsydE0VYD9G6xB9xmhL2wZvOnCiNc97GtNl917kRZGxhDZ7P0U/G3nwWOM/9sflJa6XsWDjPsbN4AfhF4cu2DvPsQDygcFiIslFvVxDks9nBUDnAdwDvySVvfweQDk4er

4M4elsy4fQDjSW4Dh6StvAjvPljOuxNsgfJDsZnHD5UpPD90svD5FtvDmgfwDyd76Z9gf/Nzgdn8soeJieMXFTCmuQZtzsih2oesBegDVa0EAAcKdaSDqe279zDM7FS91F1CLBo3eoxJmH2y7PS/vB9/mg39ijMDE9cTJmLwbMqh/Y3Jg1M65XRE4Ic4FFN6fNxx3/sbDtKtmN380WNykuD67QOQcsg4jAf/hjxKAfAj54dZIjDulthdvKlMfuBI

PwcNzaUcMCOUePDxUcjcIftlttUeRD8fu6ZmHPzV55v/D15spD2eIyjzAd6j0EdKjq7uzdrjDGjvDsajgoeT92CsG9koez9xEd/k7ZRGcp5P0pzoAt0/Hv38sCBu0bAChwO8AJYxPWtDkekl5kEudD3FuyDh1D2wmszDHesBhGx9o0jkYch9hkfDNpkf99RaBlTTTmjHU+0y55Oq3GKfHmDrS2WDsv1O1iIsu1pUk2NotleE25AXD8EcKj0EeWVA

0CE+Mg4VaMLiNXQAS8AYkaWVaYb9j1ESTAWIdh1j7ANsnhhAMMEfyj04e9j7lIDj2eJ+jEcfYeMcfTDCcfrj6cezjtOsweq0uvdq0fvd3v2KNewnLjh0fQUPscbjniUMMZyKjjx8p7j4kZTju8xHjwofej6fu+jrgeU7b2xrRDjmavToD2V8MdOG2+UswfABWQDloYjp3t9cxMd0VioPl5z3vCmBpQgsANCxupsFRMvMdqD+kePR+hNTDtRulQvF

yMy4FFB9ysde4loTkGQM1v+4M2cR5XOADgcsgyvYeK9lscZU+xGpDk5sddjbsNyp2nrxL+LBAA9AuaD0cA82eKBDnicuUEnj8Tz+JdxCnJFF6HPfD+Icvly0dJD60cyZ8SdpD4IdSTtOU+OSCiyTsvKHF0SfI92ZmSx6Mt+j6U4hwomqvFnAis7NPrMAFmCwUIlBLgAkfu+1jFU9stKXumU7Ph+owxdoYphaomp4TsYfs9zwFaDhss6D6MgJ8F8x

CbWKucj+KtDB9Nj/zPePvmir2pVxwuMT0kuq56wfbNsAeu1tseQD6Wkgj6ChdjlcdFT1xCWVeA6VcBnTORGwkjdwDDTei6itATwcTtzUeFsgqc8gMqc3jnsd3jw5VbjmqfzWlHPizBqf0UH1YGdxSdPdwjunj1TPnjjrP1sygeFT54clT28flT3qdtjRq61T7AbDT0KijTrwcT9mz02d1Ht/jhEcLRxOZaBYCfBNK2xp9KsDEgFsCkAc6CuT6Gvu

Trod1gdZI+eY4IKGa1l+Ts+u4Tq/vBTkKsTD2/sR9+/sGjAHGVqk2uJZrkcRUqGrpzaENGN8tMmNytOM18xtNj/YdK93KtHDz8b4kVfDXjkqcLT0Ef9j1acDGwASBIV8eqMd8fOiGcetTwEeYzi5DYzxcedjzAd4z6CgEzwcc3cYme7jsmeTjimdHj80dPN3CUzTxKK8swcZYznGeMzjqfPDlmebjtmfYeEmfjj8meHjvaehig6ccDn5LSbTwByf

OkbBjhWMC8lWyaxSFvqx9uu2CqyCtABSiOmBUrMAd4BHAboBgQP4Mcp94BWQb4CKyqeu6ml3s2R5MfSD1MdlpZbqUJxqCfMPFziI3iJagV9h5qmHVh9wid39iKe9CspiOqYNBUcdpQ+5LGwVDhlXk/Bzv3uxBpws1YfGNtKemNjKdM12AGf3P6fr5kXJyMk7WF40Q04FtzokfTBmBxA+lV4/As8mZZLdCPLJ/zSNGpsvAtnankwubRTDubPJRbOP

3u8vRBudzgHE1+sXCM0bEN+QOucdzgV6oGHtg2Fx1S6eJ4wssAhvqfJhkg0KLAKjAZLpMSeeDz//DwCm0DisM7NtBu8NTz2AgD9ATjoWWIxekOlNMsZecvgBPjlmeogEOe/aRTD7VF2ZJJdYfpzem2+f1AIOE8JEcAJyV5oXucV5vz+QIA9T+cCRb+d6fMiLI2E+msaI7qSmEBfI2PGyK2L+f1z//BeTqojqJTDYaBVD5YN1doh+SZp1YZtjTASB

dgAdMcNGImpNmAvVLAHCz4Lxgp8ceo7T4BLzlzm8OgCzKBagHcQZODgq0Ltu59seYQKGEXakLxphdl5WgImfWjLOPBe8LwheMLwRdoL4VhJokeSa7GU71+4exudNIz0RdSy9ZYiwsLh8NFAfDjT9Xbyg0Wjx3mj7VqLxeN1HMcRImIRczLULxitZsxOvSUxmLp0AWLrRdCLkLB4OTeEdYXRhhpDjZOLjRdryfLLaL9lgNzy0AODCfFf3TnmAkqUy

z2fxeWLkz5yLigvgsifEn21VyPZsV4UNvxfQIAJdWLhJf1AfwErD/mrG7NnvivTJcuLwJdCL31BLErlCqWYiATzjJfnR5xeaL8pe5LvRf3mZqIkvVtiR4AQemLhpexL1xctLsAC0aK4OG7SAWTNOHYlL3pdZLuJdBLoewoWF3Gea6GAwOHKAjgiZdeDW01nPALYGgUhedNW/NNlKQqCkeQKOL2yVLJVph3NSvpbLgZfs/YPuySsVgHsupdSmNZfP

Ss5fPwbZc8cB9ZBxUYQfMqJcmeBStEWU4ovLy5fkt3COYGytCo1I5ePL05d85c5ekLqSsM2exRpGYCLgr35cbL6FcDLuLC9CdOYBefFrBT1ZfIr55cDgGFdpq3sS72FRZOgdJcPLvFdQrgFcnzl8CHBK4r60b2pUpLef1LiFd/LzZekLzsXvMRZy85clc/Lk5dsr1Fc0r+oDDiDsnccKelTEe5fqge/PpQ2FGrMUhcBxKPA8115PkNkexWgL3ZR4

WVcWgeVfgskLy6gBLA6sKJdSr9VfjeXPxyrgZcUeNVcAdALx0RimvivI1eEmDVemrrVfmryBBkQBqBLlWJghsj7X2r8cS6eHP0CMoVfYtVzU1MXYTGjT5iGtYeyAbQ3YQGOwKINCYCkL/iI4md4zR8TyzQIZh47eUxIVtN6Xxr81ddz35H0RZ1C82dNeI7TNexryswL1HRdINoEniN6vCr54V6Lz/eAZrmNe42ctcJr+mhtCEYlVMINCC/cV5Rr/

lTD1FtfasNtd744iD1EGXrBxPQy9rptcDr7NcVr4JcA66dx959phEHeybDJ0jp9r0teDrnNeBroEldiSTjiV2jylTYtfRrmddxrudezLl8AjJbKD6+WcwpYB8zHr/tdZrs9cJrrtjJu2mwINNV4Przdezrl9fkdafAKGJPp7uBtcbr5tc/r81df6T4ycaBExdr4DfTrp9etr8DebKEyKUJ+yYzdL9egb59fmri9qzLdRGeEA1qwbktcYbhDc7riY

j0dCBy42BLCRxjjYgb09fEbneewEXoTo0oNlImPLHob2jdDr81db3QkwsXSVZPPNjfwbjjckboOEkcNYjKQF1SGNqdeEb9jfbr+jeXrrLuy0MeMekZleNrqTcCbmTeVrzueNMDrDNsTrG3wW4PrruDdlrwTeyb4wjLdd1APdULzAo912Sbk9dqb89cUPQQomqTuTHwHthvkmzeProzfqb+dcMb4NSX2xYQGtWYn8bzzf2bnAtJiSGrJKPDTvMR1R

Bbrdchbm8PKQGeyZxQPATALnUxbsDckb7i7nA2Uw+oZsAEb2zfBbhNeX+srGrBBYRubihs0buzeFbtNUiE3oTQIPmppbzDcZbzZTzZW9FuvHRgNbujcabgHWHBLMhscr15niDrfGbrrcMboQNxqfRmuS/VPub79eNbkzfYtbCk02QKXymKJi5CqbdEbobfeby9fzxpSBiL6muYGFVcVbgrcDL21RA7A+WxvN16QJj7UHb2LekL7XgagczcPrPYpb

w6jeGb67dHbx1Cw1d9i8pLNCTr8rcvb9LezbsAC68ABHbiFmhg0Ype/b1TeHbndfz4+2FzEjrFzEKJdXb/7fDb2h6kwO7c9CYiHsByNd/bmbco7+oDRfP1CVoVuevsxHc47zrcbb/Hew4ompJbGv1QFwbdebi9eU7gHG7CB9Y5ofBz07uLe6LwHdm5RyblQDoykQqJdZQJsrJ29ph7KciA3bndzubYgFQwLjSSmIXeUceNSi72BALACXfLJYY5ay

l7oDsZTfy78zp6JD2rK7iXe+oSphxaqphJxclc67kXf6760g3bre7bbmQJG7Kpj3L1vmaxHZa72EuB1bI7dBwrZTDNAF53Uzskfa53cvaxYR9pD3fQ70kf2nZEzrMJZdy7mdxB7t3fTHTndVrxiLSmRqK68MPx+c4eyB7kI3x73pI3b/wFZkeyZa+BYQvz0jq9pc8wMLKD5hqZ6gA7ogsqh3WIEpKJdl72rAV7nVhV7mZcUPAXk+baPibxqtKN71

QLN7nKCt7x7c3bxaIY21oT1EPEzVbFUD97sVrmsx5nV7vHdFAcjhc0ZoRh+lpvkr8FmrEQ4oSRb14j7gHGCIuYL77ZMSSmTffJYNsA77+NQj78JiTlafqCIhOQ/bnJJc0M/ebQEvCX7o7fwLJD6et3aXWsk/dP78ddD1fWhVoG7edi0Ib+m7OKYbX/drRf/cX7oA/v7hbK0Rj1d9hyA9b78/ev72A/Q7ycnK2APBBV2UGSmBojJ29+UNQPUA3b9m

UdEwgyZQY3d4H6ODFp11BEH+hs177Ck68LwYekRLBIV4ez4Hmg/Aoqvj0HxfeA7vAxW5PnKVmHtcUNjg9U7Lg+wwEg/uzKJlj2VpRUH3NNiHgKbEHo7c2PU+kzdM5Iqr0Q/VocQ9KHndciJDso9sa6KEWOQ8EH2g/cH0hdZWO7ciJBvAB5LWfivTQ+EHsw8DLuxR+odyxyYlo5M0Yw+cHxQ88HindFAIg6NCd6XR4fpoSLkQ/UHhQ90H8w/00C9Z

vMqVYzNzw/hHxw+6H3MAwLUiHj4daCsZuw9hHrQ/eHyI9Y2ZKFB4Tezms+I/ZHiI9OH/GrJiKLAHswiwP7+w+mHiQ9lHvsFoLYvDh2fRnFHhw/1H3Q8Qb7LYaBdw8Nr2o/aHnw+M7vw9m5NDTctswU+2No91HnQ8A7ypiG1lZjM0Rsrtb9g9ZH9o/TH3g9iRVQJqWVDS0pgbfLH+Q8lHxI8zH4SIZzevgPGPYper0jr9HnI9OHyIyc85aBeVh9YH

FSY8DH8w/JmXNNisS3x9Oe5dXH0o+6H8VoRL6cmOkWN2ZH/Y+rHwY8UPF7oEcJo6dCLAz2KZ4/XHv4+Rum/3UpIPDimeE+/HmY8enRcr+4WBDM69E+HH9Y+tgRrt4OHL6Se/E8dHzE9746ik80aqDZock9rH3w9gAA1qG18sUoV3pLkrn48Enxk8GeUdxHdHmiLLhQz0n8E84Fk9HekCbzxqRiLkrrsQBNROYpsU5cXL3Q/PbPJS6MQkw5+KU/k1

fZPA9boTUrmY9SVx0hXFJsjyGKJdOtleSjJxdE4Mpw+AOPljnmNoS0740+hfU08U1c08q7y08UcbNAxkKPDJQqJcLDICPaeC6C9zwlqWny0Ag7Kjrmmp+CwfLBuLQX08YWYFic2QM+6HqvpoGn1CKQQToqrlzbJsIOJNEA6oM7iE90rkzpRYSCJPanCxxAbDRE1aYAc0fDTt7kU9wwAeM1TeoPm7Ys/B+riv8qCBzmHoQNF1fk9sfHCyNsADpxCc

gFxkANczHhsDNsUXCAoqlXdn7j3iJS3w9NAc9tno3d6b0Nf7Ehtftrj1BxagNDo3RUxOH4cTGTFpjahzTk4WEojJbtc8fMQNDmHzUBoU+NRyBCf2kdQ9qfzQ/lomKVZVnm8N7FRYGi95zYzHXtlYNgVYwIe8+xr+Je6HpvqMk4uzM6i49fn9HeV9L2Z/np89c72UG+4QBMw1Q/kHn8C+CsGsy42f88zHutKFgOmrI2MpbLn788QX1C+Pns8/Bnuz

nhYYV6wzsC9coAi8PnmY5nnsiLP+vYq1MqjpIXqi8oXmi/oX9Y82PR66MFS8/jLihu3nn8+QXtC/QXqteYGfAxquApVmF0C/8X/C9sXqC+kLsS94uCDa68GfB4X5C+/n4S8KX69meva+u3okd03n2S8aXoi8DL8SLlYKiLN7sHZT7gS/UX+S8mX8tJ+S1DRxCRogP76y9yXzS92XvsGzLKYiUOC0AsXu89CX4y87rwOLxYddHN4+OfD2Vy9GX2i8

eXkK+M0MK89wiK82kLcSR8U0+35iEmMn4K82m2Ocmr5TcCW1pSh+VJnvMRPdCmV1cxzli45XnCyJzpZLJzoq/1bWiAIFm4lIF8T5tbB8udbPcDdbaWF9bXuh3QOQZqz2TYQQ0bM8Dkl6l4TzWQtse2Yj0XKdAduB5INiZY9BIAQQbGcwATABDATADewG8DO6vqXg19bOuztDPuzokcGt7hJh2KXnWsjP3SNk8D2WW0gpYFPxlY3mvjDlENhT3WvA

z7px8rvLI3WAD4XbzkdHw6ssp8G6x/8i+n/PYYd1jrvV2p44LbRHZxFzrQolznAsIN3g/MsJGXGjWsM5oUiB1KbZdkpbBCUOUXoR8BBdXmhL7+4QKVnPdK9DHoEkLotIXDNUI3v7UjqLQBG8XrJG8E3m7dkoW+HFwEYk7iB/dU3upQ03/G/DyQm8UPIOE9NYeToGcdg4rihts33G8Ra5G+nQIRefYv56p+KA+pKbG/U3vG8DsLm8wrs4pG7Z+Cea

3YSs3nG+I3zm8o3gZfYUtGyEGbpJ95j6/AL7W8c3pW963kjc/vYFiHJcpjKQTpuvz82+K38W/c30Lf41UZKy0MwsOTe5ci3nW+W3iW9Yb2MhnwHPwekZLAqrv28W3128JrxFF1Bc4F5ZNW/y39m8u3um+cbpK/tKNaLkcEXa+3529i31O8kbthdhMBedtOacOU33O+035W/mr/DheVohNeR/opJ30W8V3q28A7zzojiYPtFwVUDD1LW8K3vO+V3g

u+ct2pq9b33wNsBu/+36O/mr6bwzdCJj8qJo5FNs2893pu+B3kjeA7FI9UpKknXz+e/J33u/N33g+c8ni7STd4zAo02/C38u+63pe8t37zyWqfNj1q0ZK0L9pRD9L7F2S3KAJrgrv8sNBarEFRZJzCZci4ailBS8Yml4Qc+730vgRYHhm35id2Gr1BvPMevAvdVJQKnmvfaX7aKvJBqAR2dNffvIUi2qCy+LAem+I1av0LdPnKyS1B/HLAPDrMO9

ZYPo7fTuRYRtKAVhXmbHdoP4h/zdZogun6HddsJBk60Q/maPbXdkTzFFsjtpybn5h9Y2Z/1nmYzzM1mPdCW9UG5sKUGh7mvcXtBNPsfeoimqUR+BT4og03YZrFXgV6ukKlHRGYiAtEcHfT76hsdYqfBomN283h8+B+oHYSvba7W6P4M85+Ax9hShlUS75reJKVGyqJP6McbLoRux8M+cadpTCnkx8D9fVz9CRvhC3x/dzuBvg2gBUbqJG3cu49RJ

J8DZJLHtx/ce45aeP8J+UQG3eVz0YQTJIeTkF0jruPxJ9hP4DY+PrncR2fXbpPo7P3bKg+z6b0hQ1QeSRYVJ/HL169PmP/TlP769VPrAw1Pz3cvX+4wNP4+/OAL69otH6/VPvh/EtXflCMoBuIF6kwtXthBtXik74Irq+iUlvC9X8vvqznh4LRg1zIMxWogT4uOGzge2at5QBgQOADewBYCggaEC4AQs6/AH0AWoo4DHy7V5bXgLuIToRvIT7zOT

dcgx0aPZT3wG+B+T4HpnFbRtaypmhKN0Kf+Rx6+Rz22oZ+Q2tmCjur9glpim7DZz80OU+CtuieR2hidrNlhw0NnhIw6iG9n2KG/wNsueMnuG9bLRMjmBCF9isUhe4v0F+3bAJgxCIl+GM4Z8NX0T5NX7FgTPjrZ0MDq9hi2Z8DbVqUIVgi2Ew0d3xqbjjDi8puxqmDOi5K+yw6b2COgO6peimWALAfZmaAMkCaAAEDEAOc3Zl5i0M5+5+4Jx5/zR

d2WdNbmgVYdBu220lvbPGSZmCzsBYJOBAaDjnv8ViOdZpg9o3BWZzieh89SexkjpOJaAyvROqGmF6VlofeyK2WGf8jtYfNqlcmaGdbUM1pfPit+ZxGmeB6Dl1idi2phtytrBAaok3YOnXisqtmnPQtpw34AOVTmxUODfAOCfOzqyM7XjzN7XsvPqv7XLlQSBCYMgm0ZzRnp/1EeRKWGY5TdTGvqpp69asIQMkcVPyOygcMyTLc1bOfmi6g3RFaPf

XLvsiXuF+1SubD+sfbDoAfosmt2gD9NDpKouDVvtDSImYTOjUT5ahUBBETca/oywSfYAAQk3fuIh+kUeled63Zco37cGAyKF0z/g6Xf96tXfiwo3f0IG3fu74YEmWgPfzg6PfgSDrb7AFPfJA9UndyuzrJpMSLK754ka75nNW753fe78ffDIWffKjVffEnfffwQE9HNnsGzNdYluddaImg1+fYMQmIBnNpVbjvZTfkeopgCqAmABYeIAPT7zEv4E

X8ZIH/ALMGQiD04LfMNeJH+/chK/LhqOFfEOXrg3nRhcAnwRkRet9b8zTECsGJLmyc9c5mi2U9NuiO7j7Yti0lYnQnHDV8AWEXnW/7Wc6l78+cGMorb0JIb/WggUosbeWq/MUnzjxgDcwejV6JlYDck+f9aeJ0Dehal4Zn50N+xfRN4o80zdXkag3mEK26ZPon9ZoLPX44fKj4L5k9H0hld5D8RxgcpvZANF06sFOH5VZWYu30pF1IAWZZufCY6x

VSE7VfHvc08hR6F3KtnO8Qrj+x8ZjamzQmT44zZtbqXYv2dLcj75ycoLJow6wFY6+jJ7kYeIyTfNyldSnCn/SnSL9FHKM7YnEo+KzBSBHIncQSQBneIk3Ol8oWAHGFrc38HbX41gHX68HXX/gCPX7q6BIEgxSk/UN0AbPHak4vHGDEgIhAGG/E7dG/Nel6/k3+s9oYoQ/Po/Sy2ccklmvm6XVKfhxrQi5fS/dsnir4mvb4lG12mxZg3sE+ACwApz

OwHwAXora6QgGzDexmo/kaf2vHk4lAa0V9wLRDLwSfmm5i0TPE0+BimoQynjJUMtfvH4PaA/U0eQKfac2ngkrvejYXzHRp38pik/qZFRM9zMzn8M+zniM+DfNrnyy7DzRf/Ga2bYMoa4N8erqALmLkddVHqJYAQAo9WuA8wAQA8BAcqkwAewBusuAGBs0AP8eIArQgSAv8Z2AQHE1QwCevD2LQQgC9Qk2sraN7zrqiEwfarQsAIC/+FxuqafSmvb

AE+peH7vlOb8creb82zc9Z+/z08tQFJKqYXPwMPiaa9mgG2fMqyT3syXb8jkw5h/e9vswdR3RpeyzbLBafNrATBOWyqetrgo4/9Sufq/32ca/U74OH4A4yBzkQeN0A2fCJIFKuLVCW/Y/dsJ9/QqQ8wrqtG+UyQJo/p0qVv7eV/mUA0f81CxIDj/Ak8IAif6AxU9FT/z3vT/mvxG/YZc/f/M/m/s04vTkf+Lp+f7gohf58usk9L/SGIr7Ff8gEVf

67/ppYAzKs57NXn/l/epjEffm0LjfP5DTwX4GloIEwAYEH7ROJOw//nei/8NqTH338Lf8X8LLcCBLPZ3QJcknBDwxCcttJeCbMJo0LHhoeLHyBhc2JwTbf4cOkm97RW1SbCnzfv/WHAf6DfRWxluEgGcA3sEwAkwHoApACggBwAoIAKUO0AcADKALbw3dTvAKQA7wCCpv4WW/KsNEEWu/JjvsxO3SqozuxOQ+pv4lNW96D4OkYIFgjbVimENVYn9

PKExAhNVkiIRMy4iE1WOAH3gme+YGLYAQZ6eAHmhEbAw1a7Vp+QDeSkAVNWFAFUAQZ6Zo7Tft860xaomrMWhdBkAeQcDAEKVOlaBAHVVntW7AEKVCIBXAEo5NQBQlBwftt+GOax5l6qGAaQ/nPMReCMktygkLahqgLWXUTUNOCAPNzvAHkgX34dDh7OjFYavqa+9aQvMCluXgwfPmfA+/qVEB6QmUB/PnQmD15ETg62VNj8Hlz8HI7yWlGoyrZDB

jUuQvQs6oO+KlacZppaLBqbksQ0b4jEAJ8AmgBQANOArQAtCrbw+chUuO0A9Bz4APzcITSCGggBUhg1SjouDY41dhO+37ppRmjOdg759v8CMsTXnNtcR8T0DkwOFdaMAUNWO1ZEAe3K9ZwKVKHmjVacAQBUftw5nNwBRMx9AQnc5wwV1pCCNQGT5HUBICQNASMB5BzNAZIBI1ZsAb6AxAhdAWXW5AG9AZXc/QEKAaU6QwEJ3CHWdf6/Ou1mgs5io

sZ29MQTAbVcpshTAaIBjQGzAeIB+AHMAa0B0gFLAZ0B3VbdAZiMgwEbATuEAwHrAcMBwwF7Abk24YrD/lVKyH7Rih1KtIIzHJWk185ojsv2GmqCvtkkv/7//oABwAGgAeABkAEIANABsAHmAYb+W/579ovWfQjFPl/cj2YoPpRCYNBGTOW4t+a2FndeZjzhzkDOQL7rCJMQJkS9NDZMSQqhooFOdkrPmlj+PqCMFKF4VX4F+hEBttaKfkhsGlajv

hkM8aaTlG3Ouw4U/rlq4Mr/0v1qBDKK/Av+S/75yI72uLyIylGeywJWrh8wk4bgFs/mAoCv5lp+Cxg0voTKlGwnhhgWUjLnhvHm8nxXhq8SXO4w3oyeVTA09My2aV7WcrAQFTA9NuT8bIF/ah5+DdzAgYV43r7wFEPIxnivdOU2KOqwgaZA8QGJAckBqQHpATHqWQE5AUUGq/4ITjF+qr7bZsb+RXjnnjpu9rJNCAH6jQa1QAAilEDU2vysZr7/P

o7+NIFWvrfojqD3MpgYdgSbQApinbBrolwgzYBXJhUwuaL6MrkotE4ZZsK2dNbKfjsSy+bPwBdE4b4sTpKBtKyafvHYsoFFah4okgDGAaCApgHwqvQyLHxRnjn48gQXrLYuPi6YNE/mQOzT6G0wxyzGRIG+75i7hgA2BoHJ4mM+xoGGfsy8xn4HajA2R2pWgVTKpWxWfh3uFYEHiFWB6Ngudlg2DQgzEJHuTYFdAF6BR05Ssv081nwqPvNkt17nf

nz+k9ZbPjRM4IAIAHmCCQBCAGBATs4JgbmK+v7Alpv+tH4HXhq+XBaQfNq+CiySgh3U5NR8cHJi5ni9sv9O914Avl4BBX4DksH2KZhgGBmYaTBhwnFOuAZDBp1ickrJTtV+s+YE/oi+SM4NftlO6uYYAZKO0RZW6FeAzjq3kCto86paIPUWL0h6dguQliC7gKhQ1gDWANCCnJaxIFb0/EHJIFxAQkEKVKJQokGDVuJB+7ZSQaHcJqRyQTiCCkFso

g82M37bBlr2COYYeBogAkGqQQpQwkGZAAeQmkEjfNpBrlC6QQXc+PAGQdUMRkFyUvB+qgGIfgU2o+jy2tGG1pCqnlP+nQDXPuBOkeqTAN10BoDFJGSASGYtDomB6/6xfimBns4rED7g42ymBJHwYRpGRHdu+OwHSqvIF/7aDmWBW3hEnjK8eDh+4KfaD/5+5CosJnRKauEBNX7DvsKOuc7IzlxBztbNfm7WBSAiAQQOuAG3AUwBUQAsAW0BecqyA

T0Bg0hfAaNBKORIDvg6+Ii0AYWyXUEMDmIBD/B3Af1BDwGLAR0BQ2jNVgBUlAFbAfIB1GCTQTQBvAETTj8OXfaZ1t++5A6dQfQBe0FCUHMB9wGEAY8Ba0Fi+BtB40EvHKU6W0G7QTwBygHlcjt+v45IfpeBtXJ3Vj5+O9homMpakLb/FmBBFphCALbw+ABOMuCAzACr4NUK3wDOAMoA7wCSALbw+RaE6uFBuv4Q1m0OwqYWAUb+qUFasNggFaTgw

uc8hjbYTsyeKzDE1GOkQEFEQVSBngFO/iM24QhkoHqmnnT4UlYo5NyCdD54+bANsAuSd9aS2qxohuxa1vVBrEG1fnSGGxLdga/S8gT5zmzBrUHDgdKBB4Gd4HqBkHSHgQeGwDZ0vqA21GynhueB5oF11pi+NoF3gaFuhr4fPCzBLySSrrDiVZgYUso+LoDfgSP+JCJYTrvKwWDPwKQSF04lEld+YYH5yDAA3sDfAOCAmRKYgcF2lgFMXJp4HCAM3

kJaoy51HH5OgUqoGLA4OjxsMvFOIU4Ceml2pYGw/uMQ8cQ+2Ok4jGim1imQVY4T9OIk9Nji9jOG8L6ZZnwmQf79lvL2kb459iOWhw5yQsCM4lRIiA3kQYRY+IycX6quIHSy+UgzXMp24UigQLj4fPiR6JeqeMBsAKm2bUjWWvXa9RYHCvegccr3enpkNcHtAcTkDcE/nJRqLcHtym3ByXCilkfQpvy9wXBQA8HvfIZQw8GDVqPByGr7AW1mpPpHA

eT61cHngtPB9cGwXI3BE6oLwV7I8UjLwZ3Bq8E9wcJqfcGbwVt828GqUCPBwJBjwf8WbA6mTvk2dxbfkg8WASqheCbsxeCQtswEyYpviDsAiqD0ANlK7AC+wW722IF0fovW/RTxYCXYn9yQlMjcmGzktkd0crJg0J7GGNQWyoyOiTJXwA0QsAI+zmXgH2zOWPAsHSiQ0mkYAkRQvj0ojlJaBDyBM+YHxgjO7EFE/t8mqAFdqhEWwaiuoI9mhbA5o

JCBlcGQHEwQg6od5HaUeQJsHOIhdRQ9ILUC3zZxDqZBAgEuYpfqOmQkapIhwSDSIXr2sI5oBtVyHL5Ugi0cyFYLwnY8kLZw/CTmA0oQQM4AocAywLxMjoAUAEiqaQE8/izAuPTcjGM8sNpictLWWIEoQb9+vmCdivNk+zaYbGmiDfTDHDaQvNhysq0IU+ZkRlqAEQqWyonBzv7dOAnwQrge1Hzkhp4+5IkoJzxh2DsIySQ/1AuUQ/RYXk/WAb7iw

ZICX9xBIYFMEb5DgToQ+lbRkt5+8BTZYm68155QgbZO8CYWIbYKvwBAgGBAbhbYABzcCCG87CmOVgHFvncuPFziJHVgujIxYKYkTMH5gf0I9pzRStEhCiJFQUnBSiTZsNsoEeC0QQEBjJDOypjAlaREhmP0r/5+vixSqzYcQcH+MsHoAe1BbY7pFvEUT4QEiNJU+wpjQGooGiGhIj5cuIgkiFJIj5SWVPoGYna1WlnkU9AEpuNWN6DTASHWg1SVF

o1cbwy4jIHcHRYuFCfw1yGNqLchaCgPIf1QRJTPIa8hZM4fIS+KXyEboD8h1/Br0F0BAKEp1kChT47ZRFFcolB49seOz3ZE+sR2b3aN/uo4EKFQJKJII0i6ur1YdyEn4C+qvoAIoaJILyFjju8hAFTKUOno21r95JihKKY4oVcBMwEdwa1I+TygocShQ/5wjj+BVIJ5sIBGykArZCr+mgyvBmn0pACa1KCA5+gzaL0hFYL+wZliKCHOgA0SBniZx

Ij0VpydLt/oBeoXZqV2ZerzIeFOxUFtyCw8mgRqWNW+EM6xwUWmpHx5KDyGeyHv+i2qHyZHISXBYo6b9DxBLX7wpmlc6JSslvL6WeCz+Dk6yYCigHVaaPozxEdc0nZhAJYg8BwjSLPQ3IDyyHvwo6oXUAE4QMDWaLVQ4QDegAGW2uiNLBjot/hrwG0gD2AFiD2A6kFoCA8h9iY19paYoaGAJK6W8XDyGjaS0aEo0LXQGGTK+j+g08SJodOWKaG0H

GcAT2CgQDtaKAjZoS5cb/B5oeVoBaE4gMWhdyCloWzoqAQVoZVo1aEZAPycLKEsALNWyiGa9oIB2vaF0LbI3rQHxGY6Ofwm/BuAnaGxoc968aH9oVTIrEhDoWmho6GZoROhGQA5odOhmQD5oZ4SRaHuOouhn9BeSONAoehVob9IG6Gj/FuhDaE/NtGCoYZ6IeoBMb4U3gDB/HT0aP00wVY1tJ0AkyZgwbV4VkDewL8ApgHMAMQA5lbwTghB2MEb/

rjBSCGoQYMhxfIuSqq4CwjevgbKdjyNCO2iwLDqLEWB8cF5fljWxE5WWAsM97Dj4J1i5hZGDkMGowhDHGeYQN7Y7M4Wb4gFgpIA7cA3gKCACqAX/DLAnwAQQN8ACwBKCDNoEEBgQPS4P0GBFi9QwRYO1o2OJyFNfsJmmkh9dmBh3lChICfguEBWehrApxyAUBVWA8TegKdaLAokiG+Qt6HOAG+QCgBvkAAAAm+QAAB6cVxGYfWhJmFEsPQKtxxH0

FZhrlCzkLZhqkE+XI5hCaHpQK5hHmHeYQfB5kE/vh9ghmF7dsZhllCmYUFhFmGnTJdIC5DhYVeAkWEOYU5hb5AuYUyy8WGoAD5hJk5/NtBhf4YYBn9O0YbBxKswSqFudoymrsFS4DLAN4Bs3PgADEzaoVOiuqFGsgl+oySoGIwUO4ih+DQuISFqWDxcUiLvsKCw3H7Oso2+DTBRVpQmMrzBAstGwvaoCjM21lh4/kK2HCFZZn6hHaoBoWSiZyHGW

vX2F1BkVo/gbsCpYUiIsiGkKit2m9CnYfRQ52FewJdhxYTXYfWhiWH7oRZBhdAPYaFQT2Fl6FdhLAzvYf8Bs0bVIeR4fI7wFN5G+9juuk0hfP5OzuhhXUQswDuYbtA8AGSAk9bwQSZKdz4NNg8+2/7WAbmOctq2WEiYYQHlNPUcwiSKYB3U5KTRMpH6nPb0wVf+fYBEnp0SPYhPbLtuh3jDnlaoW7pxiv9BA4qqWHxwbYDCYelWnEH+tvlmieQ8O

IzaQVZvvFlu/YbK9pxO/fatIBBgwdxl6KqESIhbodPBN3qDtmwg1OTnoFTOffaF9gP21IQP4M9hFGBpYQ8hKuG6+oHo0Twa4YBg405fDJNOL3bTTg3+x8Hu8mQc9fZ64fLhbsCK4aYmRioN5PDGsHbq4S5Qis5imj+OxQ42wZKc4OGDFOKYHKBn7pC2dDIRQSqy0MDEgBb4YEDdAOLWJQYz1u0O3iFPTvjBpuQH2qRaf+hELomm2niNsKxoZ7i1N

ARShBq5fsQhrrLWSn2C4Z5g0OhSJi6cjkkh1Nas9Ije0sFDBvliCXyqWilOwsGNQXV++2GCJuO+6L7O1qLhMNQAKp3ex2HgpoFyXmFeYVJIzABgqBR6zoiz4RVhWSB3Dg3Mk+HT4Vkgc+EgVBvhS+EUeh9hqiFmevOOsXJT4TPhm+EL4WCoXmHL4VKhNWH8FjG+ROEKxiMSQWoudjDhiLZp9MQAcAAcAMMCqKrJ4W5miEHOVunhhuJkYfk0oyRko

PUYiOyB9lhOtMA/RggsPHqBGtZYc2Fi8rSBbRD8uGRAfTZY3uTcrOFbKFsekdSc4cnUiSiwAkpWvIENQZEB//ZbDkxOpcGVIWxOw+GndES27HzCZmQcVkDGul4gruEe4a+qWHh5wL7hZwDPKObIxk6NofQRjBH64WXoyuFsEebheeQ3ejwRHfYnjrbhFKECzn3MBfYMET+hAhGX8MbhwhEcEXxI3BFfjl6O1xYSxv/B5nw1IX+BjxY80M6oi5KQt

mDWMeEDSizAERDwAAkAMAA6/ujhmKpJQcmBrlaZ4TZ+n2LERrp4agz73Kt0gGxuSspYDCyt5ua+CcH5fgthQeAanmtEgUqJzLRSawgYEeq8XuRLJB2WrNAVMHnBcM47YWxBe2FcIXL2h2G/olQR4uEl6pLh6M4etAuOHY7OiJMq4cAwyJMqFWEX4eURhQzlEQ+OHpK5SCURu/wHkNURbUZa4RQOYFZFEaiIDRFlEW1GU+FNRiwMKww1EYTOvEpdE

T6A/RGtxOURVuGIWr8OiQ6nQQCOh+HtEYvQnRGWmI0R5RG9EVURAxFtRrURYnYjEU0RGxEaEftORQ6HTsHhVIKPtJD8q3RmqL5e5TbWZq0hA9oPWIQA7nzwAOnmdhET2rteyEEZ4QMhQBH6Mru4dTKqwuKBTYK9JEEKyRjoaE0e8BGlqgzBtULkdEbWbr7Vqp7+EzSXapQ4jYJeofROaRGv1v3hPCF96qchwma9EYgouuFNyqJkfmESIeJkNyBq4

dhkgwyujqqW3BHZ/ugA2JGO0riRmcrBZASRIipPaD7hpJE4jCcOswpvGjuh/AF7ofvhQgEFIDSRSjREihjGr2EsEfKEzJGjAKoRSlBqjmIRp1Zn2CDhRmaxElSCclbwYdrQJ4giEmf8F05/5m1hEMTEwIQAlrAcAGBAor76AGBAOwBDAF/mbADfAPmGzQ7xjolBOfLEYf/h1ZLIIYNhLTB0aE9sc7g8hpARQEa1bHKyNuKU4SxhFeGXsveYUqx7y

Ibs5KSHeHK043jWkHU0aTAK8hoEsMD14T6+8n494aLB30rFIelqBiS3tJHi5P4Bti4wf9LywSMwisHoPKM++n4ngRrBpoH7aprBneC6wVWutoFE3kGRBGhisLDAP5JcsPAskZHXWL/cPh5+6jBhMZaARgeyYrSE5mbEafSAELgAK1628L20vWECgu8RAcE7/lHgoXwf3nMQIKQm5FRw5HRVMPhYkaIceml6KJYqNmxh3gE0aNKelfTj4A5YCfZ0w

JshH4ChCuOkcL4dgbthRcF94dwh5BE5kcLhVjaiIXSij4wbfk8cMHa6To3K9JHoiIyRRirgYJhkI6oXUOVch1JAwKNSuUilVLgQkSAV0NQA+QIKyBN+75Gadp+Rs8pmku7hyuH/keQAECJAUXioKOigUcdSmgoTdsSAUFGvkHvhIzIH4RaUr5HwUW+M4swk8MhRwpG/ka+q6FGAUZeK2FHDEGBRQFSQUeYA0FERln/BphoAIfEk9EGY9mOuHtQDk

enm8OGm+PhWuABgQFdi8pATkUzmyNq+ISaQOYDu5FSiZhapzsThE7r7+slg7TBvMoJce6IkUrahiyFtwgPIYNCf3hqCt0qJ9s8mDxhnQHXmSJEIviiRYrZokfeRQuGWNrlOrY7GWk7huuEPoIEA1OgVIo32LfxLfs0iuUjskR8O4hHSZtrhzuFeUQgAPlFsAc6OBk4IIlKR8AQ3Dg9IkxHKZlNO0hH24bIRHlGy4Yxg3lEhIn5Rxf6BUeSRf8TwD

v7hYsZaEZjm0b5/6qZmjxbApPQugcSQtuIWNxE0TJcAEECkAJfY7QAswH52CUGEYZjh2Lb9IdORaEFXroIiEyRtOImYISGfMPgYSDTaUeT8ulG9kkWOJCHWSofAxTRTdJHYd/4N4UpiGQrRMHzhIo7HIYLhFJaBoePh+fYiNHFR96C4obPEqdb3Doo0J1EIDsgO51EkUboqaiFGHAVRkAhnUeQcV+FmTvCO08wCUSqR3ORP/utAkLbvFk1RFpgb4

Aqg7cAceJz+F+aYwdteRGHJQU4RHxH8kJBso7irhtwm96KQETPgk1FaUTQW/YpAfA7aAZE74qt0bKRnwnm6dapOoUWwcn74/iLBhP6okXeRmRHgxpUB6bJ8EYVcc8qoUcbhrREFIIzRrUjM0SKRyuEpURXax0F/DhlRhawc0bTIXNH0UfKEpVHEpjxRtxa6EQFB1VEJEqu8qS42Tnz+yZZA0bV43sHP/EYAocCfABZG3VEY4UmBWOFxfjiBzpFDD

jPi4eAzHOMhDEQY0Xrutt7MYQGAuNHzUZXh1YYg7LhSWNLE0bQaKBgAdILB+cFXkakRN5HpEVYOe1Eb5i5RFcHh/pAchRGLEb0MJEgnUdRIllRDEb9yEwxs0U9Ros4TDFHRAVEboDHRWxEvih0APM58AS1mPJGkUXyRSdH0zk8MqdEbxOnRZM5x0UGsCdEfQW0U+vbfQWLUipHMcokoWFxhMLOYcGEoYZhWoYFbAGBAK2ahwMoAq+i4YWSAXATJp

GBAoIDSqNPQOtE2kT1R+tF9Uf1hI3JkAi3yM3jn1mW4fk4wPDeyaRhRMOIk9v7TiPbRl/4LURo8SHzVEOZ00CCREfUw5KQ3dIGgMZAlwBceWfq02OEubPaJkRTRyZEitgyGpBF2pptA37xOUap6I4EQNv/W+oF4ykeBJZHAtLtq5ZFnhqAxvfDVkQoy7c4A7gfRDSEt8hdE2HpFAOfRa8gGuMlCwfZBLl2RtWFytoRB9URPPJk4aYJDrJ0A+GGz/

rYKnwDD2prUXpizgQRhetEOEQbRKUHw0VqwQfgHwBkGnmr6bk2CZNFU2skk8pjoMbbRoCp6UUUGNOH70cMkR2ZitCbK5lGQzpL0maJ9zqwhAo5v/j6hn2YOUTTRIf7lwWH+eU7uUTLhxfaKEYbhSuHG4UNBoSB1dGkgbsCJ0e9yGjEN9loxLNGEkdPB+jFtbEYxB0HW4UdBaVHd9rMR6k7hUZ5RjGDmMdzRujEbhFeUNjH7EUrOhxGAgXxRUrKgg

TVRNTDuEB2C5TYvVqrRXUT5Sk6wCwB5Sv8WzxE5lm7ObxEAEQpR6FgFdigyIxzbLMjc/OaSXIBOTqEP0WRGu9ELIQkhjKA9bisOrZYFeushD5r0UiCwYfiI6t7R9ha+0b6h/tG6YYHRNg4VAc+RhLKxcglaP0xSSP0yj6SMYL9MNyFRVC7Bc45tEYNIfTF/lAMxUzKoiKlowzFTMjChYzH3UdXaj1GCCLcguIjTMbMxYaxDMagAIzHLMfBU4zF6Z

j5BddFB4f5B/FEhMQEqvz5aPkrRE6zt4iwAD1gLAGfUslEKFmv6VkrhMQzqQR4ImE6ouTG0eDvs9ELDyJwUTYolMQZRZTHWSkzBD5i70ifcmfrrYRFSQmyEGF7RyREFwRWmnCHU0RkRyjH1diHRajH2DrPE8hH4MDzRM0EaTqgA+LEH8KzRdjFTEfzRMxGoWnMRhdAc0WSxljES0b82UGEfUTKhzHJwku6mYy5f3AR6y/Zt1gYBpvi28BeSCQD6A

NTm6sZJMcq+UNY0flOReqEJfokorTaEGNfREBHFoGoMQOwfLlWYSfizUfpRgL52oQXAz2xGmFl+hg4ZMhqszNCVqpeRzTGU0WixijEYsXphof5dMaHR/ixXUVeUs6xAqKiICwCoANMxJpCZ0bxKEXLGMY36+jHOsfZIrrHusUTMEXKV0U2sUSy80Z32jjEnQTSxLjGTMf6xJ0hBsR6xobGszlnREbE10ZLR1WGsselkjdG1cjgxstSluAGcdobAQ

bmgafTiYZJh0mGyYfJhimHKYTAAqmHWkRLWtpG0Vo4ROLYMMWQCI8i1bFsenchnfuwxhdSZoLnqujCnESCxO9p70ZXh5Ca72MAa5nSJYD7koArU3HF8lCY6PIwharAJps0IhSF+JPTWvZZWsXxcYphxGPpepQF1durBeDJjgbvm/7BYYThheGFwMo8wJcCRUg5+awS5IZjKT+a9ajKBoJhygRIAvwBIEO3AFMA3gJ8AzAAKoO8A+gBU8jyi5cYpT

NiIl7GF2N/o4ER0FNTcBMLWbpiYt5juzGRAujCdmF9imoDR2CM+en60vgZ+ZZFQNhWR4DFVkXA2esEDzuseVPwTsdrwU7Gl3lg2s7HbiHJMC7FJYNbBYtQGIQnm/c645q0cq64pEkOsSkCS4h+xX7E/sX+xAHFIRMQAwHHf4FRWSr40VixasNGtsQNRxb560Jy27H4iJIJwHz7JKCq49YAH3icemrECMfEh4JHWnPSBB4j18Hd0p/YZ+MvuSfgQG

GDQWZD3tG2w5ER7sbZRc4aP0ruBhyH4dAPoYjzEgBJhUmEyYQgAcmEKYUph9AAqYWpheQH3ksIahQESwSLsY+Huctn2CAAuptD0FIH34cUQhcCXEbCqp0Bp9IQA7wC28GbEuRxfUuKxYnEqvnQxcNFScfk0J9wM3slC6Nw3+hlCdRAA9P/UvxS5MrKYGabzYbSBtTQueN0kxNRwojz8maDaRmwUMNR/EQOKa0RBwWbaTTGS9smRVNFbse0xEoEPk

cHR6tDuLrDSxjyLLsJmZzbaTsqE9aG4iNyU6Q4mXPNxqzFYpusxebxLcaKRLAALccDhNxYRcYf8pd4/UZgkRYBhwdDhNbSDgGn0AIALAJgAOkpDAJbErzGNNooWgMIgklTec9LtmOu0LsINgI5Mp+wVLKCRWXqGUQXALmzyHikhFUFJCt5+A4rekE562rDbUc1BAuHDcc5R4o7TcZtxX6CBcu5h7mFSSD1mUYzECL7AAwCRcEtxuIhp/JbMAXDrU

EEAJsDz5Ntc1DozMecMC5AYVIiIa9D+3NbyrlBo8Ytxs3HnoCjxsXJo8RjxDWaIhJYgOPGpwHjxrPGcAATxMsBE8XLIiACEoOTx5wGDSFQ6VPG1wY1WdPEJ3IzxOFDM8Rr25+q8kQehBxrI8RTxnPG9ZvLxPPEcAHzxLAAC8Zu2zQDC8aLxJPES8csBsXIy8VJIcvG08ZgA9PE5nErxC5Aq8TohUtFyDBaBdIxrrkdxY4hNHDuINLSTDmJRrATtw

FuEqgDr6CPY+cjHwL8ABoDMAPoAKCbewIhGU9E0MXaREnH9UTKxhZYW+lU0U5542J/W+EZ33K0Q/KxAylahm5E7wtThmnG04dq4XGyNlGWebfTm0RkyYfBD9PZYJZa01OamqTKueGaxfXHEEYlKYsGv0cKB79ET4mQsmLGHsbjKBZH7gf/RdfiGgUeG4nwgMThxYDE4cReGnLzXgaXORHE4vvrBN4aNrhECF6zPPLGGR352rnviDsZ6bopAcwTmH

i2ABeBnWNTWbsIrasw8DfE0/En4MryocU4eRJ69CAF43SQV8MpueuwNipRwfjRcQvRxQTGGIWP+1HjsfGH4U/5FgGn0CwBkgGwAEEBWQLkkxzEZcQPi4nEtsWnxA2EZ8UFKPvrz2FPS69aqMMyqDRKJbC5uEWB/cVwGwbzbSjMQpngYwhDO7/bmmt7+22EosdeRrTHosQHR8PH7UUdhwmalEXIAuwzwoDegkKEXUASI3zisCVCMQSBJIPs6XAn0U

DwJqvEomurxX2EFIHwJ7AmCCZwJUCTcCRmxzLGqRtfhnn59PEAhQ17bgZacIAmW9mYRtgqegMSACiAXyg9x2OFG0RnxzTgLcsmybYIrwvZeZwLGePjspEZAfDEhkQqjsZeyem7xYIgsgvbLCOGRwZ56uMFgTl6khh+AY4gqWPtKMPHFwQdhQ/HlAZm6miIYbBzQ8trdMWZi8hH15N4xRJQ4+sSQbUjQUEeQHOAv5DqKlIjnADx2jygnodPBrFF4U

XSElhSQIj/wVFF7QnTwaoTBitVGtJo/5IY6KQmSJgVc6Qn7+FkJQAg5CROm+Qmb5Nh2ksQN5MUJDDryhGUJRAAVCdVYmnbqIDUJygBckXnRavEF0Rrx/7D1CfEiyQmuIKkJJ+DPDpkJFCjgYHlo/oQUqKjE/QlFMGxRQwkHCnQIlQlYUNUJKByykeXS2hG8UTLReXS10s+wdjx8cP00AfH4BtqR6ADgAaHAEEAPYFFBxgmG0U6RhZaJ9EbuLFzhL

tqw2YFlLCWe24ipXh8y7gF20SOxpTFacQGiuEE1+oaxA4ZY2kOwBiQYbKTB1nGosfZRKn6OUbTRQbbxCZByM3Em8YBgbMaHKhSAQxa3IGjxNSacnKjEAwnvDHWg2AwQfv649hzh0UuOqIiUlAEcULCEoINIGIC4xrhADhTAyKvgoQCigCX+kyqVgN0RkPgODrKUiMaWmA72SUwTEZLxZByUia/QNIk+UDhRDVIfpiehynZJoSjM10iFSKNwnXy4+

HfQbIlXjsXRnImylKvgPIk3kGjx1rq6+toAgolMAMKJoomEAOKJ20DdEQ+O3+CcmE1GMY7QgIqJLRHz5CzxpInUYOSJKok08NSJnmG/fPSJBwklCaJQTIkndktxHo7bXKLOXIm25jaJkFC4iPyJwsZOiaIAjkgiiWtobolNRpKJPoCTKtKJ4k6yib6JCokKoEqJxAjhiYPQ6onaOrGJDDq5RK1guonTlpAEqXCGiY/QSXCizGaJCxEciR6U3InrA

LyJdonZicGKuYkuiYWJ7okliZMimxEyiT6JJRHVibWJrLK50bDmAtHOMQt+H2AkiZ12YYmzxKqJOXDqiQd8MYmTQGxR8YnXQMyJSYmg8imJFolDiemJI4k3kFmJDomTifmJrokziSsREADlieeElYlLif6JNYmBiXWJ+4mMMI2JqzqniSUJrYnnAO2JR5Ycds+E//A9iZBJD0z9iZ4SEdFpidaJD4mQUGOJz4nQmnmJYQAFiWKJxYkfiV6JP4nyi

X+JK4nvUToRV1LRkgWAJ05ELstG53FhjiQxA9pgQEcAUmGfAMoArQDR4VDRtz4z0Xq2c9GF8gt4z2z2KHYExCbm9g30d3RwAvcy73G71o4JNqHasQDxaCCNhtHG5E6A9Kfasb7VQfZYQiEd8UO+XfFNQWEJ+IkRCYG2T5H2sfYivahYdsBibkhv0MsgQFTCgMAouUgi0fvQmf5u/MRIusi5SLxqNbbDCdxI+egVSGLxpPGeIHegU9CyCRdQGwBUM

JAI0kFWSB+RaIB3YSlh13Zu6LuoMjRmNKxqiipQDAjoQpT4MI5JBfzYDC5Jh5AkoO5JxwkMyNgMPkmEoCzwDGCBSfRQwUnfxGFJN6ARSVxAq3EkdnGxr8QxSSK6cUmWSRBqSUm2SZzRDkkGdk5JFUhZSW5Jj44eSflJxEiFSSbAxUkCCeMgQUk9gBVJekHYDDtI3kH+MYHhRxEXMV9Rt1JZ3q4eAfHJvkHxouSb8NFiP6gkMr8J9DG5cfyQtNh0a

EFWqSS5YkmYz/qZoCz0EdhhSqXhKXbkRoDOQRG0gT0GBDjymFSig8gMRln6lTDe4jIxvr7eoTbsdAmDcSUBg+HNjodRGM7ISRyJNLI4zrVJlKEO4XNOA4mdjuRJNwmUSQFBC0YWnC0Q5074XCUk4zyHAJgAQgBgCFkUcAlw2inxiAl8STJy0vQ6JGUsd1LQIGwxBsqdCFdJxUwJfHcCJfG0wSRBgjGV4V2woWCkRH4Biw73tA8YXZRaSXyBwkK94

W0xwMnZkQjxB1HCZiSh/g4kobzOCQ5fvrGxW4mF0CShv8FZsRRJkrInERBmdSEJ+lauAfHYfptJUCE0WhQArQAAgIa8+0k5cenxaEG82JIi2K7n8ZgJzUQM6iLsohLdJP4RxYGPSTuRZEEkTq6Q2x4/FCtkbtGS9DOeJeoxRl3h7CEtMQoxeIlKMTaxKjF2sTix+fYy8YNIHKGx0Q+OMsAgJJZUxKFYckURWiDdAEeO/g7xyUihFdHJyanJuIwZy

YvQWck50YdByk7TEQrJuwZKyQUgecmJyeYcs8QpyTegacl3DCXJS45lyUyxkGHKCdmxS0mLMqh+hhinSXywzWEsLAaAQX4GyaZAzwBQTgaAOQL6RkTJniFBdoghPiGpgSMk9l7MjB6QQ7JJmIWwv8xmFkZENxi8McRBJYFPSTqxrBDDiOO4qGgpsOFG0ua8/BHiqShRcY/RKREWsbiJPYHhCVHJWLGqMW5R4KZ5yTPEqADIoYYGadFhDteO4GB8A

HlomclNrJmcvrEQAN/Js8R/yWEGACk8asXRwCntyXxqFoDlyfYxlclUsdXJhwGyEdApv8ljjv/JZdGAKYgp96AxXNeOQawQKYoJMFblUWoBWDEQJuoJDwmZng6chOYGgJd+ugkD2kkg/dFHAPuSVDFcSWv+JMnZcZJxlsnScYs4d26WqHVg8NxJmFx6Y7CeWL1MPIZhznTB5fELUcU0uEGxcbTUyUKfSQOKDAS31rshIck21sLJOc56SZHJHTE5T

tixn8n59guJ5SZTkPiQEMm3IJApFim2/B4g+iDXjpGxkhHkoU4xislUodrh3omWKYX8TyDOKZQpcqLykcNmwLaxlomIoB7hLiAJOv4TyVsAvYwwAOCAoNoKoDCBUX5NsQgJAilICfPRZ8bwmNzQI4D8rHGG2E6exC3OvvGLLkcmsRrh9sfJ8kmaPNARJyzOof7JQwbkITVgfI7YibQJ4ckvyfpJb8lzBjHJZingydchlokqHAiI146HKqiqsgBNU

MeIOcmr4bFyIXKoSf0pxdGDKZ7AnSDXqGgplLHRsRuJHilwyZeOmzGTKVaJ0ylFEbMpwylSUKgpXcmBKXtxoOFktFcxPA5TUeMS/u4lsZtebCk0TO0A734wAM/ynQCT0Y2x09G0MbPReMFtsQl8h8CGESdxHuRkcG7kWsrMqow+/jSFQWCxWnH80N2w53hmUbUppAKa7A5MwcksQaHJT8l+0fQJQ3H7sWFxHSlBoR1BwUBEOuQIP6GZ0tpm/4rgY

B7mNgbYgHipeeTcOrbSRKlQiiSpMMkyEYWsYQAVOgSp1Km2SMSp96CkqaXSKgFnMYtJeXiMcbVy4XREWopgEfCaBudxLmbRKeRizwA49JoA7cBGADPcbAD2+hu+A4CFhkcAygCv8rwpKSlZcR8ppGEKUbKCwBj4aC8UivJ9yD+88fa19J2AjSHyKWzJiimV4XA0QriwwOeYLqAs4e2UFR6U/GT8mfphAhBsT5hJEQ/JNAnZztamvfHRAalKsQGSq

B+IvCwywGFCnwAjUEIAlPI7mAaAvwBWQJoA7iF3kshA1UpIAbVKDY4uoNZYfShs1sEpJCLKkRDhUqxCkCPJOBDfqERcCQCVAFj0vALmyYIpyAnzRJgYqBo3BBECYWAFQSAKk5JyshECHBR3SQ7+7skNvrSBZhY+bHEIQlpknuTct272KJKwlEBvMNUQKOItlJvYv0lJkTpJIsloqWLJFSEjcdr0iKJh+PRESOwTsESJbzi+wNia04CWIAJy6grNU

nlo+6lpRIwK9QwhNl+QQCibCfegeJyNoXupMhC5SEepQugnqbkJZ6neUBeprjYigDepDbZ3qUKcYgnWloLRvVyPqQoah6ksChoKHPAcCgoan6lJrN+padJbhH+psdZIydLRKMm2waEpepgvMPaczbAB8ZDREqk/WhTAFADQgPgAZ/DVqekphfJJ9B/KATTLCG54fciJegB0Yj5pCqHOQHz71tapl7LqLLyeHqA4JO2wYVKLROcCK2qlTJAK8tphA

nzUjGiKGKEJt5HWscYp6uZf6OE+K8g6Pgj0wmbQaR+qC3BYBN4mbjHg9stSpxyrUDMK5Kjd/Jyi7vxBAAep6wxMahxk9mFElC1auAAJ7GcgSoR5FokJDQm46D8woECWANwwD5akimVSXBwVIIwMMJpAVIqKVkiOUAcgVJFd4NoKMGkd/GppfiIaaTegTInaaahQumkAFAyihmlr+KekrJQyxF2m5mmuIJZp1mnrUFAAdmmLCdPBvoBOaUTAroRBA

DppHmm2SOf0PmmlVH5pN6ABaY+W9KnAae+CymlpRIxgrVIRadlRmmkTgFjopWk9UnppoVAJaR1ISWmDVCZcqWlmaUX+mWlYiNlpuWlDGg3kBWkx7C5pADAlabFpZWkQYOFow6r1WNVpaFCBadxRasnIyRrJTdFXKUdxOj7zOOhoAfE8KfhpZkDPAMbq0IAGgHqKZGlkyR8i0xC4QYxos75stq4MlRDk1OUwQlqMaMZie9bbkb2pJ8lnmM6+czhkC

cOCjbD/3u2YKc6n9mECxNRUQpoGTSlhyYH+kmkMCRipIA7RybDiAHzx3tWg9xhxCcZJZmJZUcX2ymnE5IGM9Sb1UGMphbL46Q32hOlBhMTpDhSk6S4pZKGzfnbhm4meKXSxpjHUhFTpWIQ06anAluEBKdzixymVUUoCctE8Dm7u8OrMKfoB0TGm+EoIygB3gPgARwBJKdQx9hH8Kdqpy8mZ4TrwJngBTGsQ6Bg4wlhogOx9OC3y9RiiFNvRARGsY

f9p8knYZkPIK1GUIbzJejZpXupYgslEEfyBi6lAyX62jAlB0YjxmuZCQFiEtOmAYKiIwABTQl7p3OnUYL7p9WnM6Wspm9BBhN7pQekTMChp+3GFeEEBVKYjsKCwrR6d3IJ43rptwN8AG+CwgIXId2mfKYdJwNDNgC04FRjxliA+BGaHtGiYE6kdYn6RoVYWvmxpO+IqLKMsCtB85AC8WgQaKUeIxt6LLsWxPqk+0SipgMkRyVJprumdMdipbY7Z7

GgAN3qcqRMxBSAj6RyR1QDj6aShNuFuKTGxNcks6ZPpjeyj6br6s+mqySyx6smY8sxyWs6HacnwSliwJinpIYFvCRAA7wASJjwAfgCj2jnpOqmpgTfAJRA6sOQYhNZsHkc8RJ5jJKz0IzRFMSxpf2k8fuCxwLDdsID04SGfRq3pmMAtMJHwqeYpVj3pLSmv0supg4GrqZLJHumaQH8gMMaz6f4OTSAoGSHpqymyEegZs+Qb6TCO7vEnKVKyQukqD

H6yMxBxcfSmBoCgQfyxrAT6AHuS0jxDAA4wHiEWamnhfsG56UIp72KA6j/ed9H+NNmB37yTEKhokj4VGC/plIHNimXx5SngsaOIkNR4aDEwRNEgGWPgnswAUoiRuin+/vIxiOmiyS7pKOllwe/JnSkcTmZiLuDNFGPp1mIGUGvp5siz6XLJKk71/qHpshH6GSYZIVB4GacxuiG9yX/xTdEY9vvpJowwKk/h53FJqV3REgAGgJaR3QCEAM8AzwBwQ

brRiunNsWkp92leCuHwg2RB4A7BufHKLGdAhtb66Qxo8ZAEIVuRYhkeyQth07geLtzKpNxrIXCxXxRJ8Ix0fL5Cwcip/XGWsX3pyOkgyZiRiBnoAAyIbBz1GSZB3JGzCQ9RZFEFII0ZEGFHKdcJqGl7ae3a3qn5xlwgOUCJvhQZGMHnab8AYECwgEBIMsAAgOgmoRkvEfm+qTGOkYARJ4BJ8KesouCRMCM04DjkJjn4xcDTkmpRccHV6YERmRm0g

az0dGgyvKOwNEEQzju4DK5UooiYlRxLscUsMCCWppAZ5RnPyTAZGhnVGYr2sOKZQPewdy4KGHn6O6na4eCAMdJecIHpYlD7qWTpxLHAmRzSoJksAIBghOn06fPpjOnpUVYZQtGzxNCZeeQu0mCZCJm86VcJFVG5qSHhGGnUeCTcmQbxcaDB1Bmi5N7AGOqggHAARgCYADoJGqlvKUrpvElsGbWptsKVQNRClWBVPiqsK6KmXkuUJnF43nuxv2kZG

abp4LHHwEDsSfS68BneKP71MCu0Y+7KWh/MypGdcUguaQpzqU/RC6kGKUjp6KmfGbaxX+gZOOeYE7juytp4wmatMjHsjvy+6bHWxRFi5GaZ+JQQAAcqTSCurLPquOAGUEsRLMBWAAog5REdGWFRkzH4QKBA5pkTMJaZSxHP4H6Ztpn2mX8gjpkHKvoZrpnumYQAnpmYGUvpYenzEaVSIZnOiMAAgZlNRsGZPEihmbsW5w7N6pGZLplNRm6Z1MBxm

VVhW+m7aTvp7doxKPCSaXhjEgHxxzHnaYPWPAB3gFBKcY6vKcnx4RnK6dKxbJnvYtnES0TpOAGgDpzRSjao9kwAsPrQcWr9NFk+NMGiGTXp4hlacX/oALAP1kBssU41MXQE6Ilh2De0CZHw6VAZahlLqR8Z4slMCYBatRkF9lbSsbaE6QNpEyB2KU3JCGkv6iFpVUlZmReZFLGpUVIR7ikJmZlRV5nC0meZ95mhUfEGmbFlmT0ZFZmRcfoRCRIPX

ErQPLElqRAhWFamQEcAYEDvAJ3W9s5FhknxYRmpKZ2ZaTF36T/MsNRzdPcYfk4VMNfAMNQgwv2wrsn+kQ7Rl7ICkKF8vNgpGcuZBRlDBjTc6FhhMBJp6hlkltJpbUEmmRMp0zKNoYFySFTxmdgphawcWWxZnRl86d0Zsel3sBlC8BQQhlcGTsFYyeYhhkY0TK0AOThJIPnIlkA36SrpbbE6PKpy9ljmqOREofhWshZMV0qyWoiu2tYm6b/pEKk+4

COwmixi9PkZqzhbLGdAJHBhMFs4p5H8kKIGQ7L26d3hGpkDcZUZ2pn7mW7pgaFreokobDKB4OZ0wmaoSRmJokiTKkMAqhBoAKsRyZlZmdoAkexIct84QVnoSSFZEABhWekAEVk9EVFZQQAxWaoQcVmAaXN+qJm9XAlZBgyPiaFZ4Vl9ERfhvpnRWbFZ9hncqY4Z2+lRioV41BpzzNsos3SALAHxLSHSWRaY7wDKAN7AmGRdwGgO88nMGTjBDpFLS

v8J80QoLjiY8ZArRDK8lb7znnwukTBFwGCpckngseZ0uzwSngmQFEIDhnR0EDgHyun6IaCoLBoiOMJbma8ZqKnO6YxZA+kmKerQbxjuWOoigiIl6i9yscnpsqNQvjZhWgIq9vSEggdI1KC5WUzpWBmFrE9ZBILgjIJApZk9yXVZd1rKsMNssqFS2lSmHJnpOJxS53FaAqfplQBLbLCABsLdAB/8WRxCACzAvwASYb8AkFJdUYhZ8xkG/qwZt+mZ4

dayx3TK1hSkWGlgie7KkNTJsORwmZ5pGaXxM5nHGSfJ5UBC7o9WbnrJuuy2SJg1KGFgcZBTIR2WOW6qJM5ZZRkamf6pQoHA3kzW5Z5FsF/cOamy/rP2AAluEM/6Jux85AHxaGEUmW+IrQBGACj8qBA8wEpZXZnz0fQG9qjKQK0oU3T8EgThl7QniFkoHtHhCs4J8IkV8cOwKg7MRJdE0fKn0SxoHkaPgZ3IrxQfXkWmZqhaBGNRpRl6KXHCuklam

bAZaAFsTkfCIOxNmJk4HKrCZtz6tZrFDOJ20/h0mliEs5CO3L+qrjYq+rSEYIxlDD9223acnNB4MdK44MwRJ6QAyOf0vYzFaWepb5DkKI+Ai5Z1RliEe+COSNSaQMhzCsfQQ0GKiswckiYzCv5wlBxP+LlSUUmF0HHZwIwJ2daSGAR10CnZi/g/qk5amdn4gg70TmS52X92O4ogmVoxJdk9jGGMTWlV2Y0MNdlcDPXZRACN2WaW0dI8dtCgQwkWi

h3ZTiZd2b3k8hy92S/4XFlHwbIRg9nvxMPZ8Uij2cTkqdmT2VwMh3oz2eCM89k9dovZMJnL2cPkpdmvjNwwldnG6FvZddm0hA3ZRCj72ViIh9lLCYNQ7dn0UMq659mQdj4cmAR92dtpf5lCWWrw9ClIjops9d4p6XDh6tmmQJIAMABgQCzApAB0NHPJcxnJMa8RJGHKWXnpDTAg0DN4bfTYBhvIcJa+bpnE10kDDsOx/DF40eUqp/FBVkPIdGYZw

WsIWcGxqJQhI5L0WbuZZ1maGRQRtrFD6eoxqAAYmSfwf2CQOefBH9muHMBgpvT2HEGEDpmuqrwR6Jkgmao5u9kdjESRFyr+9FuQ14l0KhA54Zn6ORIRDOlmQZ9hyWGs6Uo5RjmbdlYApjmC+rSEFjnaOfPkujm2OVSYu3GCWYQZSpH3CVEIJtnz4hBm53GcSedp7cCfUrOyntAvKSnhv+FeIUTZ9DnsGcWgFJLHwMNki5L3sa0Sf8xLRPvYnWKo4

kbpbsl8OS7ak95iRHTUzqE+5Nbi0HxB4P/oJe5FpmoSMRhSORL+jnGsBAsA3wDfAJIAsIAQQO0A4IAu6nsYcAA2mDsAAICOEHrGfnEpqQ+SIhrvGTI5OpnRya6QYLAGeEAZMCqLvho52dlOZFogGcptaTeQHOmZmm+QWYzcnDNcC9n5Up1pYQCNAPogYjrhWqJQ+Tp+aYXo/WlfmUFpo1BBhJs5a1jQjL7o9ChV0BCZK9lHOSz6pzlMiRc5MRTfI

Nc5GPq3OZBQ9zldaI85RmngYUohzRniCXMJkgmmNK855vRlDNs5msi7OZBQ+znhAIc5S5aKKD92ALkXiUC55AAguakWhMSz5AeQdzkWik26r9DQuUlplwm2evzpBJknEQrZfYDs2kPUxan8Aj6m52m28K0AcuL6ABwA6rZ62ahZJNlotPrs7D6ROWP0u/pDEtXxzqATqQfJrMlHyczZ8km89gAspeAtEI1ZDGZcpPysjen7GV3p5rHHWb3prSlGK

edZ3EFgyUbyuvZkqegAqvZfWSiZP1m9XDa5bvE7af+ZmBYUpsQZUQg3+sUQnWIB8aYRjEk0TPnIoakAcBGpUakxqc208amJqcK5SxkKUWOGNYZ+2OXwnem7+gnwni6U1GdYLTCLWaRBC2FJYETcoyTpsCgqTsrpQWFgcoITEJSGWfq9TOO49gRrsT3x4tlTBsi+PYb7shp+csHj8bqBY/GjgS+x44HoAI9+0qmyqfKpiqnGogaAKqlqqWBx6UCI1

FhBlWAdYKRATXIPsbeY4LKVtNXgizi87mhxk/HbatPxJoGz8VrB5ZEL8bA2S/GWfivxRN6cbN54P2KPtL8Sy54ImD5sSWwsFgE0v/G3CQRaODl6mHsUgnSplCnp1xEdWbV40IBSUTLKsIAQwZG5I1nLGerQFRgE1HvI8ZiH8h8+A2TmnGXYzzylOURZLgmyEmVgN/oSuE9s10THka6hsub7sKjUeSlHWa5ZFRnGuf3psjnwGcwJR5kvOViEbzm3c

EBKX5GiUMomsuHV2euoADlAVtBQFRS+UeR5PID9xCoI4mTRAEDgfugBIISm3pk7aBcqxHnVcKR5OzkHkBR5N5BUeaFkF5Z0eWEUDHlCeUx5tkAseSYqaqlMCpx5qKZKZnzRyynUsa+Zv1kbOai5Wzk9IAJ5GLnSeV85oDnUeQc5tHkooJJ51hTSeRkAsnl0hFEACnkcwkp5MekhOcxykELErKd0PTRMLPFxWpG3KRaYnIIwAJoA+cj5yD1Z37nM5

qNZ2uQvagnEfNStsPmw+9yBxELuxUw4Xk2UVenpGUzZoplacfWAV5qY0rLysKm30R2YxUxqmY/JhrnQGTV6A+GeWYPp5rmQHEr8TgBXtic5f6YtXGcqcVGCKgCK2+RsHJV5HFC6eYaJtXnDGiE4DXkxOs4IzXlNGTMJCLmtGYXREMSb2dV5HXnMKgeQCjg9eVC6fIr9efxZeJk0KTfhjnoiWbLUqp6aciAJxOYvuTEx3/wlajXGsxn42TQ5Cxl0O

frZK0oYChmOw9SvJJzySZgLdEtABbDB9tBu6bnsyZeys3To0rOY8WY6NtfJgbLxiuJpLxmYeW8ZxXnokcUa8jnleciUFOnZhGN5ROlikeQANBBEhPLA0gC5SJeZOuHZUUZ5UPniZDD5KIDChPD5po432QEGxLERUb1IwkjlJpzp0PnsMHD5JKDfmScx80nUKX5BzhmupkBZ5ylFGZkq3vHncaJRRDmiKJ20yYZLbK8JCukE2UhBJ3kiuW2xnuSQ1

BOpLr5fTh88M3j3eckYgeRPebXp8fjvME6g3theDP4BVFmMRqjYiPTo4six3emFeTuZp1lZTkxZoMmx2TxUGPnmAKvg2Pl8Wdx5numBVCb5O5Lm+W369jlImY45EgnOOdnCxvlk+bb5CGr2+Vypn0G+Qbt+fclN0at5AzyZ6ox0WE7ncY1R23mm+BBA0IDYFBvgHAALAAhZbZlIWVqpLJnE2UL5NNhukMU0WCC2WNmBZWKtNkvIirEy+QROCimzm

fbZMzimhl6crrZGsb2+JTQg7MLZgdlfssHZDFn6+aa5zFlHmQB6vsD+GKB6IAzhKOYZVcmWGfa574Lt+S0iP5lKCXk25Zn1WZr4gfnWfCMkjUSACgHxgNER+awETUAvlIOo1kDBefJRqYG85NRCaQpquJeYSZiwXn74BfnjYSzJD0nlObH6hkyztGFK5lnkCdq55nT7Spn6GHmO6ZqZTfmZ9rh5Esn4eVEW/7qoAO8AjRFyfLnJ3/m/+bj5fUYSA

AB6P/kzXI55AunkeFP5jxb02A2BBDGavAaAKtGL+aLkRgAcBDxIamHf4YCWKTmLyX0hkRmAwrzkr3FfymtA5Z5JmJM0kvk/3kJax/kiGWUpyrl/6ZA4R7nCqRRZDr61MTvIuyzDHI0pyhlyMQDJRXnAxs35b/kHmXTRgJmaeqgAhcg1oWsGIgXl9quJFcm7oS0ZazFtGbYGEgViBUE5+Jly2VAFDPmFdJGi4WDx6TDhBoCd0afpZIA7mJIA0IB6w

r65A1kHRiwZS8mneSmqrKT3Ho+oG0De8XTJdqgRqBQFj3lF+VapJfkLUVJa67Sa7A484jFiOW3InmqkfO2BBrn/eSdZ7lmveOUhcBnv+YeZn/kuOYpGzAxFWkE2utLGaGKUu0CQmdrh8QVPaIkFl5DJBTHo5vmImQ4xz5mL6dxZvVxkHJkFVujZBTE8EdJIuvkFuJm0rEEpqgWIVuoFfIbIiR7sAfHEMedpgrl7zNgAHEnxgdQ5ErGu9rgFrJkG2

Q+Y164PdCguWLgGyjaA5AVH+Ul5h8k9qUZZ9tl6WDeylflauQsSR959sMEFnfFP+W5Z2HlpvJEFYdkg+SxZLCokoE8OutJ2+TSy2PlnBdUFFwW2uS+ZJQXvgiI0VwUs0rcFTrmYOU559PkYJMiY05Iw/CnpUTHIBW+IouitAEcAzrCmBf0FmXGSsYsZP7nRuV8YM9gwLAWwkdg5+bUoMwUPeYX5J/k0Bal59tnYZooYaF4jsLIeVfls2h6haBptO

eEFb7gHBbwhNRmxBQUg0jrm+ZAGjaE0hQhqdIUO+YUFC+krKRp5vVwMhWkFTIXe+bXRtVnj+UO6k/nNBXqYN151HHRJHHH81hLprASSALBB7QCd1uI86/kMVgw5wKJvGP8SjqgqYpIpi0SH+aiFVAUHGQDOZ/ld5qWOkJT0aFUq0OGq+UWmwaC35mwxj/n6KbsFczlj8OSFGJH6YW353fnbAR+C2yAMxmwcQ/k3oIMBboVahFVGdwXFBbfZhaxeh

a6FGIB+hRAFzLkB+UKFKsL9CDMcYFn8AnyxkoWi5FtsCQCkALCAk6xgToyZ7ZnIWSn56TndmVcEdqjZ+O0wi4FYIUd0KIXS+TqFU5kYhYsFC1GI7HRo6TiVQtOUchmSQDP5qzB1+SoZ3AW6+aSFVfgOhcD5izmg+fYioAW/+a6FqBCsnJwAHoWNoUOFJzk+haOFOlD+hQN564nqeQ8FGCJThYaJM4UUkM0AE4ULeYy5wTmQBU0Fcb6R1Jee8YWYt

pAhrNzd4gCAmgBjkYnxifl8+X/haTlWBaACwKJRnk+FWFhEJkmYBiTlhZQFcwWKuQsFNXEnybXuRXZ6Wdl5XOEh+GRAN9HWhUHZTundhfaFBIlGSQ9ZHrQAeqIFqlA+hQtmW4WW+SAFigXIRb0BEACoRfOFzIUYKWp5WClBhb1ciEWSBa6FuEURhY0FqlLRhW4QvLAyvCz5Q6wOoGn0nACmkVZAI2oHeTeFR3mE2ZYFgvlKhfac3DI5Qj00er7YT

nhon4WuBeiF1IEeBZXh20SjLKBFGApJKM2FvkBYQeZu7YVcBQchPrY6YREFsEWuUboZUo6bjqwImVpYUEj5gsBuBsgSe0IFBQRFRQVshcuFjuH6RaZFwOZ1BV9B5zF0+XSM0AUBKoJ0SvLxhfMAiXGfAGBAkgCD1EMALmZmBeGmQ1n3hbxFGTnq0NtuV5ox8Fo8HzyeEan4d3kuBWiF1AWSRbQFWnEAomvIgG75puHC/gVEEga49BqqRfshsVIf/

nr5K2C9hf+a/YXHBYNImykqHMFZYhynBSzSHfnliZYgQynzKfaJ35yQKbxZvSnDiUVZmYnPBbrSTUUPjq1FIylhhbccFkUyBUN5cgUjeY36PSl3iWhJvUWiSP1F1QWDRbspbUWjRX4xAeE0+X75LkUErFb60tp1KIHgRnQ0tHfAafTvAJ3iHEwswKOyCoUiNo+Fa5qH8ZxoaNzkGfq+DTC89tVA5j7VYEd+U5msaVJFL3n54LaoqiTgRDCROUVe4

tcYnZj1HCSFewXzKOVF+lqVRUeZeOCG9DxURSKeUYN2GhzChKRklVTzGosau1ohWqFk9KEjvHeMjITLysaSbmK+tDb0iMWCkfd2oqCNWhJkIPgcmtjF1MXD5HjFlRYExWGERMVABdim5mJ04hcqmLlA9k2gqMX55LTFWMXBWgzFmZpMxYSChf6sxZ3KGDnA2fyFmHqH/KiOu8qz2GesXkWRft55tXjHAJSs4IAmzhBZonHwCcn5FPbDBStKspixZ

ju6Lu7/QZARl5pSgqvIH0VsMZapSrmYhQtRFHirzs3udRig8V3y3ni82NzQsDhrEO6+3JCzHHDpnAVFRVxmffHrNgiY2kVSYO7kfOaScI+0ujxHmeD5D6DCxUSEm5BCgOUgpvRBhDo5M1plsjAA9BxKhOegyIjEiAB6ucBk+IT4AHr9Fq5QccqASSSxjBFBhKzFs+RRUWfE8+QiNCnFAbGf0OzG+gDZxSnFecX7Fm9op0CVxXXaQorzOqoIgsRIS

T0pxIjSOs3FJ0jj0AXF3cVwXKU6hVm8ibiIkyp8xFHskVk3eoEcCIiYANmchcX5OkTM88U3kKFZp5ZU8HhF6EW19sj5xfaJxcKEycW5xZwAacX/Kn45mcUhIB3F18VB6dPFRcXTxWXFOFAVxQpU9LEaObXFMWguIBAkjcWKNBPFQKhtxU/FWFCoiGXFvcXfxZpOJTqDxeCaQKgjxUhUY8VGOiAl9khTxV6IpcVuWo9Be8WZiUvFJMRyiTvhuvrrx

RiIm8WvxTvFAFS4JS6UyVmHxaPQaEUqeVGxVkVLhcRFZHJs6QnFDVpJxZ3FN8WrKvfF3jlZxTnFECXkJTyA78XYJZ/FBkgwJVXFP6E1xWuE/Mb1xYAl21xoJa3FtpTtxQIlXcVQJTwAfcW8+py6Q8UnSEglKIgoJTs6iiU0uSIlb2hrAXNFdUWLxRAAy8UoZOlZa8UMHBvFW8VwBJBQu8VWiXVFB8Wk+PQlVPk++TypgTHXuVSCTTn7VCgYmoFT/

q2AV06wUAaAP7FWQEF+wUWp4aFFPEVRuZv5XsyvvBq5XCDeqd6gblLPwHx6tEKQ2VWFqUUOxdJF4rT14FZyeriUTijip3SO1Pl5vqnbmSVF0EVlReHFH8m6RcqkgdJACDWspVTl/r+p2Qnidk1olzZWuSZazSW4lNRQJqRlRin+HSUdCV0liiEMJa4pyJn3BSwlA8r9JRep7UYjJeEAt6njJZ6kPIW/mTLFLrmmfhrOBKx5EYdpMvT5gEJhndxFs

GAJ3Tm9Of05gzkLQEKAoznjOd0AkzlMGeYFcSVDBan5SoV1KFAgfzxtsLLQ2EEOoe0w+7AfPDl8svk/RbISBXbFpm0w8ZD3HuMcvm4swW2CFWBB2vyQaySaLDZRgcX/SbOkL9HVufzhunBt9DYWtfIt+bLBeZFfmO/mdHymQHE5VkAJOUMAuqIqgfAyZrLePrmgodhCkNqBT7H5kQ1sKsHHgcAxq7lGfgrBkDb0bJu5V4EWfli+u7kUPDkkIKUy9

GCly1F1LgGgBNS85DClizhXuWhpX1GsuU66giL3sErRk+Bp9DFBQAHewDsA+gCrZuCFesWQhQL5CSWq6esmPTSpKNiubkZ0BItECWaiRIWwXal1loZZf4Vm6T+8Fum9TNAmWllfedVBVlGMPt6pEEUN+VBFkMVaRQZJv2YNJZgBsPAQmetoHcHfOKBp6/gKlFN+0gXwuUBp+VnvglGl7SAxpVt+3iV8hVsl2XT3WuDZznlz9tP5y0SaBFi4NbQ6g

Gn0CqBdOaQA0nQGgG6YYUGdckMALLR/Vq0AtvCsKVmFSfn6pcNZIXm/uc2CuYClbhO4yzBP4VMFMkyCdCXq2CSMWIClaUVYhcBEpRBJEjdZdNo18M6pO/m6gLcQhEHQ6UviQBjk0QV5otm2cd2BomGSqMoA0CEswKvgXVn4AD+AQgDtwBBApgHtAL+I3hLwAf5xmmHR0OmpHSo3SmsQ31ELOeFxHwWRcdKcsMACdCqlQg5qxV1EBoBPQNCAAIAPV

Dz5LaW3hak58SXQhXfplPxtTKHYFDhezMqmBsrBRn88WTL1EAdpdsW/hQgRLNnrMCGoSbBezKCyDGbutidAf1CdyIdZyKXIkWEF/qVkhfUlOhkhpS45BPngmWUM1OmdjCTpPOlhWqxlUemeiIT4U+lj6cSIOBnAYBSIhPg2GdPpygAUiGeAlcXKOezpt5nDxUAlFOg2mamZ6ZmTKpmZQQCTKmGZuZm84PmZE1DRmcWZbUZemRPpWwDxxTlR0mXMZ

cOqHGVWORHpYJm+6cSIPGXr6XxlyBm4GcSIwmW8ZRwA4mUSJZJlkVEQmbolsmUZWd8gFpmJ1kplNpmqZTmZzogaZV4gBZmTKkWZHpm6ZezF63EF9gxl2LnTwViZcJnUYBnFtISR6amZ1mWr6SJlgmXBZSgZjmXGGdll9IgSZUY5jGVOZF5l21wVWf6ZaZn+ZdaZIZlBZXo5oWVRmYWZMZklmW8FmyVYOZi4A8m4uH5ZPxnHRTUOf6Wm+F7QzEn0A

N8ARgCYBdPW2AUWBc8leYXz0dtuppp1BNneVxTjIaqCEXa0plIUJnQECb7GCaJagCq4ghR9TEDFnI7THArytW7epeRldlGUZXaFdSWBpY+ROkV0ZezReLEtSITp4aUACCVluvyE6WGEdMieSXeZRmlWOaaZIZmttKf4j4wWmZVlq4SD0E1loVlR/BImpADEgJ6ZlcUnmaIMX5lIum9l0mV6JfnFXohUJT5lAOXFkjAAWVnpAAcqq0UjKcpl3yD2H

IT4GOUg5VjlM2i6AGKA+OVkHMNFUlBDAJDlBMX2HGJOkiWlZdGleVLs0piZhbZs5YyEn2UdSN9ljJRISeTlawDY5QplIOWF6ODlyVmM5dDlsOUSJfDl7g4wuUjlUfw4mRTxyCXo5a4liVmY5SLllOWR7DTls8R05WgAROVWOaTlGuULRVrlgOU45S7geuUsDHMpIykM5f/wUOWF/szlAYXWRbMltkWs5U9l/UQvZTCZKirK5dJlH2W66F9liWk3o

ELlNpkU5S4caZni5V1okuX25d/5d4yy5UOhafzXmQrlSWlK5f/wKuVS8aPF6uW1RZrlwuUW5bjlrIhDRbblUlBG5STl5iW55WHl2uWW5dTlReV7KWgAseWO5VY5lEXdkWqiASXErEMcYWCh+YxFDEnnaRb4FABGAH2iR8zXRU027GLfvNX0UxCIeZEwWCFuUtBxOfhnTpB5hxn2pVhlFSl+zP2kUIZPRSuZSkU01BHB5RCnZUip9fl/9iO+EtmJU

tDFk76wxVSFaVoqCCRq56A8mnzlnTooKHjohOm4iCDlVLqaSI7cRLC+aLjgMdJcKn7l+6nDjrekHIrB5fIhPmU5Ovc6SoSgiGKR+mh66OFJ95mDSC7gBPqNoXdorSbUYLflgeXWCAfwj+XSZc/lNpmv5e0MoOi/aJzlOIy+5enl0mX/5a/Q7oqF/IrlwSAg5aAVnjrqOcdo0BUC5St68BXTCYuFREV4+e6SN3DIFWsaLfztSGEOieg85dgVIZm4F

e/lPmgu6N/lTiq/5WUMZBX4MCsq55nAFTQVt4RKhPQVfOWdtueZcBVigAgV24XKztKhxxHMcvmpYeGCcMCidWDHRZmF52kUAEHAqYac/g2xyTkw0aTJhsUyclzBGDL5gNnE6iRYIeWe1fRZWPPiuNglKSey5eHEWatyeBgN8OHYTaTVMWaFA4qPVi5K66VVJTr5NSVUZT2FNGUKOeCmaiD3oPixyaVegAqUpiDfOCkVrOXpFf1EWRUu5cwlHBWF0

DkVaRXSZRkVMAAFFW1lY/mZpcZmhbhdZcSZXxjbbl5F+kbnaQCA1vDWVrMAnEkxJZNlTyU6oQ4VHyJx+gs4rQgx8LvY7hVV9De0jxh6JMK4bgX2xTWFjtF33LdqsDj4OGEVvnSh9uxoayTT6CDsEMWXZUuliRUDhQuKw1zfYOVQC0jVJmzltkQP8EcVyKCMnA5BkTZvHOGhkypoFeFIbUbf9PeZi5YHfNpQOnbhoYQV1ITI5X/lXoq9oe5kp0zQ6

P5oa9DJpc9ludmWID/Z1ejKULuQNMBBad8AVxUnFYRKWHIfqeZcVxXBADcVj6THia6WjxV8FeURrxVGabSJQ1BfFa6WPxWSFSQVEJnxoQBkB6au6AiM4JVe5d/ZO3ZFIiP4VVCsABugrBUWjv357IXvgoiVU1DjkKcVYxHfiucV3lAWXNcVWsjYlfcVuJWfYPiVLxXB5cSVnxV1Wt8Vr2VSFZsMgJXNIKwAtJWglSAMYaWMlVt2pznjaLCVUwocl

dLFNRUdZYrAlYXVmeSBYoWavOORp4VLIGNl/7GtAPgAxDE9FXYVERkDFYLs6T44OOEhB4i9NMtlPQ75ZLc0jGi+FWXh05lHGfklL3nYGrg4fJKrFfuI4PHzktPg4IFbBdpJOwVYebsVYcXXZaNxtGW8QSkisPmigENwaACOJm5IoUmulpYIdAiPTMWEiuVPaAd8WxYACITgCigZ/miAKCiztojlllDraGoVrOgYFdjIp6k52ZigZ6CBWjW2HAk3m

YgACJwbnKhkHTL1WLSw2GQfNgog2SDjWsic4aUCZBUifyBNaUFpN4D5laSypDDFlSy64aHllegVVinVlVbotZXnFjuKDZV5jJFwzkTTdm2VCnZCgJ2VZejdlRjgPOUd6AOV/eRDlbIJI5UwJNq6LQmKKtQM/XD6IHOV2VqLlf1Ed6bZtt85T6mclXzOBwFu5dU8G5WY+VuVTdA7lU6Ud6llld64YQ7yFcwMJ5XVFq7ojZWXld8g15VUFbeVHXxVS

V2VaAiYFRCZL5VPehyVj47Dle3QX5W2Oj+VU5V/lbOV4wroxsBVCpSgVWgS4FUKGgy5OhUqCZ9RJxHaBbvKGc5H6bCq7QDjXgNlrAR0TM9ULuqfACShbpW9UbmFD4VRGa6QjNAIMUxGMXmg0npYDXK01GOIY6WRlTviYTKFsBEwRsEHZZvlMPSt8Z1iLakB2R2F6kVVdsUB1GVZle7pF+USAKgQJtLkmo+2Tzn7gt84blWSNCAknlUwuX+CMWXyB

a5VPNIeVVH88hVBVcoFS3nd7LmxdIyWlYMUbsL4WBD8xyWbPuz5EgD5yHulOtyHpTUAJ6VnpRelV6XXhbYVilUGxS8lEUVXsq5q7ZJStP74jkpebH2wS0DIMpb4u0r6VfMVJFkF4DCWHZgC3kh5OGVpeAOZQcR/TiJpeGieagHF++W2VTQCScb4fBpFWlZPpQLy4N6leccS+KWtuYVqJ7ESAGWl3wAVpcwAVaUswDWl71L1pcbOTaVDuVTazZiCk

GH6gaC6fHBxxaA77E6opEKzVT2IjKVNufVegDGYcaWRJn64cWu5+HHbufylx84A7uaA7VXsuf7MplYMbj1V9ya2LP1V6V6YMct5XjQNFYnaOLKKDsdFAr6n6fgAAdB9oqRWVDmHeQMFKTEGpVBlqulcEjAgdgSheCMSF0mAONLZATCBxOUQLVUOpctZtGgMqhG8FllrCFpuzYBIfD2IUoIPGSeROvBZkCmVQsmQRc/50jkwRU5Vm/RZfPXwh/JyN

gLBSmm3mWlEYpU5pegO4kri1aKVGJUPgnGlg3kJpQP5GCJNaXLVPFD/fA4ZBBl7hdPMRIG45itAOs6fRcWlG0npVSbE0IDNxjjZ3sBo4bqlxMkdmUpV4UX5hfH0hwTrZakoJnSG5BdJnNApggj0t2zqcfqFPYJRYHDi2fgwqa885HRgxWJEA57LRlzhjxjeLpzVDuk2hemVgPmn5WUBhkkKQGEhkEQBPkZy1TFCBdnCP6BdaHx5SbhWCJmhgnl35

ZlwGFXaZu9l4WThJqegBbae5QqUQWnkYHnV2nnvOQG43Eg7WsXVTxWl1Yjl5dX+5ZXVj/gRJjXV0mXhpZBV8snclTZFdpa51Yww+dUt1Zj5dVrt1fiVWkhd1bZIFdVSZH3V1dWJtrXVOOXN5bQp0Oo0RdYsiX576cWlgXqSVaLkCQB5wNCAVTbggN4ZySlMmXbVpVUzZYXyyu6NCM5SqpnCGc9F3KDtyIDiaD7T4AvlfDFzUdB58fhIfEtAQmz2k

IjiWiQ30REVdpqpMtQJ2vmhBUa5GZWkwa+lWKkHFZBy8QVvOQEiyLCakgRAwQD3oPM69JZRBscJ68Du/E8gJo6LQYvkdJpa6IJQdEiDQSqEr6T+1jdRjA7ROkgOXWjIegZ6TU4fAT8BHDVgeo+U+DoaJQpUJPCQofXadDXTAdfwliAsNcB6ojUBcNw194Ir4RJGFUhoNSUiGDWr5DFkBIK4NZEG9twENbTIjinydjm2pDWfGipQgQCUNQsBxAE1a

LQ1UvFDjAQOqIjSOkw1jDBiNZB6OwEcNcMBXDUGerw1eib44AI1qlBCNcKhIjUcALY1hFQSNXAAUjXAVMFV00WDSnI1TdXoNRKiVgDKNTg1zgZqNVzIwJDmAJo11ikkNaBA0IzkNRFwhjWsAcY1YVCeNRY1jDWF6L41wYD2NQ41/txONTw1xAj8NY0UuTWvAd+QPjWAeqw1/jWBNQ5UW9WQ1eR4xmJJJLKCIm6cuR1RFBLgQFRAzAC28KBlClU8S

XfVylX4BdmwC3TgREQcJAWPbOaoa0pBleokQ9S+1QEV5SoFdmeIWJZSXlQhUjD2WU8U6zAg0LHVLllplQD5vAVXZe0p5QFJFfn27mFbcQ+qb6oMiusAa9BIsF8c95BqjmE6liBYWmJqompwWtXKD/CpcMu+D6rBALiKBiAEgCh6XEB0uKgAVzWgtTI1m9BXNcrh2Gq3NUx5O+qPNSNJRVGvNZyUsiofNbDGMFq3ij81SKySagC1eooVDMC1pTqgt

WCoELUEgF8OitVsFaPVMFXomjC1xuFwtWRqCLUPNQYATzUJUXYmbzXotV81/4oYtTi1mGr/NRkABLVAtWC1RMwkteC1QrXQjlrVzrmDbARMI2ZB6txwYxXHRc2l52nWibVAnwBFODOy4IDNdJeFRgCb9vnImADrXsPlT3ElihkxlS7DNLFM7Zh9yOHu20QzHG6g0Wo40XCJ4Kn22WJujMqbwkKQW9EfFEw55m5aLHyS+9h18BhYtHjRFTA1T/li2

ZNV9lUdKhR4gCzwvJix5pWSQAqlilFNCDGQ3TVRKabV9dTP4EYAmBRDAEM1NtULyVNl/RVlVY7VwdhhqC54ycQ8jpgJrkp0aPZYIfbKrJtl6JbHosmmhfEutp95m1k23rtKgqxT4JHYuaICqHAghUUopcVFm7G1JXsV/NXrpA2AQSrv1mkKN8DCZq15bfbfOFO1qXDBNfMJo3lE+XO10VW0+UlY+37Rkv0ZxKzhYGEwhBjHReKpKbWFyLOI3QBWz

hvgsqnKAM4AfaIlIqvg7QAAgM4AV9W8+VxF/PntpRv5zhG/GS9shdSLlDDq3qCYhhJ+VNQkcANVpjzTxnL5FNo1ns1EaLR7uLnB6SFBClgkZiz9CBvlYQJOgC02wSE2VWpFfbX2cWipJP5h+MqmiDV7NBXUt/w0/uqp98YXMJ0AlwCCdE2AxACaAAOsH8aG5HOIeyhAcJKA09BW6sQAJEA91K2BYv4z1CAmUv4Q1aoJ4fL+jvJgsRiPqPg5YlVna

Sm1QBLhEO9SNGKGte8xorT/ElnxKBi7yQle5tozOLACmOnFgN7Zwpkpea1VXJKAOJupbfQJkH8R4RXc2Fs4gqw7FYnV+xXCZvrl4egyxFOmVugIBK/4baFUsJ22BACcAOqp/g6WdWloyOg2dX3ErWD2dWehSnY2UD6AtP74RRNFytU8lRgi7nWgal51IdznAL51MGQgdkcKgXXqqZvp7WXvpYf8cGHRhnvJdnzHReLpAIXEOd8AFAD0AKHAK7iul

dm1g1n2kWFFhqVtsQt41xmFgJ7UsKXpKPAs4WCg7CCuUQzf6SKZWnXlKjY8LPTfIvhlB2nEOERlqZBZgcHEBzUi2Uc1F2VmdUO1MQVS4WZis7UUupRKxICkUC3owSCNLG7AEmRPAQQALiDwmvKKtXkC+GH84WlIxa0gPyHsVFboeOAMmvk6W1B2yGZo+sjQfgNIHkSYurQoOFDzjKd1ITjiJZz6JVJ+aR/0O1KYDK2Enxq48Od6dImulrrojvxRd

a4SSBIYOo3kq1IYiP+gI2g+XFFw/cR0hNFoV0gKVKZpnXojaIGUXWhpILQoZw6ber1+nywAUEFps3WASmiUC3Wi6HaUK3X55J2M2QFs/q46woRHpqLFe3WtaQd1xfbHdbZQf2BndZg6eWGXde1wN3WZIHd1QlBYuo91B4zPdWc6EPUjeqgE1Lmfdd5QoIR6NcicOJWX+ED1YOSrFid1iBKUKhZJb3VQ9REmMPUsCnD1tkAI9aBASPUedZHoaWkDw

Rj1+ZqtCT/EuPV5UMPVFhnQVcUVAfxLtXN1pHkk9Ut1eZqrdZtSlPWbdTT1v6a4xQz1i1I8xYuEPFTK9dRg7PUozMS5BAg89cBiqDoC9RlcQvVs9S91ovVA+h91GAxfde/QP3V5abL1UpXy9cSQivU9UsyRKvVElIBg6vWfjJr1bKFcavD18oSI9SZpI2mo9Sb1jDCY9a/Qzw49xJb1+PWmlQCBuhX++bVylKaHaT74xlWE5gMCzEVgSB0A7wAAg

IkxpXWPJeV1kGUdpekxWsoM6kMZs7gcIDjaOiTFgHs2j7QAdbEaTglxIUClqzXpKmtR5lVoidVBxCbvMMJFPqWH5Y35vNWnNQb5lIXTdaHKTPUN9lR5b5BROii5s9mXqbfBv0gbcCsaVXm9eXN526FcwLJQY6Z9eZd6f2BcJRcgrghUsAxge4DowFE1JDozCrgcLApl1UvVt5n4iB96r6Sv6mEAbfYu0hH1gsTT2UFkKo5dymwcgLqGeYT5VXkP9

dXFRHlN1YvBhUjtwVyan/Wzeb6KHeRr0DeAWLq0DZUA8oR44MANdVryGg08UAyQDd1pjGCwDV/ii9UeZTIQSA1AVNc6VDDH6ugNXSWSduZJ2A2AEqSA1vV9+bb1wAWESLf1EPlLtSQNUiVkDc/1FA13wbcoH/XO/MwNQ6oIjIwNwOixIAANrhLsDc96nA3gDYIAsaFLaT1S/A2UFanl3dX7qSIN3Xrt0BINV7ZSDVqSMg0aOXINeA3SaltF9dF5e

HFVBKz3yfAUtqjqMmhWMOHtACfpx9VviDeAWUoUwAkAoIDwgMRpAgKdAPBmrOyggGwAkgAYwcM17yn21ZV1DDkKcX2CMgQzdLEeFPySsNX0QUqQbLHFJ/kb9X7V6jZTpdnEJLz65Ip1OUWZbjJcmnIVGAmRCHVF4JqBgbUhBcG1XYEBqTW58dDlQNA45wINuYtVv9E6fsrBxZHPVWylp4GZ4uu571UjMJAx1Mo3zgMuqiw1HKAYqJg1YMyucRhOo

FEa/jQlerKlvRlYeupS0iLrJCElVBlJhW+IgzV4QGc2w4BSdZWGMnXCVp1id6yZKtENNqih4IjsRp6luN6pcyFEISs1LUx1Ymq8fjRiMYpFZAL1MobkPbUUZXA1E3VnNSnVpimNJTr2aTy9JdzAmI1wuUrVeVkq1e7y2I1tPPgZUrWpdcO6RJllAFmgi5LtOMdF97V+uRaYeGFwAL8AmACcgs2lBQ3MmaM1DtUZKX04qnJmLOoWb9xGeA2AKfgHN

tdeMIl6hWCNGywBxLJKEfDzCPBlXfKyBAOy8NwnLJOZYQLTkue4QUqmdSc1g7UojUGl6vDo0nzeJ9zjePfJ2dUGZWwlRA3nFiT5ZjmlUtgEMDor/AgATuVEsa4xKPmieSZl+DD4QDaNMejAYQ6N87VIuSYxZ8V39ZD5ro3kYO6N+7YN1T2A3o1A2WaVZI2a+HuxSSS6eHV1KqWjGSm12tFfAEuAmACQ0eyNt9U79vm1GSmmDlU00JRJsAJ02lnQL

i1uN+5r9X4Vp/kSjQmiIx7bRHaaZlXOWDzu6gSVpC0c/rW6IgKQ4iQniJqNvrYJFZN1fwSfYhMkHWDOdkCwRvm0hO6NFvn6ZQmAWIRjjV75kyUOOSohiLku+Vb57VCLUjONXiW8hdrVkYV9GRSNEoCSsF5WB9WMReSZDw2mQKIACQC9RJlVbI1j9SFFE/XTZWM1xrXimFGetKVrzlN0FPzXbCJsQBgnLDzQFNXL5eCxzni1KAt4gpC5fOy2//Ibm

Ulgf2pVcU90AHSaxDklJ/VCjn6l8DVJ1QexkQn9jQaNQ43GjbjpkHIAenhW6wAL+OIFWE3ujT6Ni40YRXhNOE0rtdtFfiVN0bGNW7VHtPcZx0X1mSm1L5S8LCbYHHhvDShOCX41mKKCtfkRonnqW+xb3HUEpTRJiJdqX41gkU61FFLqLhO6SApbNfuIwE3vsKBN+0rRDSJpg7HhYEMN2wXx1cc13Y181TqNN2WhpPqN1KaoTVkQJo0YRQJS4QD4T

Z6F5Wg2RCZNC4VclUoNHMUAekZNuGEkTdUVbfX8VWyxW43SnBtAlCbfUcWlOsWn6aCAANaAAZgA0xksTUW++TRluejSZSxaLFqA/BIC8mnVhJgKcYs2Qk3/cX/pdqg7LGP6TAXiMY2NIE2uAq2NC5SIdWHYlSVBtapN43VajZmVmk3ZlYZMstC6TRquaE3wRZAcAHpbbJmoFk29JXVN5wC7gI1NuI1UtdZNsWXNTQ1NDk3bhU5FvKnkTa5Njnb9F

Lt4XkVSWZrGNEw3gJbYxIBASH9cQU044cW+vUxhIfew58CUdMdm05Ip7hJEdB4WqccmeSUddRTa9gzGcjMQVaoGdb500k1yYllN4E3PJqtE8pgIjedlSI3FTQg181UyachNlU1GjfpN6E1vOLZNhtT2TRdRXfmTkCIAv00ETWdBCgUAzSwAbU0j+d3JUY061Sy5243zQHaQGNx99e1ZE00WmK0A7LSkAO0AlwBhXPNNpgkavuKYC2TrMNmgybD0/

DaoBEZ8XFM0AFLEAglNhAk9gsOeuwin4l6yI6nnTc2NYE3yTexo6yRf3E3Sf3ljdQ9N6k0X9bilqM7lTQONlCZVTR9NNU3IlAB6FMBnIBDN0tUYRVLNJAC9Te1NVk2HwXb1CgXyzTLNyXXQzZuNXvFwzZgk6iz9yJ5NjEXw2fENe+bKAKHA+gDQgLbwAnI4zaF5IU142P50Eqx2BXfh9eZLlJe0Z+4YyXJaGGVNDTEK9gxcIOEkeaamhWdNYU0yT

ZdNbM2YwECwm9g0Pih1QcVRAeMN13IITZipSE06TYONos3CZqXFgZIyzf/5QIAZzYrNs42O+fONw3kLtegA6c3UiBrNJI3vBTDNFE26zco+qyR99eqp52krbHS4JthnpTbNnaUjJIA4AvLcoGZ02qysfrfsArCWqAwhEa4SRcX546ULUXWklNTVoDHBCkVMzcHNF00tjVdNCU4YCpT80E1nZYXBvM2aRY5VpU1PLK9NKc3vTWnN1rp/QLnNss3Fz

QfN2E2p1r35mCnUtarNGEVAgIfNldblzSl1lc1DTbjmjpCVpGpJYlVq2UeNoiiZisxJkoZxDWBlj7V3hZP1L7VVdRAYiQCd3ryktSiHcRtENCFa+NJMcxL8cNTNW2X6cvhwqTDpGK0o0XzyjTvswVJpGMqNHIFbYQ9m+U3DDYVN683VdpvNl/VfGTvNIs17zXHFs8SZBUjFwUghcEegPUjWjSeqXorhjVCw6QVxBUx2zSCMLTeQCzGsLbUaHC31W

ONF8aX4jWF17uX0Lbwtb3z8LSwtY41CLfaNnC2HKXKRTLlURbDNgEZh2Ks+KqWtYSbN4kr93JMAtvBkNPFB6NUQhYMFebX31eTJVwZdCJmuKBo9sIz03LB/atIi3GIbdBWN1YWU1Vpx0ky7uDyO/bBsJrWBNRjMzbJN2U2SMTe0feabmavNOIlFTXzN2o0ULbqZVC2GjfUoYs1dKQURijSHAKvgXo2cLTegq42XURMKaS3CLaSK441z6SyF0yWBh

dfNjfqpLektLRYFLZrNTk1OGYNNOs1xvgD0WaBncYxFhDlfzcBa3QBGvMYgCwA8KZmNOYWcjcUN5VWTsQAidRyPwC5+awLXsi6oyShWxVHwSC21tTz2Mkw3wMQmJoxmUUBNs80szXJNHIEQGP7g2xXczSQtPAVRLSVNMS1o6XEtek3CZtI6nAkv0N845y1IBsF1Yi3fWRIt1TzXLdyFkM1dGSoFLeUUprrNULK+eH31MTkptc8AIAHmbKCAsAmXj

bEl143mLbeNHzH8cDxwbqD+tV5SawIGoXyoN8B1HMM0P9XzBd7NgajVMICmkfDN6YHNUk1rLYEtC82MRruxnanQNcQt3NW2hciNRy3aGULNKE2pzc6F2c2lzYtSpcV3zSEGNJDiBQytIgBjjcytZ82srUHAwM20sXXJ1ro5zfeg3K1jjQ4GfK2kTcENdS2H/JRNbQJZWAXq7zDHRdy59E2fAPrGzSy+uq3N0/W9mUPIQrgdKFzNfGLeeMsIFQ4hx

HYtsxWYZcJNjsW8TVja2rA8trit9TAZTSHN881hzYEJru7lLEQtKk3krQnVj00Jzajp1K0nLXStLlUnzcsGAFSbBpOFBwYrBkcGhRXsFcoNUCnhrSGtka2OTQ0F7y0kIrKt0/kbGc6oElmaDO0AvrnnaXSZvwAvVMCZ0SUgrb0VYK19YZ6Vz3FXBtRCebC+bG0IhWKZMp8wpiSCPpoGXs1VjT2CWoY3sgKQgeBS5qiJAS2hzVj+QJ7rJJ6h4S3NK

V2F8RUaTVStHSk0rW9NCS10EbPEjPHDkX8gSPnzraHxriCiLXiN9y1j1TaOLsBJnPcoTSDKLYt5q7VypeotjnZmCv54ISXPuSjNtXi28BQAy0D0AOAyeNmcRRjVtDnPtYqFgy1XBtrK9pzlmL2wZrZVHELqvTTo3NJJpSl7Te4tE6Uu4me4iv5kQA/RDY29rU6tWP5TdLhSHAWjVah1wcXH5R+iPq1aGZOt/q00LYGtUBxewNONiIzSzUfN2S37k

Pht6s1HzRfNhEVXzTGtIjR4bSuNBG0KzffNkrUVzdrNMq26zVqAx1WiSWJVXnn0ja+5qMHMAO0AeMlFVT/h7pUoWQMtBbULeEkaNFkNKLkyAc6t8rySE83JiGKNaK2treo2VPzDDlxCxbnHkct08ZDhrnrwitAcgaf+akwrzUhtMc0kESHFJ+U0ZVOtu80zrUeZIjQVLZktdyC5LYotz/QAkItSBOXnkAdMZRSdRYo09m3OiOUteS0kbW5ttOXF5

SkIiylPmayFRRXUbT5tAW3zMbDBvm20bfeg7m2hbfut9QWqLcmtutVhOcKFF0BnwKiOxaVs+W0tusLPAJcAn1JY9KnWvS36xdmNFi2gAoJwhwRe2Hd00tmfRX8NzxQjsJZxanI22Zv1o82V4TM4R7k8bDLyPXHrUb2+U+CdYlbWw60I6XEV8E3mdUeZ2I1QtRiNFLXoKSF14i2brZvQ020tNTx1SpELRqMIu0peReH5l63EJOCAv1y70BwAQUXFr

SJtRQ3Y1VV1WsrhMCskPcjT4Hk5z0WU/P/y2ng4bquBuoXBbLJJGbm0gdayURjYJKRAmiLARexo5BiI9O7KXY0bzT2NW80IGThts7WF6DLAEA12DVZIz+BRADO1kPldaDDttg1QDTegCO3/FhRtTCXRrRzFUO0o7bDt6O2F9i/gq20CVU3RfxGsNgHaLLbHRQv5u23iUZrZ1FKrXpqtK8mvsr6gXxiBKsmwUU0vnpgaqcEPmJgtZq3orSVgOCA++

uO4Sfqg6SOIAWwkrowUP2ltYt7+8ZburamVey2jrRNtvY09kMkywKTObLAgEWqGXLix/o1qDZ/1ro206L8wbSBI+QxlLo2WjVkg6iBHemutHU0qzTGthmWo+YbtVu0m7Y5FvvlSrUet5O2ZbbyomDKaLN01SAV07awEoICHMFGq2AA59Mztr7Xw1uDQ1KRn0hT8bzAz2OWYqyScfLMtglYxCsTVbr6uuvwkIn4S7QeReaDS7b7FvkBa+EsAnZh3T

WvN+y2g7eOtAs1fGert/QgwIG55yqYGTengKdnO7QUt/g5BhEbttISrjdjtEW247bFlbe3N7auN1S1JrdvVYOFe7XeozZiFul5FegW6La5VxpHtwC9cRXXh7Rdt/caVoC3yOcGx7cq4b9y2Gt50elUC7SptpUL9xk3ix8CODKzK5NxKngWqWSjjsJ+NUcY5QA88Cu1c1b6lPNWlRdEtle26mdXtApAyWtrt+83ggIBAFWk6CL/EJTXWhGQc3+2iA

JkgpoQ5UUSwhADVDJQBiPqQKQB6wB2/7Vfw/+0AHYcq8B2gHTiU5ACOAFAdPcQy+nPkYW2qeTjtVG02TUo5P+0m8ngISB0AHUAdJB3BOCNwGB2QHRS62B2y+htFZVEZpTG116ij7TuNfbCwAsdFHQUptRTAqAXMANbwiLCL7SUNlNRMwXzyHNBqjVayuYAygmMsB8C2xbtNI80GVQFSK9pienmgnj52rZEMUZ6LLvquLG5YTmECuaaP6ZCBME3v/

v21Y638zfwFXlk3ZG/tmu117af2De2xrXupYNk28r/Es8QMHbcgOZyVTgbxBEw+VPi1+ooXLbNAo0HbxIuWbh35DuIFjh3+YH/tOB0/yW4d/txkHOEdE6qMVL4deIr+HYPQ0B04HW+QIR14HYwl3e2EHV1NOpVOHZEdGiCuHeQdD47xHZRqiR0CtX4dDDABHWkdBEAZHTAddQV8VbUtHu3t2hTtrnnGfPXguW2MRf8FAe2i5Omk1YBnPjeAD63FV

SM1lW0QraK0r7JC7iNkeSiIdSK42BoyBOHUrkrJ7dz2++2w4lKmmZgFsH044ZGoGuftOvDZOfntHxAOpjDCIO1kLWDtE62RCdYdte1GgtDh9h1lBTwt7gCzIpSpP6BZ4IxgQgzOSM3tSPlSLQ8d7Ww/oS8dzMjt7autj5n4HTkdnU0hVafFXx0EAI8dt+TPHUeQ/x0fHY0dATHt9TtF4PxtHQM82niHDchhjEUShbl1wUDvAPnItBnEgEcA3G3lb

W2lFXXnbSIdryTRwBCGiAo7+lowgDjVoCskTqF80Msd0w7jEItET2zmeMXtiHlZ7UBGOe0MaI/ABx0MaDWYKVXRzb21KG1xzf2W6G1yOWjplx0f7TmgOu1HUY7msJ2BIFkt4ym4diEAWSAFLV3txS2u5aUtUBx/HSqdpO0uTZrO7B2u1DwkymAhJYmFOJ0BQhR1vwAw7TOawh1vrZSdQVbgpQqMX7XOuCvaqZilNmf+rXVAbYod+02x+o2GUaTsj

qfaeuy8nXyoue0CnXWq5uJGcspNiu2erWpN5e3mHTh1qI1XbKF8Ne1ynThpR5nSOmLSVy1GOrmdUa25HWCdn2D5nTct6yWj+TUtINlyxSidpp3Y/gL2ZTZiVWgO52k1NjAaB4iOneJt2nwpCuswdEUwAkSe3tin4u+w9Q0pRf6dIG0LUR5WznYGJMr5oZ3tyD2IEZ38nT2x+h3FwJ4+0Q3GHaoZ422UrS/tMp3pne/tWu05oF/tVB2HkBAd1QxEz

D5ZCdFr0LQd1QzTxOedR5392YKtqB1/kDedpTqnnTPE152YHRqOr510Hfyt9UkKBfedh51vnU+dKZjZ0Vedf510HS+dIF0PMJKtzkXSrTWd0pwEOCgRU/7QwGAJnwBjyZ+xYEAJ+SMdhQ39LeSdb62BUmOIMCCbOJWFG0R33NtkGApZKFsdu+3/1frWzZbaRidNVxkznZLtkZ26AX7keU3UcXftcdUJnZEtSZ3P7RYdnTGw4hdAO522HQqdiwb5H

REdThy4irAomYBSSCK1lR2v0MBdJTCmTWUdmSBiXQS1El2zQFJdAFRJHWBd8l2WTVBVdu1EHYpdi0UyXapd6gDqXWY0gLVyXeAgkF0DTS0dJp0aouhYMfAvdDS03pj2lW+xEECsaAIdGY0nbSVVYx1cjfxJQxzkdGDsq3TpOImmXlZpqrrO6iRTEHvpLa2UXd0GwagdGGUsVUJ0Xdntc51iJAudJyS26c7Nq52dheud3q2WbbKdu50psLOt260si

Luti62OjS45y617rUCd2R06nZFtHMVkHJVdZV1GnXoVrR21nUd078qNITW0iCCnRcTqieHkQONlLs6nbVhdU/Us7Sg29iidCJPNh0p1EAey0cA0/F50E+IM2T+Fgu1wcP742C0q6rRZcZVRqPRdfJ2pXTLtJ3g6PLACVnGjbdUlph0q7eDtVh3bnTYd1x1CXcktLfzZxaKAIB25mb+dQu40siolD12/7aiIz12JMF+dtclPUW9dB52fXQedL11WX

b4lNl3yxbWd0JR1HNydndyqgGn0kFLEuOQ5iYYPJVeNqfF4BXeNcDTYJOAZwLJrAst0sNKQbuO1LJ3sYULtiKK3GVUx053JXc6o8517Xbq4iZAWMmxdhzVK7TldBy1PTSup0QV/BPldgl1VRSolEkrOiAZdg0gLDFKA3KSJMOVdGA7c3d4dqIh83WSUJixvkH2C1V1TJU75C40gzRsxj8V0ztmluZmS3QLdMt3C3c1dHfW2XfVy6T7XGAhdQnLna

fgA3QAn1AqgQwCr6O2duY2QwjwZJwQVMJb+JHCjLB6m+8iPjYTdu5H1sPhwIXjZdtU0TTnOWGftakwX7dk5+C0iJGYKR10mbWKdsc0YpZKdeV2XXVcdn+22bYo0713BACKJsJ3ksrCd/12PXQncnh0G5WggC+IRqFwtGA7J3RpKfx3p3Rqdmd2/7bEd+uUhbXndALDagFkd8t0FzVNFRc1QHMXdqd0anWXd/CXF3dnd1d115bXdp8DV0a31Q+2tN

SQiqJ3T+YAi0CCZrWV0eUCUWpaRHVGTAIQAZW1eXaMdUg7lrXeNq8Jg7MkYgCxoopRCPqCXtGkwgcya7KitS1177QqsNZ5JYBUQEeA+9tsdObCB3XsdiJgcgQuSbryuGVlddlUADplOyZ3PTYJmfF0a7fHd8p1VRRJK7d2BLMRQ/CU83TndNd0XSoXdRdFq3UA9pbIZ3dnFYD293W1FkD027crNSWFK3Y36gD2l3SA9Kt2IPTblfd0oPQidC0mg3

Qow/KnxVbWdVKRmtQdpXV0MmedpsIAcAN0A31YY2dmt+chGAN8AaZbtABmS/kW7zNbd/EnDXrNycwTiSQKQ7NCkQLWKEHk82DEari3Abd+NHi1F1Cc8fNiI7NA+PuS9sKoEQWoj4bfmfLahRjIElbm5uHZxU1XFAbli+bCv1Txd9aL6ITK13awQ3cswMCw9sV1doGXnaVZA+J3fAJm+EmHayMtA0xmmYOVKTw68PeTJTp5RGIq0/fIHaXUQ6fki4

If5Kiy2pX68I50yPViF+bCS+TVgoXiaouy28ZartIy2kXk4EVsIAZz14Peir93jVepWobXv3fa0jSom7GuGX90tSk/N0PSJ5spqOSjRbF3lmryOEGn0HADnpc5xO+jyVcvdmF0+XWJtGSlmFtCtLRCrPvUoWFILZFGkQ4Ap8B0Nr20n3TFd1EYH2g8YrbCbqQuS4ZGrzpfRBDgPrAN1nxgK0BPgpK0erQ/tFK0TioY9qhY0ZWVgkU0/RpnVNx2fT

cOQLxhsHEgQWRTanQrdhc2+jWVYWRTfjkENUF1g3Q1Zt7n10onU+bCGzbU9/WU8bV1Ed6ChwK9U+EA9La09HI3tPdhd4m25sMskYyyf1FKs5qXauLxEiZBGdBwUkyzu3Z7JGK20aDROxeBinq4ZDY1U/LUcyljBQUixRabf1eXw6z3xnZs9Xq3M3VKdeHmzTPGov8xthXtuAXiJLeiNhdCtDGv43zisvT35a4loPU45GD2DSt6AmyJMbY/NLG1x6

dDVJyKk/NrwTl3ZvudpMsDGUvoABi2XADP+JJ1mLWWtOY18PZQm8WD+2v8u7p0ScJluvbAyItbZ1qGgjeM9c8at8p50w4aXGey26xUT9Gaop7QjdQflsE2P7QO1hy2bndoZFzXpskE2vzCNImYILLoZyhglegDUSi4SSZrcnPZhILqapKhAL/jNGlPQiSIGjjwtuTrUKiVSbx0QZAG95SBYckdIvHZR/P69wQB7Qmj6oCmQELC5E41DQuM6txw/9

AE4Pr2ayNHlBUicMP64Qb12lGE6DCrhvYv4Nxpfdir8Sbb89bsa5irV7Jm9Vb2cAKm9Cojpvf/wXb3ZveqV9hL5vYUtlkUgnXpdve0yUMW9AyKlvchVX5EVvcm91b1m9cEgdb0yKg291JrNvTG9MPb7HFi6kiqdvZW9jyC9vb7yFsjc5YO9WFDxoSO9vFWInc5NLV3Q9LUhxKwYNl5W8AXBNAkAPeUptSSAVkC28MKGZkbePdVt6DGQlhcUgOIWn

EFmr9xJiNmQ6bDH3eGVS+UWrY7RuYFezABSya7NVRwmXNAhxGeYDbBDzU3qyRhxXr7+x12xFaddG50mPWa5DRJsJlMQj7QTqes5R6BBlhegtxyPkEpIwCCGJrk6dlrzMMzI/4q4iJ2MDb1SSBrIVkgnkCBcqlDX8F0M53AFCbMKvor88JWV573noDoghODQIq9Z0IivHUBQnr10fSfQSYCMfXu9Hb0sLWx9HH3kACwcp0g8fbZICZruOEe9ZjRCf

T0JahGifdBQ2WgSfYBgUn1TaDJ9hZ2gnSE1o1ByfZNQin2pjAx9jSZxvfu9Gn1Qiux9w6qcfbp9hoT6fRuchn0pvcZ9ZgDCffc5ln2HvVhQNn0vYHZ9gQ0sHdGNG9g5JfAUwCK0pqf2XV1mFSm1tvDYAAZSjdA/iH+9ShbK1kCu4ikNrVK5SrjtlCam5wL4aK/2oz2Vjca9TCbeeI21dNU40nVCb4ZqWCudeH2wNWXtpx0V7UR9rfk4bQ7tM3b46

rxkYgqCiHIlUD1+jQxlw32JaFngKFGQ6AAlDd1zjfnRNz2ETafF033OjiN9c33CkWcAi30pbU0dVZ11FX0U1El7YoHkHmwIXa0VKbWYYUIAdyU4APLpAC1Prcd5L603RUV9RnIE1Cmw4H2gqa4MkKkn0tV9caiR1Qod7gWdbZeyMWaScEiYZwKUWXRS5qYyItAWJx0OVWcdLr1INVVFW33QUL1Ws8RJ3MRtKP2zxUwO6P0/XcvpT1FY/etWuP0g3

Uid0F2a+Cd9RFoWoSEVStEJAGtG0+22NjeA1CToQoR1wL1Zjavdqr0+PXokLTjOApz88tqkzdbik83exQeyhFnjyNI9sH2Xss2YuGVQqk1iZX5PdF50wrzH9V19PM09ffD9fX0pnbqNbr0etBzRvAraAKEgtxyjxG4OlZyzfW22x7ZtvYia6n0TWpN9p8X4sTr9ev1orIb9u2jG/WZFviK7ve29LH3V7P+KqD26Xeg9Aq2mjazltv2evQb9WQ6O/

aN9rb2efRb9sir7fTe9zR2XDYf8FP2jumaGHtlOXQbOKbWvHJgAbAD9ubbwCNUPtY993EU3jb5dPj3Vho6hZgrVELwZ1QZVfUL9tX25JZE94v2yEgbe7zApYARlwMXj5rDAXZ67LRxdpC2q/Z/drN0CBYSJJz2TMVj9yLb/iqiIAf23HIT9Wyq8AAcqKXKWIAaAByrtAFfgLfqKNIP9ZvlQiiP9Amp2/eP9IyqT/ZFy3KRz/Qv9Ol0j1Q59Ld0iN

Mv9w/2oAKP9WSBO/bvq2/0pcrv9DTD7/doV0f2Hff+GnWArSdmQhdQ0/RJVPz2m+BvgWVhgQIAofQUmLXqlyr2TkQX9/71fYu7kXtg1+mMsjPSXwhtAh5q85Ci9C2EHJCc87HyuyvJiMI0ZwCE9BWLt/eS9iZ29fd39UQW9/XBFSS2QHPYpCClFEUj53im2/P4peP2JmS451AMUA4vQKW39TSQ9AFlx/e65l1gi7DAqZgpOXWlVBW2fYGBSygBkg

NCAMsDGzQ99pi2Y1c99I+XGtdEeu7gOqG6dJM0ngHAgaq4Y3scEwv1IA7VxpB6K2C/2m12oILlFiNjkIeDFuAOn9XBNhH3q/VpNwaW5lZMxs0U6/eqEg1CvQTglWymkJRSIqEnwxuURZYmX/aN9Q/3jCjSytgMCavYDT0FOA30pLgNzRe4DbUaeA6f9vgP2fZO9xZ1dRef9AQNTxI4DZiVTKaEDbgOm4R4Dn4leA1ngPgMEgEPdaW3D7bbBnANvP

TUwzm40/dn93/1L+QaAFMAG8QqglwBghUADttV9LaC9I13OEZPd/9Qt8joyyliFYp00v32V/QD9fp1A/UodLKRmbg6c7oIwsa7ZLAV+5GDsH9Ev3Ur9jN0Efbldqu0kA8y992X4PW1FYKj9jjOOqCknwFb9Bfa53ZsDn447A4PdMQM+/d+dfo0HA+uO2wOZnLsDLANu7U89sf3g/MUDOsQv9u9xTl0m1QIDs5qEANCApAAJ8d5NOf2SA8+tZJ2tA

1V1EahU3qVMTp6w/aEyDQgPmA48xnhKbf4VDX0AsgS2N5roGF7kzAWrmU90xTSvbBtZvXFkvaYDjr1mHdxdFgPZlZr9kBzcwGr2dAOyERSDJP23vbrdB3HPA740an4E8jDdR9WVA6LkPdbtAD/5QIDzZoV9z3ExTLJFUe7EQIRdgBqnohFgRhXtMDW1Ke0KrHWkOCDdSmLtlr35umsEKkVw/SgBVL1s3X394s09MWBWwoR2/TTxA7bUYAB6m4pEz

POAEjWv0P2qmLULkOaDaAB6g1xgxAh6/WgAuIgXqsJqmgCmXe81LoPVylDJs9A0fbWMQda1NagARoNRyiaDc4Bmg8YqloM2CMYqtoOmNQ6Dg0jOg64croOlOu6D8YOeg6cDPL2+/crdFQA+g/qD3jUBgwBKwYOhgxaDGwYRg/2qUYP2g78wjoNxg5uQCYMYtYmDNqzuKn1N9wPWXY8DJmaaRryoqlj3rJidtT36ySm184j5rRF+ocBf/Uq9UgPAg

yAtJQ3NRGREzEQyVluIFfJymavmXnTneJoDJ8lKcRGoQDRcYv9tGZDiRMXgZXrzAx39Kv1hmn3mStg3cocF5+XX9W84QB2cAOrAePqm4RcW2EnAyHsD54PyOmsgV4MLWDeDQomOSEt9+c0rfc3dtz0F9l6Aj4PQ4M+D+XDg6LeD74N3Az4lpP3PPZP5bG2GmCDQqYgw3ePJKbVQMjAAzaD90T6mQ4NAg8Atr63gvUbk9aStELCiQYHKLLMe9x6tg

PRCe1kUXXbZngV33Ooye8gUeGaMsJEQTeye+8j03aN1CwPodUDJB4PnuCD0JT1X9fkRYdFl/KvgL4ktSCqd9okCiSBDuElvic5INLJewAJDYkMooM6I44lTCYJDJd3TiVkgVIM8WfxDSkOanZAlWElvg+JDKkNzSZtFiX1lPQdxcbV3rKhoSchOXUq1KbUywPbOoIDtwG1AwK2NAzm1fRUqvVVtShb+NO7M8fbWTNA4Rnje+Og+10TwLQiD9X0UQ

47RVPx24kJp4ajHkQYDsilTDaqD/soHg0lgA4HHg669yDVngw9lriAX/UH9XDq7Qi79EUhqfe79eQVQikj5Nv3r/YH9YKwO/c79hSJm/fG9wGrkYJ79ct3LfbIFa3HFndr9pUP6/eVDwf2VQ/vwrv3m/QVD+DD1Q/kDu4XCvZr4OKVHcUQctZikmfSmmQhp9EgQepGTAJIAG+ANA4+tgINPfSODWEOdPZDCFKqznU0IK6IFsOVg1UCNRJlqUH1uL

VE9ngXCmOu0x9qMzfRDkvSWTEh8ernZPeKd0d2XOKEtHTaTbThtIjSR7MJDOQCTKiDlQWWTKpqUf0OjRh9wqmX38N3Yt6ZECFMqNLKfQ86I30MQAL9DdplNRgDDCMOFRpo4gMO1WJMqD/1Kzd79aYPnA4360MNDKj9DgWXIw4KAe6SAw7oIaMPgw8oAGMODQ28thQOSnPH9CekIzX9QNP03KeyD2ZSXACbOCADfiLYRrP3NA+z9bkP8g7Ag733oa

I1qpMHxuuR0huqYbNEYdrWDA3MVo52V4QsI+C73Hn9tfGGkAkY9QBol7REtnf37g+gDe0WI/ec1qUNJmUpDxZKqEMJDo/2KSDJDukNW/CdSvSUiNMbD+MMJA2eqdv3SQ5pDn0NqQ0LOAVCyQybDRRZr/U7DZUOWw86J74Nuw5GNlZ2yxUd96cD9bYdp3xj5gIOwMN37tQIDRgDggGSAYAjP4HJ86EOrQ5hDL32Cw52KK0D+4LhmIV2uzfg4aArIo

jl+wUOOtbWFNZ4hPRBst/5+LZiDkvRyTHhZh0oPQ1HdO1GFqKEt9x5JQxSFToWDfRWJCIjltsXRVAOylEwDS45e/Yf9sQMhNeQD/cOUA67t4EN0g8idk/kQ3dTWPCQMRbU9M/7naZwAYUHMIr8Air28wxVt/MPjHRX04rBs7fUYjFiR4EqxIaLgsqW4wlquugq5ZcNLWelFyriG7OhoMMBNtc39ejYTqUXgkcPNw2ZtqG13yKEtHZ5vQ6eDSZn+A

2eqgQOOAzQKlCWm5byJAvhRaF7DwcPsWaxZvsM5aWAjTVYQI+XlZuW7dfbDpsPuw48FiCOOw8gjSQOoI3PFUCM3kJgjcCPYIyHDw91rbQH5ZynPsPy2FHifPa+9eGkptRTgtpiZDebEfIPGtRPg0p5AGBvRtaKuDFIU3+iaLJQF5/7kQ+XDleGQ7K9JZ0CbNdbpCVaR2CH5cUOP2qEtSyTqg8QDt2XWA2sDBuUs5VojqYPO+by9wW115Trd88OFu

LrNxyxitNayCF0idQIDGRySAAp0sqniA+nDef3grWAD7kNTdDmw7hFRwiS2mUJNCE9pOtCQ0t+Fd8MfbSzZA/QVLGp1lTBC9lD90wM84VDAcZ337QSDWz0hFn3mReB15iSDzlVAI99hs5rfAA723zhHAJkj2SO6I4rd6YPoALkjd3H5I4mtBQMj3apSpkONECtqolVTQzl1vR0r6BBAohS4AET2nCMfMa3qO+xEHD2IlRCYCcD0TLYZmH04d1m3w

ydDtf1GBF2widT4WOOIXgkEhZL0z5rukD3Nop2IjXuD8UP8RL8ZgCO8Q8iU676T7NmaN744IyfBeyO0gzH97APg/H6BW7XPmh8wnLkpDSmSMqBsADqAnXTtI6K0oBiq3inOyfDekOIiF7QcfrykB86Lg2bpbuQg7FFggO0tfVaG9cMdg2RlEd3LI8rtnUJJI4ilGyP00UJG8TRFSt8AFt0ywNh+/g4UwIijPwAoo9h+Vz1N3c1DITUYo98WWKNDA

KijRiNk/YW4fHWK2fxdvfJOXf/N52nEgInh5tUfVMm+jiNPtWtDWcNcI2Fgl7QZCkLa9KVz4gV2S5QrgzrwP2mA/XLDp0Mcyfng5H0rQNSekcOGdRmQ2TI0QoojavRJI6pYqiOWHVN1myP2IpMZCqCBeRu+LMDfAEMAX/3+DtqjuqMswPqjhqP7I+7yJqPewHqjBqNf/YPtFSPUI3mxlKMendygcUww3fcN1p3oAACAFsz4AP05LrCPIxX02/Hq7

EJs4NAFsH0j9elLODBC8ZYHiL8j4LEkcZ4MIBZPZuuDRyxryN4Vdr1jVY9DrcP8qmqjZXkWdSLdWwCjwzb148Mt3WBDRkPDQxvYor1WdAa0gPTxhQkAdI3naf/+FMDewN7AkwA6o4GjM7R7uC0oW02yYi3WRzwNgJ0+txgGePJNbXWadfLDvkoogxmYaIPspDCNzNXbbt6+38NH5RKdOaNwo/YdNIONoeujty3rrXa5Dy2sxkncDqNDQ2Y9at1US

VWjDUQwdXMSdaNJjQIDs/qSAHe1cADQgGriwtzOAFdizABdOVAAcKQr/rvDpJ2ZwzIDHSPS2aUQ997vGIZ4j2zn0Wz0wbL06iL9yXkRlQGdQUan8e21hcB9BvLa9NoNCH88y8Ns9LU0bZgkZWjWOj282mMNT0MveLlikzSEva+lCz6tYP1eeXSvPQdgouAT4N6pXV2HjV6jEADOANkB+ACmkQv+BUo6o42lJsnOALy5HAIdowl+uyxY2DPg8pjc0

MqRrrzlpCpJs+jZOeE9VOFjo+KjJFnaMujcEZ016sqRzlh1QkpsHRhKoyw4wKSZmIjsFjabDbeBAqU4FmzZNWDGGEgqfF5lbLveloAPPJlAlaQKjMyuFmN2gYn4JuwLwqEMMCxr8VzuyZgheN0kExDOvdvOvB5EnhVg+jLU1mOIQEF+Y4yeK7QTubwyGlkhHg5jRN4TFSojLzBqBD9usWMUPOzKvu1sMm7CSYjuY1WuB9rkOLXmevDMqtljnc6n8

WyOVq43GNVsKWOhbvx+tPS5prLQo2yGY/FuAlqnwETUKfjxkYCSlWPxbl2wtTTPI7rwFRgxYy+uh8CqWCz03rWluEVjAOpf6NlsiaK5psQmY2MMbmbkEdgncTseaQrkNh1jXO43WPrsVTA5QGz0clZhY9Z+F7Q5uXcYYmnpLqtjVa50dOZu5Z4T4ifSs2OXruSi1lnoWHYBjn4nY53OSzkH+hS+6Ar2YwmuwkRTNbbiu3g92t9Vu952qLTUnO1rB

O2Y7WMx3iYsu4j7EtE+YOOcbgzeybrF4HsUqlHXY8YQCfDJul+sIXh1bcjj2LTpjs3uqyF5KDMtDWNrY0Seq+Z8qMsI/cjHYwmuy3TNRNF8I7C5ZB9jE97LyKmu+L202FjjphD3PEvD1q3tKJSGu2MObnKZ9W2VoHUogPSs46IUbUzxjX/MK2DJY4VualmqggVAvKOS4+auCmNh+M6oymPy4xlun2KKY8rjstA7Y0vOVL7pqehx1xJLDch0DL4IA

FM+zL5JZKy+PV6tSn1elAA8PLvV16i+ztHw7HG1PXRNAgNsAFNNpsm6BabY+gDn6CaRpqLd0jAAnwAldU5DZXWo3WvdHSMbTSpR5uoU1KXpIWAzHByd1KZBQ99FwP116Y6gczgNQGw23yk+5Je0t64dGNKNDZ73wlaoLTaawyOtTN06Ydpj+9JZkT39QdH6Y+8SrOOtNqd0zQjJQkbsJuzY3oDKifQOyW+8Ca73SlmQCe38rOjcreMwvjssD1YL7

oyeUxL3rAapwQLLOQPjeriTlJsVIl48mIZM2jCQCsBEp8M53m3jQ+Nz4+YeyTKi9gsj+aLKbq02g+Oz49lsbZ6S+SOwvOT5Kli0J97r40fjneMmXgDilRDsgXes3CDT4/PiN+Mj40Te6Y5ryBejMDhRMHkRZt7X4x3j7+MUPKAKSfRQ1Is4ZRBIsf/jh+OAE/Pj/+Bv6W0IjD7nwBReV+PQE8PjsBPCsO7MD7If1OYWPZRQEzPjMBNuLmSkzNoUo

j3IWt4AE2gTFS5RGGaGAPSqgu6QL+Pt4xQTly5Rni6gjMlEhg6yw9gH4/gTjBM7rtywt3RD1G6ukoMcE/WkXBOb42iuTJBFwHUEBbB8cPQTG+PH4wMuVRwsIW0IUjYyE2/j6BO0rvqpntEentpGKhMEEy6uOiS2gO9e2ZC4RjoT3BMt3lMSXthK/irYQR4hHkjK5BOiEyRueV6QChjSu3h3UiYT9hMt3pA4Mxw+2BKweqluE3ITJG4NCJdqV94tj

R6QfhO34yRuO7jSTMlCF91AGA2unBOv47oTERPC9CiYiy5MXRxs8RMME+4TAOPAGA7BEeBbZBGeKBMiE/4TLd5vHnjYmcTsPiLaQhN2E8UTu96mnKzQEl5R8K8wYRNAE6Fu/8KgOOosl/HKAnguzN5YGBvJp+JqEyjjlS5/ap0ozYBpntnj87R9E3O4AxPY42cUi5ToaG68RkTenuMTvRMh+lMTlOMzLPMT3KATJFiiEV7LE4bsqxPm7JTjbO09y

BPipiS9NrQuPRP7E3njLRPxbtTVCgSmeD7OazjdE4uUKxPXE9MTbONlGNhpCziCsAUTv1WXE7nj5IE3E2tjQZ15oCluh96Q2c8TOeOTE4cTCuMu4uWYWCS9pbHBkJMTEwcTQJOnY3/USfj+bmsEU9K5XnsTAJP9Ey/eIBEDHFHtvOS4k/8T0JNok53OnYrYaP0UvKSRMMgTfxMvE1cTgJPvExAY+97yrZJwYOzLnniTFJOsk3gYMEPVYMXAdFm7E

+STqJN8k6/cW7qKtMzDFxNMk/iTaxPmrs54Y7B7ymh9PUoik7KTvJM3brxEePL3XI/AaQoyk1CTYpOak0LuJrSDgjvuYxOik28TmpPJMqkoxyxANLVVH2rBwQaTlpNvbljYixNfYnxcgqkOkzyThpNvbh+t6eNZISos+pMok86T0O6p42jcYxITqYGTapNOkyyTdV4bak9VRoGtbB3Ekz5MvkbUnV6pk3M+BZCkYzJsNuMQQlhcla3X9jDd/wNsw

6ZA0uRm+avgsICZtWmFxIDagDeA3wDtAF/mQIBfiHxjhZbM+Vea/vgLzDsIBGY/vDvWpbgCSYtdgSPPeTviVWye4t6R6KJUcCHCxeNjbYsDpfraY+0cleNEA9XjBHE1kXXjY5PwWN6RcZOtkEu5IDaHQMbjpuNpkyy+GZNsvkZm1uM7JYrCtCMeufQUCJhO46+9402lxjRMU+y/AN3iPeKTAPnICQGtI4rcZsZogA6ALZMavnIdMwQdaqEMwVauv

LmA9lgxMLDStNxiI/fDWIXcsC0QbfQ5fFqGKmMpkHVCQiGgTaS9cSMOvQkjZeOo1LEI2GyLk8XOy5NQMdsNO655+S2wQtls9FpRrOPmgELu0lznmLmw9OM7rvvAIBHLlFDdP0YMUz9VxONukevI1xitdoTjVa49PuR0rzC3EEmw3rl8UwwWC3j67DowXcJqBlRTpG60Ht9xcaiaudAxvB5kdFssaRj1Ez3yFWOkLmR07ry7eNmOdQTXGLJT+nyVH

ALyjZGQU/9jjJ5kdN2Gm9gA9DcECciyU/hw+5p8eqwed1Y84zgW5oDBqFgTQjkAxS9tblPr8QkwWjzPwJrEaumyU4aMDSgxkCmwOyxUU7duYfhIrZvCyUXEUz9VQO4d4QBSt7ToWNFT+NSJ7SosQBYFQBlTmSjh4D2wQEaVExZTe7kwZVrKN206AaMI0VMeRuEkUWDv0skY0VPnQ5W1gpAuviS2flNc7hlALDxNEBbpySHmU8pTllONEG7afJI6A

5fjT2OqLumOR5EMBKeYEm4644xTroER4DEIgPRoLC+Bs1NJU4/Djq6CFGq4i85jU74utGgDskLaYLCZQCtj2lOvsr7g9pwNKbmmdS47U6YuENT1Yn3j/b5PE6tTKlOU1FIZDCEhxJfJ2L7aYQSg25NqwbuTyZOMvl1sB5Pm40eTluNGZmQ9BKxGmAtGU3TmqDU9r73IzfeTFphOmJcAsIC4Vm1oHABGDEYAiSByqBTAhUoMmayjQC35/R09ar2hv

KLgoBZtsImmWCC/zCCytKWTlDtNssPmrYlNHi3c0HdudRzc1gaY57R4GDTJwzTWTph9jEYNrdTs6FPsXQ/tIbVbEmG18UMuoFiustnpbYsyduPtsRZyrQhOXeID52mewLT9bl3WzMjdoK2h4xz91W2xvD02zBYPGIGgy2U9Nt8YiZBX3u6pjgm0tsnjAVJf6IOuDHTfPK88Ru7AEZk48m0bYS5uw40mA5hTFL1cXc69/X0RFu6aazCbwgGcOm6Gw

+poB74VAIDNayUFvSZaYdOz0BHTPSVYw2PDZwO/XXqkMdPAdpJgRyPP/XVhlGPUWM4Fp+JOXfXN9E0+ozLAzjLU6L+Txb7e2G50UNSI4lK0vBmXujMQ5Z55KDIppcOgsdBTngXO1UOyizhXQ+HCZ1h18EXgzmwLozuDeAOcXQQDxIPcQ93D6SOT6U4qnADOAFeg7tDh000Au/ACfWb9p6kR0/44bwpsVAeQpIBUMMp9bECdiblImGCMwINIBoktx

Fdosij4UQVwdLDzqjYSo8TgJAgpadMMVV5oVLpDjoMaVQy3HN1808FxvfPTrABr05uAfzkg6BFoMdbZILvTbACNANgd//CBFGT4X9PnoE5OS/hIxVQwQWm2SBY6s9POAFAzi9NGSPd1r9CoMzn8zkQb02b029OJgMAzC5DXSAfTy7Yg+F2JJ9NtFu/ZGOh0sNZIA04301PE/cP30z/TdEo1tig6J1Bv0yt8DeSf07HTC9PYM0RKT3Xe6KDoPtZAM

4X+IDOP+IaJEDPgmXHT1GAwM/uQcDNwAAoNl81H/T+DiDPT08gzWDMbSBgzUjO8M1RKqwyv+FvT+v3kAIQzb9AkM5sxx9NRIOsWaTbUM33DBaFHSGist9OMM6vTfDNP0zdwbDPmYe/TXDNYuhozO0hV6P/Tvug6+ud2YjMz+BIzMehQM4BgsjNewPIz173EPRBDzYMx9NnTwNBQsj1kTl2fzQxjePRPAIPWFMBoQ1+jIANyUetDar0PakBGwaB43

omm4NCyRQ3TeaDbbss1SIM5ejO4etBJIyr5vnQJlYPyFQ4sIZpjaG2ro/39BSCqiSYqDIRhMxwAf6pPGszMTyDv0wMaCARHCg4z7fhMM3wzd6HGukZBPlTGdnemEGoTIiucWVwLduwRBWjLcXTk/sCtSJQwUTqKdkDARkFlFhYI/UGF/ifIEFR9vcJ9/TOCiA5BwUhUYFXotQxtIN18QWk9M7PT2jNpwIMzY8TDMwBVK3wSNG2JNlCTM985TjO6M

7MzP6HESCeWDxoJSRMWClCrM8JkgA2bM8Qq2zPEwLszBaH7M4p0JVLX8MczblC70+czEtInvXfT0jMUuZOqZiYDMxCMjzOdVkW8m9UFI6t9vL2vM6nT0jOfM+zg3zPfIKMzCPj/M2AkDDNTM8CzO0igs4ZF56AQs6o6VkkrM0Bc9lwiZAizncUKIMiztMh7M/wR6LNQ9UZIWLMiM31ogFZpvVczPDP0MMBgtzODqs0ADzMGOBSzcTzRM489TYMnI

yow/0H5xukKazJOXTotJZNbABPUzwAtwFWlrMP40xBlhNNgvZ09nRLFtYOtE3h7JX8NifhoGB+NYN4BI6MjjNP22caMPFyZeV3Th2XaBWECCRxZWOCjhBEM3buDUKNLA+ddGqPwo2QDto5qM686KDPqs7Y65PVQ5t5lmYPk9S/FXoipaFHpvyzhZKKIXojwVNRg0wzk9biIb6R0wMqJc62e8gutgJ03iR0RdxxuwBMMSW0NRE3lbBzaji4A6jO5s

7vw+bOo5oWz3oPFs/olpbNaOpksjahVs4T4NbPEjPWzjbPklJXFjV3ts1Lxos7k9T2zBiMbA9XRsaXzbXctO6NLbdrhucAz09mzGjNjs+LMSElFs7r1JbOE+GWzc7OVs8SIS7N1s7r1DbMYhGuzEiUbs79l5omdszuzteX7s/2z5SOHo9LT7LEJMyeREyQKbghdrS0MYxx4M9xKkDyDZdP5NCMcnLZGdH0of8xStsTh3FxI3E2YmNx15iCNsSHLX

VUo+eAtsAwUfsnsts0zgQm5pv7F7TN/w4rQ4xJzVVXjeaNHmYtIylBL05PEImRogBdQK7Nfs0gN/JzXjitaqcrORE1ozkR2dQLMZuYbAL7opLNolKNad2AVFpcVkTVsIJAINkg1tlPKL/R/9e+p3LNvChJzolAGMzvTojPo6EXZn/gYiBUaDSJvCo4zOjOzSUQ1rWgIlYDICiE6sxyz3HN0QDAIH7OrsyINU8O8MGVaInOfSOLC3yB6czt6Y8SX+

LJzGUkfkRwAYxbd+Jg1ZwCqc/Na6nONRppztCjeM7pzPnVt0AZzBDNGc4zMcrM7xKsiSTzN/kCz1nNeaPcgaoS06IozlG3KM2t9fVwOc5ozznOADTxzPAjuc/xzh6rF0cJzILNicwFzqXMXTJFw7OAhc1iV8nPWAJFzijVQDbFzR0jxc/ZoKAxeMyOzMzOBc3gzhjOBMzHoBzNmc7lzRyoEs4VzkUm2c6VzNMMxVWTttXK800dxlZgXFNSqMN2/L

QID6aRwAJ8AJgBI3dRWwAPDgz+jRrUdIwF4eYHCBuBEqI60wHg4LNN0FFC9AvLtbSRzsDRkc4XA3WMn2n2KiCpfYrqAh3GLo2f17EP6bblTywPqI8GhN4y8Sjzow7PTM7yz5gZfM1hQn7PTDH+CUkhW7aOqPSCAsyvTa3P4AM85YnZI85ezU3Oo888dTLMY87Wz14LaADjzjLX485yzBXPf03wzZXMEHRVzvL11ETXoyPPAs422jBHo8+egmPN08

wzz0Jq0xoCz7zMP02iAhrPlo2otzHJ2wcSs4NBSFMfATl3KrQIDMeoUAE5mE6zDHcJt3l37wy4jz3HK1l2Ij0qaPLsIpKqINL04YWCW+H6ycaMIiZlA9aTcYofi4hR5ZLoiEDgFMfRzMd2w82iNd2WxBErhLCj0s9zglcWfAOTzKPPXs0O9+orXqbZA7Wzi0ROz1Vb6AFAOB74NUIAo07OPs7OzQSwwoYAor7NlFCt1CfMMhJ+z65DulBRKyfPTD

BwAzbOoAGSAGFEOFK29yxiExc4mTg6AKFHzmFDyhO2o6bHbXFOzqIg5828z1GBVs4nlv7O3s7eJgHO9s0BdQYlsHNiN6CgB82nAQfMh88CzYfMXvTIlkfP/UzHzN4lx87nzAXPXqSnzj6TlszchmfPVs9nztkCr84NIHnNbisXzxyBl8xXzZGrIpju9blAAQ3/FyjT182rgi/ODUC3zf7OoBPezC+H7813zLoi9862zK60v8zYp7/Pds0BzIynD8

4ezSykc8yWjP4Nj8/7zfTO5s+OFEiXB86iAObOh87r1xEi1xT+pjfNGKv3zK/Of8z+pG/NPs+nzuro784uze/Px828z+fNNs8fzwoQl82fzlfPQplfzNfO383kmC/PR80/z7uit81Lx7fNdswfz3fPrsz/zVV0dsxHRg/N7s8ALB7NppeuNpI3GQ1JKgUHErD4Fz5qdXUOswrHMRRBIpAD/Vu0A6XE5M7dzrrMgg2ODpxSb1lXw1UCaMrM1vgEms

kr+1LYNDe9tQ5PkUvB9dPw9ik39nI757hHg9fA9yGkYI6SgGe3efQhTkyddbEPhBdOS8ZCojqkjm/S5gPzQy0RomFoswmYSODZJZpLoC4/zlAtixQYzSlBGM5lz5GCLc6/zkSb7xO8zEugVUpLzzDOyOhqECLAsEc+MfLOAYJOEH/MHvuQLhfO4C9QLIg1olFxzVo3Jcxm2izP0UDWznXM7ek7SeRbc87zzOjP88z+h9QurDGLzwBV1Q/kL2lBOc

6VUniKC88tI/oxD+BMgXXO50rVzq3Os8yCz/ahBaRELUAzNytELLAuxC8wM8QuGc0i6KQtds3aU8fxp05kLfVLZCzMzUzpCMgULBvWjWiULpAtlC0fzRfNUC6fz1QtgrBLzvQt/qpCzzQsxdQc6bQtVTjgM0/NdC3qJ8wtS830LePN2lIML9tzDCz29QFRjC9TzwvCTCzNz8XD8TrULQIs5C0sLlqPVPCsLsbaqOQ3zMQsPC3ELk0kJC/NzWXOmc

6kLBwss88cLo1C9C7kLzyAuKtflVws5Q0LznfN3C/xzlAvEjKXzzwtzC1ZzCws+MxNoqjqfC9MLrQvS0u0LYnadCwsL3QsoizMzuPMHHGCLP6AXC5CLpLOjC2CssIsTCwTFCIt6TpFwrwsU8zyzaIsZ02HDL/0bkaO6ey4qLCvDr70XrQjTtXiYAKCAx8wIAHh+Ra3B4+P1WtMCw7ID59HmqAEhvQgh4BOpI4gvMCy2gPQDk40Np91C7WljcWr5Z

J6ya2FSMN9RA4pLEqv1GaPIbS3DsPHxzZ0zWoN6GSy1kwk1Q6lwy/OPoE81zibEKjU1w1CBg6U6JYQFg7igpTrfnK/QuIjeIFmLJYQ5i3Pk1mIpi9ucmdIZixWL/C3KNDmLfoN5i3mDAFSFi3U11oMzVETMpYtwFXWLBqS0yN+cNYvUs9+DlXNNi/WLttKNi4OL2YvfnG2Lm4V1NcaDnYvKNEWLvYsAVP2L5Yuzi1WLI4szw7Lz4HPt2iw2j72pK

O7KL734XAkA3G3naTwAbEw5ODbqF432iyjd9hXa00V9JdhukFd5tv576QbKdHSBSjkoMfBDsSf5LdNBIyq5r4vS8qGLpSVKWltNdb4e0yYd3gtEgz7TAQsf+RPT/xADxKmLotIkDUBRLYvMunAASUj70BIo/5XfIM59JXAQhHVDmhDaitgMzvUNUB2MEyp/oPy90Ip6AHpprlBdCWMAbBxItVOLG7DoS5eKmEv1WEKAOEvESsAo+EuaIGKWREvP9

LKLpEs1FORLi3WUS4vBL/W0S1ki9EsPKIxLeQnMSwf9xaNJ0/j9rlV1i1B2NtAcS3BKXEuGhNhL1It4Sx82hEsq4MRLokvwmg08xEgUS1Ih/L0QFYyUcktFAqyUC5BMS5rVNVkbjXLzrR2no3N0Z3ieGQoLW3mNI6ZAUMECcpRiN9goc23IIXhukOUsfNBBJfv5nFbgfQ8Yn9yQY9QQDrWt0xIjxEAnbkn4E+I4lptZOzWYJKsw0+g6KRCj900rI

x/do9MscxdZOZXw83m8OIs/HVELY0B3dlsJC+S+wIgAo+BX5Ax21VhorKUUfUOsKvVYSMb1S5HoaJTXAPWcEAD8UBy9GEttyg2LRZAPlXpQJKCeJf4OQtIYC0QVDVD9S4NQjUvrkM1LvJZtS5vEHVidS2mLP6R2Kr1LsSjMAHd2g0sTQCVGC+RjS5xLE0vTi1NLq3UzS7tAniW4o1+D+KMt3QtL/1NUKkmADUs5CetLWpatSwxg7UuhUCwoYKxdS

zQqC5A9S2VGR0snS7kiZ0sjSxdL/L3jS/+Kk0sMDOW2s0vHxS8tAlm0w5UjmsmMg9Ya8KmmeFcj+W0MY+mkRmAgAfh+YUsnQCERbRhUpNlTeSlBPZhe7PToAxlCRHO22eIjL3kH2oHTOwj6delN1HNJGAWwVKL3yRDzZgMps+cdqZ2VSzipwFqtwVVJAyIYDUnZmASRMwRLw0G/OJ844FxiUFmEPSCoZEu9xQuw9dYqa2lQUNp9cvriJf3+6sj/S

9tLibZiDNqzEAgdwRpBqXBoSwU8LnW18+sLTfMdAXn18XX70DFop6DRc3zSkBBBaTlcjJSuIonZj/hyy35UGjhKy4umWQVKSy29Vn0yHNrLSEq6y1SwC/gGy3PBvPUi+ibLh7Zmy4LIFsuuSNbLO5DaS3bLOjjz847LRiouy0p2bsuQ6B7LSjVey0Aw7PMTvWpL9AMFIL7LUsvizFkiI9l0msHLIX3C8GHLFQURyyNwUcv1RUSUsioPjHrLCcvCM

03BgsTgYPG2jHZNy3czLgh5UtdItsvOdfnLEfOFy6wRyvWuy/gw7svKcyfw9hIy8+5LBgqe8Yf8n0W4MY+0fA43k+eLO23mi11EG+AWzsZSFMCIAIqgyLYKoBvgjdTfAO8AxIAMWuTLDUR68Lu4PYizmBK4fSPHSWRAkplimEKZMklGvSFDl7LYZrtKXaP47Gf+t0SHtCDsbPTndHNqEVKfPBOk0EvWJKMN6KXZoza4kzXCFsxz+FMLVVvm24acp

X/RSsEAMSylQDHiMthxHKWj8dJ8G7kWgTXjynxiUwK8mTFl4M0IMCsheOwW8CuhZqcUQrg1QBcNJrNcqJBzFNSImIqtMN207RfLpvhplhOs5+iTAEvdD4ua00+LTosfMaHwOnj1bRskx7pebK6BpxTJYGzuUc0iGf6LNTOLyJEY7p6worIZsyMLNhMQWzhZqugr2V0zk97TLN0EK2a5lH0LcNBQ7JFzvcboIRJX8Py9YkZR07+QritC6GqOHivkK

F4reAg+K+iL6Jr+K5taRVHBK40MoSvSS74ra40bJVrNHkvQ9GwxuDFxuZk4daP+7ZIrrAQKoGwAzEyEAJMALMDoXbrzK92Ejs+Lz3EdEyq447ByYpCU9skMynRTPCQwFsqmzMsdbcMD3AYjtTEh0DgrFVFDKFNp7pHUzEP2vTBL+j0oAZ/SY9NHBUeZ0MhD/RDgaAAcvfvQ/4rIy7KLEOApocsYSJzqlSiA/Dq0fFoVJ8V3MGv4ZvmzK4iM/L0LK

1CKSyvLjKxqk4RUbOsrABWF/Fsr1ZA7K3nNRS3XPeOLvL3TKwcrKsBzK8cr/UOnK6RV5yubMWsri8vkFVYpdyvzMA8rSSt9JkazbAMT+UIrWFxhYDEhNP1T7TazEgAuIBmAhJ03gP/NzrM4Bc4jRNPkyQC8aaqbBbzknQhYIS0cHZS6Ky0rt8OGK+ArshIubLzkLNBpTarDWfrFNF2+SKVFS6XtybPM3eMr5UvOK1Mr/L3YziSgnyup5SRLucq/K

9lJD0uVVACr4jjqlRcL2ytBaW8rvGoCq9MLokvCq9NLf5AIapcrZSKAq/1D+QsyqxErm9Byq/yrRyuCq0qrn4wiq7xqg0gSqzRksovaq/crO8sSCxWjQESy0zkhWu0IXTwdAgMGgPNmFADxqQtsH8u9CA9qK+LE1IxEX06d3pKm425AstJjy3gWC8B13QbwLFMQuRkcqjf5CvJUcKb2QyuZo3GLhim8ZpyrTisDfUhLUMY6CLyrMbT+DlAL0kvvK

/h2lLXcvXojRSMe8nmr+ysxtAejmMtOo9D0PIaiWRnMNb4IXdidAUtbmMbq3sCPy0YADEmYq7m1rkMHwzO0sRiZKLdtDpxXBommFxTuDJ4Qf84qWLbz9tkSuBsmUAJLoiI5rX33tOk43xgv/oPT8SNe0yPTdiiJi6QDYPnpQ8WrQrNslrr1A8tEMwt9qcCWIMVDXMz5q8szZ6uRJtYql6u7fX5IRaOKDRALlXMc0W8rp6v7CxerdcUAJZT5Dz37i

3TDENm3UrueLW1OXVadHasSADYRd8BPQJ8AmYX9qy5DoAM4q+AD17Jy1EK4AaJ8/emgOXzytFlYbnmEvdFdVKsXmgah9xhhYLmwSDS1w0lmXxSKYJ2uLKsJsyxDSbOl43urIz2+0zxD6bMOsaSLoLUt7Wqd+ws8a53tXL3YwxWruMNQHOT1Amtko5BDPbI4yw1EdxmBgU5dTZ0fvTjq+Ya28O3ASGsaCxhDWgujg4MtytYFcd7uSKJfTkdmoyzJK

Dow9pN1fcGzNM2RVtvjumvk/PbTFivyVvWpLY0e8/yqmavJQ0j9R5k6/T+rEGqOA7gLZiWVC4iIUkhRLKC13ziea/erFytNVr5rpTr+a5vFsbBCtbqr0opnql5r4Wso5JFrRMzRa4FrcWu6i7UV/4YfbKJZxepkcTS0C0D2TjGqG/Y7AAt1PqsVGJMQEHVTdFTNYkkrQFA4n9TbKNpGA5MWa8gt5EH+AuZ4ay5qKdFKcqMxvJVg1GGeC/h9sEvwN

a5rXcOTKz3DxV1l5G2z94Mtszut02vvq0ozn6v6I7NrJV3za3uLu8uga855us3tXcuBnLlNgGn0cgBFOEPcTUAVa0rYxT61mH/LermQEVMQGwLgPlL586tt06py7H56bist7qUByUCw2GjgRdurntP4A139txCja46F42s5q5g9A/O69RP9s+o7/bP99/1ACx5t2+gnAwgjCMkAC9f9EOu3/VDr8/0w60QSH4NPK3ijdUnJ0yDrAHNg61v9KOsHK

mjrUcpD8/Drj/0xM3PD5KN9FBvlR8v8mWOwhWuVvOdprSPQgL/9ZWQ681gFQ10tA9pr4m1ERrNdOXwncQlT7DHApD02lCZaPPcYnOGgK8RzAYtNlu4+m8Kbco0zojl1Qof1wQuDa9197KsOKwDrfYUpQwZhd/MyJjVLTssFEINIlZzaCmG9OjX2QSerEOBgq/4OmkhMC8vLvoDG67iIpusgzIn+vXZha3Pk1cu1XT3txZ126x82DuukAE7rLusyx

m7ruSIe62CrwGsba1jLAfkuoxJwmSV4RrCqLoBp9MUSmrUZ6QsAQm1c63rzFSvKK6K0sRgVQDZMCq13bewxgrwYtL2IryQ/c7Lr/fQ8cLDA9TO3+kh5EYsbFbEwIux75YxrwytrnfYrrGva6xVFuutHmfEFPmvJ835rJ/ObxRXsAxrFtkaOYKzujvpIyfPO63I6AesDMfVYSIgz649g2XNpiwJzV6ljxJXQq3X0iuloQWl96xFrA+tRa0PrvoR3a

GPrqo4T6yJ2U+vChEvrzAtOy/Pr/yEm6z+gewvbK05aG+sqUFvrNubzcF7rzysvSz+De+spawfraWtH6yPrjnP78OPr6o6X6w/rkXCG66Qqd+vnDNfrT+v3Ky/r7OCb6/uQH+t1aZQjjqM7c3SM5/KueYxzkJRK0QOAafRFiC/88xQChKdr7MokfE12FRiTmZARfuAZfsS2eljNrdLrLMupS79FiQCMPhacbTB6A6SgDeuYwEn4Aav/QYLLhIMja

werqwNbAKFrNautSdG9jshh/VpzkipbGhqE4mrX8238GyseDjyA5irSlEBU27AUqAHrU9C303G9jtwKMyFrAmpJa7yahVEcc7G9+UOvKAobAGoWq/Ghmyv23JIqmhulVNobwn0B63MLBhtnAEYbY4s/65VzEhszK4lJ0hsWG1fz4f0sfTYbGGp2G6obIKuvKM4b9ViuG6Z9N+tGKsiLnhvwM1tzh61xM0BEXkvHwOFgmFyd3NqAafRkOcLcQNpGA

KrFEgM3c5pr2Ktus/xJU9Lghp2ANeoeoFvJf0WGfJguimAUq5GrW/UZul0IxJMGDnYL5lXv9i0QlX4JYM5raJFd6zDFPes4bdiN0yuiq7WAo/O1wbRLvGrxa+EEcxuMlAsbWWusHQ0wkHMIeS2rNpXBNLVAM0NqC8IDnwDOsD6rwxxkRL8x0HG1KO+FVPxmWX0o0eB7c8RrrMuyEn/UTlJINErra6ts2rjelCYxi6ZtS6P4Y9whoxtn5eMbwOtyE

Xer+ytmq6JQ11GZ0om9A0MDs8er+qtpBRCb8ClQm9599twLa+VzS2uVq9+rvKvgm+3ESJu20h79RUNEPZCrsTOCK1qYhL3CVfNdLIOJ63Y9KbVy6bEqQgCwgFtsJxsXrH6gVm5ya5OrmTi+4G4e37z+lVBTQEvxoz7g3CAhFTJcsiNDBr0jPTToed9rIyti06VL+6te81YDVUtQHEoqLCr23KqdbU6KNMqbQrVanUJridM4w3jrSpt3tiqbiMlrG

0l9ZJubG0RmCNxT/hRA6v76wrgAamvPAEtDGF0gvfrzaGtKFpHuynEd1G+emAk4slyb8cx3G0FDrWtzLSROo+6bOAcUKIlv9ksOVq6Q07Yrb91v0aHFbGsIS2mz9h3+G3yraQXJA+vzydbnxIAoUkg8ayB6hbIpm2ar6Zu4C5mb16k5m/bcUHpHs9ujMyV6nQWbaqsiAcWbAFRIiFmb2ABlm7cgxI2CvSkrB4vQ9OSbgxTN46+y1D1DrMtARBvo6

rgAdvbChsybX2pHZuMSNwRFQOMhElNX+bcb91wBm2L9IbO1hR1rxnxZoN1rGIM0aws2ntTfvCEJMZtodaMrTE4Am8nVGv0h02sDffMFo36NV5uLG5ebfAtNXSabkgsqMD2bAzyVrazulYU1tMmkafSW3fyMUaqL3ScbkiOZ+fqx7oshIQXpNxvCPrybw81DAzBjGIa65JygWCRD1En6DKuaKTAgnNhfa6yrWsMlS/Gbp5uITaLLZINca//zlolSh

Npo4OtT/STre/0bji1FNd0jJHsD7IkMzpqbZFuQ65RbQ/OkwFjr473e60WdITX0W86IjFtE6+Rbd/3o66xb6bFpG2RNUmtamLlrrnnlEHmw8YULAO+9AgOHMmvynQAGQBrTJa2Oi0OrCX4wOIyqB7COTBBsSgOXWf4CuONMc/UYbRtgK48bF5qcYVTJ0CAuqFRuEZs7yKfA1KIpq7GLP8PLoyMbohs+81DGHdAW4X0iavZeW1RgiStPS01DuOvqS

9a5D9COIP5bkmsZG9vKkHNi4XMQVptZfQIDb+FH6N8ABgnFk8hrpa2oa1UbuKuRovLQh4UryC9t7DEe1Ku0gSodGPJKhr0y60YrK12gdYFdZbmrBXZb98JWLT2wTls/G5DzTr0JmxMrJ4OaowuK+utJPNAbQ6pRwHFc9ut9W47re1h3m03EPVuJG/1bo1tPm/arisAGFW0CFvp4q7Jbl30CAwnsMqhqYTSIJxuGmOZyDFLGTPwSWSgH49Q+KbDK1

hXrlVukc9Xh77y9JPWN2zVcpOThykCxI0LTO6u/a2Mr7lsaI04SFUhFm8nzJZs/qb6Eg35dxDxIQVGP6yvrThsxa+Bg5GC6G5VUP1u76x9b9ZtfW42bP8k/W2gAf1vmG0DbJIt7S7iIoNthDu4beItf6zjrsMmyEX/rmIwNm+cMzZu/W2nRANvEi11SINtcfVjbw1sOA1Dbolvu7VFbdYAXk3e59kwTmQQbdP1Iq+gA+gCYABdzMspA2ltb7ZRaK

afD2ZDjIaaokJZ+siXqTTltK79zfYA2PKE+0HOsqu2WtBoN4GEwk5lCG1hTneuvW4qbtZu7QNDEQRs3cMRIEqugiCKr0qsaG+0AsBucSDumSEzBXKxqI/aLwN8rZ6rGG4lr2JsGqzuJnVAlIBVIFqtnKzSLjmgW21bbYjM7tlCz0lBaqE7bOWljWzwKJhtu2/rbnzYo217b4sw+22bb1qssfbiIlttAVNbbVYzLK/bbNSSO20KrEdsYG2BzxvqhD

XHpMmtnHsZWIzyDmyn9AgOa8+3AaS0liLCA+AA+en4ZIwC+erhWGAg+q3u4YfDjumoCyel1VXxdkzTVNPhoQUOUq+ZbLKTy0EXUkzTeCmLbYVJYWD5sNq7DVeurjFiHcjhjC+Z4Y9grI6BZKucbMw1EK7/WJCvzDeQriw2Jk1Qrr1Vz8TQrBWx8pYRxJVM83hPba0QTePoiXROmEHPb4U2G5MNVAivQq1qY4Q2JVSluJnQmi/hcCwD8AwxjM5ot1

DuYo5ud2+jRxTQ3EFcGOSV1EBAsJIZsjqwGpcOj26wbqNJGmG6QVHBW6Smj6aDTmxY+wxv/Gzrb4svoAKYbfwswC/QATjNXwXfQniKTCxW2TPOR6L0LfoIe6yQ73yCBAGQ7vDMUO0qW4sVUcq4Gcwv0Oz4bwVt1y1sAxDuPkDHTrDus8+w7GonUO9hytDuDULw7oHP1q6zk67VQBa2DlI2tYxx+hWsVA+dpkgBtdNwQ3XTEgMkBRgDZAcSATOyfA

HK9hMkaaxnDWmv5Mz49bOpqhotkAS7jIUXtCCyPniZxC52AddD+UauvRiZ4DSGZzG+F5NyMkpo28JGJ+kqZAO2F1K+aeDuNkCosePL4K25ruHXa6rfGQXWtuHXUQ2G7AHgAHdTvsPhYITSMkjVAPKKeWMQA2255O/KgaoDFk17qs9SXrlx1YCapK9GKstMx8HPl1MFfmx8DDGMKoHjJF4V5/oADy0PlGxY7lRvaC4MtTqi8JFkyB7hNOVhob87Pj

aK8fyWnWyRrB01diHGQQH3XWwii+TLa8D/oD1uJs0PT2sPd6sEq0ePym2LLbY6Kdgm2rnUNzDs7ZdqBW5NFvhu8vQc7CTvoywetYlvM29u4tZ3K1nB5n5uDm2yD68NQAPOsNZPdBKpb3Osum1lb1W3EtoBdmT7H7dmB1CbZQu9sv2OzmKZbFVsTO+f5iQCfPPbeoxzHkRQJsLJ+zeE7UMBvSj3jBDvbOz6A0z5sHHtSWLsqSx+rtcvWGZi7jpJyO

9tzxp2H/DfRuDFYWPzuVpvdgwIDQEBWQJUcbAD3i+07TQN7w9nrGluFlsZxODgHyudjcQh6POeeqoLBxALezHEGK5bTHSvBvKAKv20e/vVbkjGINBlByLvj7b74JHzou8ZaJvzfOGq7fDv424WsGrsku7T5CQ0iA+8AJUqYAOCA86xBGcqUuACZ8tvM9RpzIBPMTh14gPk03OEX0dxwAUrCRd6gBIbRGAl8GShImIKogag9iIJsRenGfClgx5EvJ

E6g1KRrMBATCRg+orLbe+3pW+pbDtUwTV+bQX6gvEUhELzQ6ee4iJj0/Pe9Tavt5ZubIiLJiroSltA6w9V1L6UdW2+lF1xviDwA7OBsAK0sCqClG4NN+TSryMaT9u5a+Kahh56c8mcN4pjsE9RGUlZb3Qa44M6CBkwylRwFsGzhD6wyDtG7SIOxu0orXZkJu4ObzaUwS51xm/o5MqPoefr7VO8YStjy2ptJBbu98GGaHNBR2aFxvq0etG85t51bA

Ee7vcCb9LBTJyz+4ONsT8Ka5mALNct6myFbEACnuzNbqLiAhcoAxADPAE28nEn1u7zL3FxNGCbayvM42tX0HCBo3O/MGbCQKq6TSti9dS6h31FRu6Oj0GPjoxnrE2WfO+y78bvfa1+bOv7zu6Okr7Jd22cpEoCx66wQk3L2yvm7oJSFu2s7ONg4wiSDbzhkVqhAuzvQiiOhGaFw6JJkqmneNbD2TzNp0dX+7GroSgeg7n3ly0SzdEiougb8HOh5Q

7Qon+IFtv3+Jo5BaTR7dhRAUSNwDHugQEx7vaZ1Tr1QTfbPUZx7AKg5jCp9ESaa0oAzgns28pXo1UNie4m2Ent4dptoaSNdW2O9C20brTS1m9DSe3R7WSLye4EZEEx48Mp7O5zoxj15Jo68SmGQ/6A6e2CsxIRw6Gi6eAgGe3G9RnunvSZ7Oba2q8xtr7t75t0AvCyN0PoAssktHQ67WgRkpEaYsTDAsA0GJ3GEqnYE37wWnD67swiTow1xrRBup

WsFqY4PGyg77Z0zu5q8JqKQaAchsuYpbhXuvqrFoBqikrTKxSR7qzRke0lGQVYmrRY2bzibo7sr/XuWA1s7Rlx3u5xbnPOVq4N74KtQzaHDtxbMAsg4INE/8NxtP7v241T83wVo3BmYQ5nj4gDi3B79I3HOCRi+u4cEf1CoaOdjAnBc2VA4SlwivO9Kgqhwe/TT3s2Tux6V+bVVe7sbLmZYe3wb82RQ1EeLDVkKxQpsDET8rLltFJlbu53gO7vYI

M+aXENcq1IMaUNOJc4AinZqFeOzLOXnszD74Ulw+5OtIdgctgyqAob3WYerCdOqSw+7Ajt+jQj7HbZI+zez62t2q9F78KaKYXps7nEMmct7x4jPwBl5wV2OwkmYnMnPmiRDhYAN4KYYGK1BFRgKuTKQbbCxvnQNEH9qfNShDFd7Y7uiowzTlmtlG6y736OWO4ayT3v/2zP+r3surfac/623Vso7/JBeu3/ojigA+6R727v+ygEwE3j0/FR7SZlyj

lkCq+CI+yt6mABKuiFyfwEI65gOpvvm+4NIlvvkHNb7KdZnuzdkqPvqMu802Gi9qqN73+v8O7IRkA72+4T7FvtW+4QOb1Evu6UEb4gwAFjNAICyWQgAzaU0+5NyhTRmeLXqoWJ1a0yQwfZAFt1q/1C+uwitWu6IhW8UZ3uoEXQUzzzR8Nd7/CLle/ybvfT3e6JtYL1y+5oMHKa1e2h1A4oJLeYjtdJb7Gr7YETFNNw5gr6A+yMwwPukQvVRWZWQ+

9J7sPvE+yzlo/tE++ZFumZPLB77AVaWqN77t7vhbWN7GJuia0AdwfsORUYjb4haO8P17cC+wC5miftbgTiYqxDleL2Iy2WF6uwy3zzKu87iYSF85H3mDM2TA86453vWWJd7Zfui+7d7MbvmO04jg6toe5hb6ahfmzwpivu4a4GgI6uq+3w8MzZrSbNmffudQvr7oPu9e8b7lw4O+7ihowGL/RcByLZIB8KhNvuiyyw+5uzz+xj7PvvL+377Wrsew

5gOGAcuHFgH5Z3Te1Qj6sWZCEsAo5vZvof7LouomC2wYUr6Wxsb5UJTLbMsIp1H1ri9jS0g4jFO25sbpM/7Qvul+yC2AyGV+5YLHztZ625Ov/ut64KOX5tfUkAHOr18XP+1YAd7YtokyfCeGdr7HXu6+4/asAdD+6VNkPsMEVVdLOXGB4+bkQlz+xW0C/ut4RZ7RzuhdaezLjlmB4CdW/vEpTeAEEDewO8ArQD0AD6mh/uPwIsCGCF6JLC9hHvDY

e8eDmpprhss1d5BSrpYOUCEQSvGVmMnLIs4ikBY2v9QN3tSPTX9q5t6jDX7Z23dO/q5Gz3AQYc+Tfs44gpNoxXhXrrV33ttAt7MWSieTdoHudSde2r0+geG+6W7t102KYdWJvucAGb7G/urejLdzUW5CR2Oh1Zusd5tCMmtB5cOQfvxdSt633IGgF+J9hL9B0eOs/sueGj7Xvs2B5xr2Pv4u7j7Afv/s5AQwwfItqMH/nVw+t0HD47TB86IAwdEm

yBrObhviO0hkmFtUUqQNru9GQ67JcD1cbtK8ppsB3yoDs35nj+sY/SQoiu0dxslwCskC4N+O/EHd1JRSw7CKQcV+2L7d3tf+2yjd3PnbPX7ZXTgCYUHuKKLnXUoWglqB7jmvhHrJEiSNQeobHUHZ2QNB2D7Wau0rAFyGwdAMFvhco4O+/eOwwGeHfYSW+HHB16DHY4kh4gHG/vkhz3dNinUh7MHnoyWB+j76GiY+6sDvvt42wypJAdUh8uOZIfrj

hSH4OZ0h0cHTB0G+k/9vFFviKratvBJIFLikNGH+8XYU2GxTHUohEH56sOI4yQdHUd0erm+u42GIzTdrff+AvsXe8L7b/tle2CHn/sKK2pbU7uyB2wh9r1fm5PWSgfDsEMc9/l4e1dsnftHeKOIDqgfsJiHKvTYhyPwuIfwBwwDWk4hiTNr54Shh512IOZzBwaYnvvWB9yHd2W8h89L/vtomRGH3E6HvkZFJPtRe5H7TLQTQKNl9ACZDTcHFZkOu

9Uo1liYbPTNtlvPRbkytko+2DJaifQTsBitwkRmqCrYI4DAGSOpJocv+2aHYgdScRIHHjvX1dmFbLsyB2JtMIcsLAsAdI3OhwwsB3OChvEkBxJpBmLuOCCh+X6HLiwBh3fIQYfD+wgHyLYogLvwJU4O+9LJfGtyjluHuZmkhxv78lXsh/MHcYf4B0v7wJ0r+wS76kNoB746tjo7hyeHLgdbAEcATaVywIF5aORJe0kYazCSXOHeIlNLB29zwphN8

aCwyK2O3gOS/akwOI2U4x5gFv8HxVs+S0kH1lU9h5aHE7sQhwTTXTu86yOHOBDPMfCHZboxaqIUasLcDh37GqKkE8wH7Xu1B7oH9Qcg+wYHIsvagzYpllQlToeHnrElNZSH9M4MR32zgwf0R8uOTEehsQ41ZBz2EuxHw/Nu+94sHIeLBwmHGiNJh0FbxAe4IwjJ7EcHh7Y6vEccNfxHbEe2rBTrlAdnVlTrThnZlC6Al8rbzEJyift95vvxR/pZk

JMF7EKHnsFSY86NQvrWG+2FsO5Yfu7e8Rn4Q4aV8BUsHGhbQKkHYZWAS5IH13NS+7kzbzEbPFhHv8b/FhOHwK7Wsk17U+hxtaAYp4ha+0mF0AcTik7FgC7Bh8ZcMhvXnPpIDIdjB3RLwftGQTcaYmZXtu6O2LrHUOIlhxb6SDNcHVjyhOR2LImCMI+OAxoEsPeg6bTklfJHjABV6FkirajzM09or+sTDNnLY/b2c8lHk+SpR+gHG/tySxv7WKENq

FpmuUcidvlHGiCBhD9kLPqlRwj26YcVR4Sa3PM1R078xPBGOZcOh4dNRz/lRbbOju1HEFacdnmhwkd/BDMsALyt6uz0wVbZ1ZJHxzsph71c7HM3cClHpAcDRz3LQ0copqZJ41pZtnlHY7YZLEVHM0fVWGVHkYcbdl+2YWS1R38K9UfrRxucm0cUlflRu0edR5J7jNvORcwCo5sd4selmuKH+ySrwES0IZAKFNOFgD020xBAnjXqIHXnQzmgoFmRs

+ZVhabuR/dJnkd9hwCDHTvf+5lbOQcBR3/GuEevuqqN6xkGmO6HDtkaopZu657kR1iHlEc4h94TT260R2Zi1iA4uwsK271ZWtvryOhdaAaJvX5RIBkAZgCLqoPgTb36la57o8TJ5esWptsK4VlonsADS8Hsf0iJFEEUXHhq4KhQgujMDDN8QWkix0S7kFyDThLHaBuDUNLHXYmyx/og8seAQJwASsdnKPPZqsdgrOrHTfyax27h2sdTxDN81ugGx

/ZURsc6x4aEDegLaFbo5seHR5qDWPuPKxxbRAf8h2KijAwYCGLHNscu/XbHhegyx3V0csfyOq7HHADux38onsetvT+p1tIax3+grOjXSGeQuscp7PrHzxz30LHTJseRx7705Vpt6C+HJHgBut7AxYh5JEWH+yJ3B82Wy2PFEHok4cGrJP50xYCb3e5YHPtC7a5qz91gsLRDq6vYwj4JJ3HVYMCiWzjv+2kHMFuIe5V76HuDm+nmzofTHN2U0OF0j

O01ivOjHMJaPMf+h3zHgYdxCMiYC5MxO4RbPxVm+9eAU8RiNAQALcXnDjSyT8f0S2XLdfPvx4mxscdWcG88gCx9CEstbyZXhzVdSccNablySd0x0s/H0TSR6G/H+AAfx1UtD82dm4Gkb4hQAN+xeciHMMcxyoep40XtLR6FXbM1OyRzsX0ISWAfBwV7PSSB5CHCmTgxbIEB9sIrx5Rw7mpZEOTH3angh9aHKHtDh3X7u8fVe5riE4dFGQGcCVXg/

KfHQfnK2PIYRtVLh5A8K4eFqPs8d8eJR09RP8cMzib8f8fIJ7DEunpJmUonzogqJ0gnKCfUspOtwCedCFauJEPURBdHhAd8h9An7vIiNFonqIg6Jz1beidiC8krM3u5eNv7VkABTZ8AiLBOzowHUVZI/gwUIuAAqYyq0tma+xmRWRD9HCw+ptNOgFi99CdLx4wnFWDMJ49FG8dhlYGbKe1ZB8NdmEe8J7sbXArt6805E6uacmFHJ5EEe4SGDmqXx

8uH18erh7fHmgGGB9C4KOTXIT9M/+IyHOpdgCckwIYn8zglwCYnwwpdM5dH9gc2e9UnDSfYWh3HZrD4APoAocDf7RZAfcfbYiWHhoz5gS3qRMcS7MPOEc2pMvxw+Xuu8PAss3RYGCLglHPswcvHcSf1E+vHFocf+6hHnCfSB49OdoeyMVgsX5sOEtknqo2h2Dkowifk/QR7MuxnWE1KUAc6+0D7evsVJ8FWRvuF0FonyACoiJu+WifTDCMqtYvRN

B4UfycAp3TAs+lPLC0noCfGjLfmHSdJi5Z7x7PVmzGtPydgpy/HfVbVWemlUevxwG+I6hD9AgsAnsEz/owHAruLNaOwCq3MFCw+VkxXeVG6FTmJ8GSsKyTQ3QOGwkSg7kFWuycJkWwnmg5bx3JjSHuDXccnUrGnJ39JCURfm4irzoeODN5ejSEnxwR7e+xLyHRJUidjGDInlzhyJ5UnQseQcv8nL8ffOGqn0TRNJ/pEPmxGJ20nskrwp/HHiKdVm

yUtMa2ap5M4dauku6b4rQA4FPoA8xQ1A+MnbdoOuzwkd24XRPDi0C1R8oU0dBSs2UHEcGH9HCu0OW6axFZMJXvd09snrKdrx+ynoIcHJ5C7usU+R5oLGEdYQwzHxDHOhxqCWBFtNQR7Xw3PPFX9m7uvJ/377yemVffHY2tz8EYHv/O3qyYHBie6p60nYCemJ50n5ifJh9JHGmYPZeWnurvbRW+IogNO2AkAORLU+9+H16hniB0Dte14uOHB24iyT

EQmFKT+zhssiZ7h2J1ingnRJ0zAzKcpYOGnLCeJJ/dJyScrHaknPOuJpxkn/9t/+Vcno6T72Bwgh8tx/RmnytkyVhDQcqenOAqnL3hKp58nTQd8Q0tQCCdQGs6I38cvx5HoRQbEbUonTACHVs+nD6exsNqnuBiVpzCn7ScEB9eHUCeJpTAn96dly1+ncCcfp4NQRQaWp3q7e7z0AIjhFAADg6BlvgdVHILjy2HTJ4AYvET88p4QHqBIR+o2uuTN7

ueY5UHSu1GzsSeLpwkn+yebx2KjYyNSB+Ur3Cf0x1unDfsY/bun7CBk1XN46ad8PMMGkG4lJ9InZSeyJx8nhaeA68Wnmicvp3dOT6fQZxJnJpBfxxJnW+Hfp7/HJYB/pxsoAGfGJwanwGeQJxYnYGdWJ0nd8mdSZxzS8CdKZ3BnaCfOJxD0YmG4AEcAkgBA2sVKjqc1cs6n7pqu3WDFythQ0v3G5ER/e0Gg+3vm4FMSD+w5fCXYYKWhapRnq8dLp

zRnSScrmxL766dfO8xnf/uW0F+bF1HsZ2PgOjBRYAdpkqfSnM0SbTDJ9OenMFiXpx8E16ciZzrrzQf9+Gqb1M4HBquNUKdqZ/qn4CdUhV0ni209J5MxRWcDJxAAzSyEEGwA2ZI8Kb4HgROo1Mh8p24iPU1jzKomYxCGDYcdNFMSctT7NtFGJbnOWHFgt214aM2phyTLp+wnVocsu85DGVt5M7L7LGewh2gOoqeTqTY+3GegtkFWrbAs+VlnUBA5Z

42QeWcKJ7XaspTqSGmJkkG0TBJnrQBoAAAApPUMoMMDiw+nYKgEiEhyieXUA+iEXoBvZ20AewPUA1dnl2dNRr9nkGePZ89nlFRtRluLb2fVRUhyhyrfZ2gAoOfBSPdndyjRh56M0KfqZ1VnE9M1Z9Z7ep2A59oA12cg53dn4OfmIC9n0OeQZ7DnByr2KT9nxOeo5ycH2Ke1eIv4ucj5yIGm930dZ0fCXWdlTBEx8NQHyn6gBiRjeCpJW9IjZzaGW

7Lqh+McjbBVLl68KlhuR1GntGfi+21rkvvLZ3G7w4frZywsVUBMx9SYPUwBmuq8u2cvzZmpNfr8Z/KngmeKp8Jn52dZ2pdnBOfA55MqSOefpyTnZOcwZ+9n00EUiNTniOe05w6s15vm58BgQOde50Tnf2eoAE9npOeQ569nFOcfZ1TnvcOPgK7nfufu5ypnIx4gJ5jnNacIp3YHtWd45xbnhOfW57TnAef253dnlOfw57KJkedg52OOUf2aR//Bb

4gtCgqgongWuz35Pae0+0IiHJnEQzDO7NA4Qcf2kywC8nux4CzU2CnweJgvawZxa2QS5ws4n8OPBzLnNsK9hx0b3kdK57aHKucxZ73wNbRUQBrnzdjszVyZS8jt+5LaGaf5geAZh2cxR7mnMAem5+uHhdD452nnt2cPpzwAdudB5+TnwUiPlKHnX2d550o58mdasADnqedW54fnZcvH5/7nEOflEWfnTAAX507nueecmPnn5+d352jnN2QY55VnC

edGp0nnuOcxrfvnj+c253dOJ+fv5zBnX+dw5y7nN+dH5wAX9Oek+zmHWwB1dFNNUAAcpmgO7OeEJmGuZF5ltU6Ao5kWnCieCwhC5yZ4IufPPGLn5NxTZ5Lns2d/ERynET1cp/RnY+ch4xPnPCdT553gM+d3DglnUc52PEj0tsEZp/ewifSM6y8nOgdvJ3oHO+dVJ3vnD+c+5+nnfueZ56fnDueU51fnv+coFwXnllSQKVAXihdP58jncBdQ52oXo

ec/5xHnWheGF2TOgBfeLMAX1aeGpzyHdadSR8nHGCJ6F5kAN2cwFyjnKhfwF9nnphfIFx4Xv1CShxCrpwc4p6ZACQCiA9CwbhZFBgZHjD68nk5nQF5kcOdE8ZLJJGFKxj2BDKHVCutTnUkKRyQsF9vavDmLZ06bbP2oe5PncgfrDjPnpRvBRzAq0D5ER/H06lKs0FIUaYJHZ6+6wPse1IIUZudVcz1HSZxvkIpnU8SCxq1HJ3WYu3p2SPjJCy/He

WgjemIADA1MDTJn1HIgYCnKKgh2Qaigb5AbACqi7oD+IPRQtgiix3zMeABKhEbg2JyAQFZ6CsduxwdHbBy3R+KqnRfR0oZnMGc0xuLHviL9FzVSKghDF4/r6KcblvDoExemDT+n0xfcO9XHLegLF80gyxeJgE8c6xdWx20gWxdGkipQexcux4rHRxcGw5pnjd31p84XBErVc/dH3Rd0O6h2+VE4u4MXrvyPFyCnzxdsoK8XoWhTF5egnxdZaN8XH

6CLF7E8IDqrF6FQgJdpx5sXvzCgl03oEJeHFx+hcMe8qSvo+ADO0DBO8uJ2Z6vUdwedNE2UuqaZ1dhZXvaD7hGoi5K5bLH66Y6iK4secqZ9dfz7hqGtzrTYnRITsDkXHgFsFxkHkziRZ0UX3BclF+cnQ6xVoHPnwLQ9TLT2uG65xp6HkG34evrMjRclkM0Xn7W5o1oUhIebXConb6d8az0MTpcx5zho8ixG7KeLe3NmJyBn2mcEjfDJq4xulxH7G

CemQJbYFMC/ALgAzXS/pXT5DruUcMVb2ZD23VFNh9zasBGo9YCiWoL0NZ5zsckoV1uLxzUYR8KcaHVgipc7E+IHKEcxp/2HraW+R49x0Ieq5zgQt8AGl8h0GxUP1jj2utVsaxfyMfDVYJ1dVpcnCDaXaLR2l2fYkPu+wBAd69UtIINI36ZjFyFQoR2wmyAMw5envSonz+URcBOX1QBTlxYHyT2H8l6X6zA+l7Wnfpdwl5Yn1TxxHaDoA9ULkAuXO

Jf3trd6gRdUB5gbXUTKkK0A5KWmYJPWh/tJPVUYLfLdIwRmtYJmmv2Ie3MYrY0wji1BUwIHZ3vuygqXDUAll8hH0adj2xwXDotcF9FnOpeJajPnDJkTh8XYFpyQRKaX1w2FQCiihucXp8bnV6emvvEZKqcOl4LEfydIiIcqsMSBICJbqAcEV6gAm75EV2QcJFexa9YXfwQel+uXnmqblx6C25daZ7uXOmeBl4mxlFfUV7PEtFdkVy2nwQ1viBTAO

wA49N0A6YqsstXnnWCL4+l943hHJDaog1OVqnvsI8ipF1qQX+hnQNAD+XqVQQWXzmxcHq/Nypey52Fn6QcRZ2hHLrMJp2tnPBcjMDPnoGXOh8ko0BZP4eU9bZdh4QnIqcGZZ5vnUhd5pzIXsoK4V/rDR6sksUOgR5fhh6Zs4MCBV/RXPZCMV1zBwiJt9DCXjUNXRw2n7uXBV5SXkVELkGWjDOddRN0Ax6VcBI3GDAdSV2NhxVv/RcCiFfKtkQdir

7LxCuB8SNiVQqbzM6Pth/KXRZfAV9ENKpei/cZXCueal0xn6SeWVzS0lEANlzg8Wudh4haaKFfJgmWHI4Bnp+5XFEfSF1RH3ld5+l8nBSBIiL8nvQyHKkiIi3WB6DMXvQyQKbNXd5wLVz5QA73JUIEgakdDe12w3NBMV1FXW5eJ5zqbOPsia/qb61fzV2Qci1cMCBNYu1cXl68tVqesBGj8xIAx8QkAG+CJe7cHvMuDx5fRJ0ciu/dt4ER89sM0H

uz6WcG8/h6MFLv5IxzTh6iJOldAV/pX82ecp3Rn6pc8p7m+XCcnJ8UX9ofyB3qX3z0IVxpS+V4DV3OHXcho2BvnyAWxRyEWV/p9l20XfBHFaZerGcea4R7nIJu019EsBbPul2uXkVfel6xXp1dlq8JrhSNr+w9lzNfaZqzXIZdnB6ZAN4BE6hQA5UowwdyXZih3BzT2ThN1U69zoaSdikbsS66K2PGofmp2qAeyntQsZkx0AFeFl3pXSpeI16wXy

NcmV0cnjGcY19qXWNelF3qX2b4Th2D+UWDHxxDTTlcDPOd4msScbRNe5NeaRZTXPlfsa+Ko+FcakoPgdM7OS7xr6pt4qL4mQMDB1z9yZWdnh4dXHNcsVzFXn4NOF3uX6yn/KJHXKic5so1nqbD4yWBAumxfUuhndWKWqEg+Mm2hMu2UteoOXRR4D9H9HAsMVMnY6TFWggeBEwbXMh4gV0IpI+dW0wxnbT1RZ+1XMFdCp3qXDEkHx2snA56E143WV

lFCuNFHZNdb53FHOFdTV7enyJRkKn8ng1CAp+q7oKeUV4vXOI37VxFXkTDHV1zXYBdnV6sHF1ePu/PXq9d9Vo1nswBgQLbwZIAUdb65vge0aFosPPtVEIM73TgzONHV363AsIRB/Rz04Q8eSCxICtRrQgeAV3VXCNehZyun4WctV6ZXWKs/+5jXZyewV3qXmYUHx0fAzBbsx8csy7wjEjrwkiejV7zH41f8x5NX/ZcQ+0mZLhwqJ8pn5Ff4N6OXh

Derl3HXW9ec14nX2OscVwGXqdfENwuQpDcNg7PDWkdQWcYuYECD1DLXsZR3B6XwGd4PXMEMVrJdsNJt/DKaBNPHcHCdii5ntkd68I0xnI6N17pXzdcNV4ZXwDfNV0GbrVeW19BX1te6l5q8x7XdV+J8o6RekK/u1Rco3DxnGC0PUpIXY1eeVxNXtpdtFyI0DWfkV7Y3ZDepKPHXLNVUN4nH/pe7oyVn9jdMN8EXtXgJAJ9UTrAswCu4nDcjEHcHZ

WA7WVpRALxWssq4/61RwQaLPPb54GViSNxGoV6MDY1w1wA3SpdD55IEbdfiuxWX4GXgN3TH3dcaN9A3Wjdc286H1NzFdN9Rjleeh0zhmHNROd2X6ai9l77X01dCOPioQdcqJzAAqBkNzIHX6dejl+03bNfkNxuXUoI3XXi7i2u3h71cXTcBHG03mKfiC9mHoZeK/HxYsSrQgMWIQTf2u0kYhsp8cN0jIKLHZrow+/oLsf4KQ2fatMOIem6EWLCla

RPhwl9qNZj60PO+ujDl+8PnZZfgV7Gn4+cPe3mFAUdnGMr9XxTofUq7+SdIN1oBLYfUPXU3J2cou9PXODcEhx9grhdQADdnlhwUAEYXlFeJbcgXHcGqNFC3ZAL3517nluf6F5C30LebvrC34edwiKIBCLdoF303jjcUNwnXECewl8nXnFfommC3ELf7Qoi3XhdtRpi3REmaF+i3SLdF58Sbc8NviAaAi/g/XGBIWO25V2K5bq1lTBXpcx2msi2NR

nSM0OB7VNho7lYHtNUQzrI38NdG10A3C2eHJ0tnnBdPN9O7tZfN1EajAhfWGqCwtmPL50Y3A+z/jUdzvfuT1xTX09e4W4nNflcMEczXH2U4maYHABQqJza3KOUz+7HXhLcDN9FXJLexV90nep0019wwGVxrhDzlqVcYF7M3sGv6AM8ArQAWzrawyzcV9NiTqgRLRgdiN9H8/YyqBZ4mVRQ4OfuzCKB15djJGBROSQqpN4bXLddsmVk3sFvUx3GnF

RsQN1bXUDe911o3xcYTh4js4+50687XVTez6MzWG+U5px5X2+eTV+a3B7uQHBZlyWUKZZHsthkz6TmZ7MYqJ3plx81TMGZlfmWlWWPpQ7e2lCO3BLeel8xXzjcet0nXcVfwl3aWAem9t5O3qVnZZTO30ykLkKO38Getp6ZAhYC2sGwAyfJRtzO0awTggwWqayeYCWIXq7RsMnZYKzAspHgYpqicaFK73BtP+//XebcKN7c3YFcVex3Xzptal+o3F

bdd2DPnFQMHx+O4skqHpw1ZLtfT+c/+EdSWl+g3V8eYNzfHHbfWN47myFC5mdVlpdZNRtrAYgD1ZbY5KifOwKO3xG174HfQW7e5mZMq+HfbcAjDejnEd1Eso7dzB/03i7fut9VnjhertynXJWfkd9h3imU1PDH8hHe5mQx3qAAHt6Zn1AddRBTA9ACggAAB7nyfOrlXGlG8N31MYivKLGWFlpwJyKMGTTmBqOI3HzySN3kZ+tdyN8WXv7eZN3c3A

HcQV4+LqrcCp/OpnVfJvimnQrj2TKf2lTfSnG+y782e1ya33tdmtxh3tyCeN7srNjcFLcx3rresdydXu9c817qbB9d4+4363ncXOzuF8jtdRB4n3sDGka3AD5e8tw2AMQhQ4U2wIV2wAtlCXxvC4NREGK1akzVgAaC5lzK3ubfyN5WFjVfijUq3BRd8w8B3BTegdyWQM+dsg6U3f2q1LkLpUiBVN9okM2d6w+yDXtfVdj7X/guz1xNiWHfaAOgZf

ycUSkN3JiBSSICnHTeFsjx3w3fIGaN3s3cTdxin87dHV96XQzdbo7btozcrYuN383eUV2N3MfxzdwgAk3cQp41nAIDmxMQAXHianFLAvLf00EHgUHHbKL8Nzriv3mZZzHo+05CiQcKHxxIdIyTRDXEH1PyXN7t41zfG12U5+RdlK53XNXebpx1Xndyxezo32LAbFYDi1k6IN3B3BhHUpOeYzwlmNxg3FjdYN5+1nbcYbZAclLdNRg9niPMMCE9n5

BwwmioIEyqgw1PQQ3fZ7Du+i3cuIIzX+PeTKoT31Lev56T35LrYUBT3QeezdzT3+3fjFxN3K3dON2x32Occd163kBcKF24XBPdE9//wJPfIQ+z3tksvZ9z3jey09zt3R3csl4Exb4jtALCA0EGL3fgAQX6Pl9biZ1hwLRO1AiOTm/qeQ7IV8BvlkKLdpTOrIps5t7VXP7cGV3+3cuccJ8q3kFcWd5A3gqdgd3qXSbtat6mQY25neIY33zdEWrsuc

xJdd6235jftt9j31NfYt0TEWHcs980QbPcPSLRLg8OaFzR38fdgqLL3SfeC5c637vvs10S3S7fsdzuXZLe0N8SxCOdp/HH3CLfNgon35Pch5VmHQr1k++RicUiwgLbwF3P511JXPs6juD2whumBPdSAuY6YGvs1hph7JYGobDLyPX40q8izdOy250PAK2fAqlmmGOV3tranmlTHiucqt7X7IHee9/V3epdzu773tpry7Xq3ExB8PBk4bq5IdxPXb

bdT162HXfVNN3TMQpVESjonHzne5XU8/lwNDMr87xqGNYz1s+R3tmT4mGBEgNRKNWnGUBNQ4mbDafNwGYDJoaBA8tVLpiYg3UcrTAfQNJqX+OSVGtVtFs0ar/d+9Q5BmQAf98tX3/feaKVQpdAAD4b1pADAD0Nc8A9dpmZ7AtVrooVTSDSgkhebOOcns3VnSUdQD7f3ZHm/2Q/3lVwID//ISA+zy6gPJFuCKvSAP/dYD63QOA8rqvgPDViEDxxkk

Xv195gXEgCmpD6A7cCSAKCA/81rtRLU5bCoc6sZlHQyvA3mDjuukN0IWUGLwl5niRrHdLA+rTgpsu7FprJCbEvIitgA1wW3bjv/Ml5H9BIG1MS7yr53ScrnYL0Hx/vIDPm+NOpSCGO5GyEWj2oi7PR4FJn7xvo9qSPKEBcwC4hqJO3UqiSz0Jz+IjEMWhaaOvDBSSWArdRa4/aA7HXe6nPU5TvpqTPni+guJ2GXArkUgLF7Ns7YADLAi6xWQKCAl

wAb4EcyfdZ2Z6eTKzcw4iu0dKUdYMrYAo1iScCi7iPlnn2I43hb0vEHebDcyp0u4hRU9tEhYrtFt8v3bver97V36/cnCDPnrMMCJ056I4BVmeS7oGYwnku76Pcod5j3I/CQlHokU+Ykg4wrBeLMK8Kw4l7+ml9i8ahxhu1Tp2OMqgYTHxifzFgkx1PmrmREjfFvMg1iX95PU3aBOx1VmDTc7hFmtDsP9MrTdOjc3Qg1HHGoT0XHD0KY18D1GJ7Mi

tgM2jDjQV6VLuWuyti1hhkejw8f48skByRUcNzTXbv9Ux/jxg8HU+hjUaOs49N4vST9FJja2rDbU9suocZmhuoin9ShY3CPFDwOLQB83nSjsFRw2I+oGB5083gK0FpTly7O7hnMRdT9rODu11P1AOzjXQ/DyD0P2I+dDxac/I/D3p9Tu/IW43xolhQ/HfuTgSk/U0VsvI/Cj1/xpiFvgGVsMv7iD6yARwDf7cJ4tvDWs/IPUOpBo15Ws3IbzjUwN

wSN520TfLDFfD3IMOpad8VX6tYzdCXAv9fzmRM2TqgcoBEwQPcrHdYPW162D0GS9g9VlyYJ9IzOh0LaklunI7LTww7CWtDh+4NSU2oMyYr+D/ZVgQ/BABcwgqC3bc7qifQruF5WVuqqgOcAxAB5QDbquABk8lMAuAD9yDowU9Ti/taBphBpD0UBM+dmmFkPWwC28JOafaJ1uEt7V7CKOzO0++ybKO/OcfZuvBXy07h83g8ejGjevlp3557zZKt0x

EAaBHiGEOxTEgewaHl9sFWY7o9RZp6Poabej1PUIowOD1BXvOuBjxAtTdwya7N05a4JGEW7B5HVtH4PIckBDwN3gNxJO2b+5HB2gHk7iwAhAGVigqBt1H7g96wUQIx10MB5j+/L+hAcde05oCbpD3qXyqA1jz5E/dwV8xn9dmctj5pbqxAuHnFFaTAlud6g2FJs2JQ+9Nh5ds3y9NABnMrqsh2fRcQ4554hYz/o53Rz94o3EvsLj1DRS49J+auP7

vdOD773ZeD1t+D8ReupfSAhOjB7j6sjf3uzm7NmsY8y9vGPSTuUdXlklGsOgIWPdurd1E7qfP55QO3UKQGm6nk7puo1+lK+yQ+lO8YQFY+FkDPnhFz/j0tMW4QQQKgQdyUgTwoP1Q+fy+2Uty6StiPOtaRs7TcGuoBUtPs3pHNCFEc3xwS++uGR1UxjA9pGUNQlufP3nskET2tmRE9E9CRPIw9YQwfHxnIaxJoGpSzXLtXg0KPNgL5ZMY/Hj3GPp

4/fUnXUp0Ds4LOICQAT1BsAY/pDgBEKFrtCu+C2FrvnQG7qPAB5jyShJTucdXPUX1Mw4d0A7rAKT/cG7wCXAGw9+cjp5nqPOcZSTK7aZF1lYt7YckwW0bfXpqjvGGdAXCDgfMcNX2I0NtLuggcTEIeeUaM/XpyTc4/ETo5PxYbOT1j8rk/ZB+uPvvduwlGG0YqNgtrJh5GTuZpFYEVb7kFPSKknj+D7sZxBD6ZAEQrhgPOItWB8/gbq2ACW6vH5U

r5/xuho0U826p0ALupHT2raA4C7AP8WWU9fjzJPnVcAaIVP2fQwpFgnD2BqT/qPVU/umqGuvCOlNomm8xOlEMaMpEBekKEnPgGNht3OqPe6xOOPAQg+IyskTRCh2NUQIIdO92XhQHWj5zYPslB2D5lx409pJ+5PvvcKmnq3cBH1cmgKrO3Qo5I+wxnH1SxPFg5sTxcwxAAr5sGALYAOVD2AIQ9vtw7qDqh26s7qPAARD50A7OAbAKq2H48pD2U7O

U+78jPnuTiFT+bNRYhCAK0A0IByD9Xnees4OGDsrXHzZPnhHRjlYNIps52aBuAsi67YJKLer8NxThiTw8nU1jtEf072T3EaIPeZ6xbX/Kce91Z3UPf/zfbXlCFv7AFBrNt3XPviwLDH970dPXcGPUeysRhtF0cATeTLgMp5Y7cBz9EAQc8qZwwEN7If3J3TKiw71w4XRfecd+S392GBz7zAjWef/MgmmADP4PpGFU+KD864xF1R8JHUpnig0NmqB

enholSNoE1tT3/UAgexz4cl6SGOoG68W4i7LEH3oFd+FRjP7dcbrKNPvo/xp2W3OQfOhwV3rg/A0Ol1xKy72OnVxmL7g1bFjl3MT8FPrE+hT0R1pkDYAJ+1R0/26vbqakps/vGYIQCW6nuiEhCuoMQAHxih2HVAxTuljz7qz09Q91W4hU/HtcjQCQDewGBAX1fFhy6QY3LA9KqGWspMT15szThvMOoCW/lptwe08Luoz8Z36/UDD9vHgHeFF21XE

Pc91173RLg7APd9oqdcG+6RGsRfBfpwcQiez7NsSWTez+PPrz4X96FPbzjfOCpnBFtxDmIAZcsWjgog7OBS1aZ6dXgvAG8AXwB/AICAIIAQgFCAcIAyPLy9p3f5yCrcMsD6AGPJF7f+Mm8l6FjUjWoiVpyN4/H62xOwQyB1n0nmz+XqS/eqNzbP5bdjD//7epfjh4TPxC6StOzHjqvxlnYFSC9ioCgvbnfVdkXtqqPRO0WntJBYL2wcOC+UDyL3y

ecxrad37QD83BImpDkcLwjYnE9c0MkoGNpC2ommZqhRrgMcIxxmprH6P8+DTwv3aqaDDxIvUIVr93bPsKrC3DD3bY1mQ3QUereOq+holvrj1zSsGi+n94kjtNkud75X9iLYL+5rhffsV8X37jcfYBGF4AD3QNsAECIkYGUAB4DQAOEgR1iPUH0A74iDqGBAEfb+gBIQEhD7APWE2XP4KGkA/IkVjTMkTS8kiy0vxpF9h50vk0DdL2UKJi19L0bYP

6ptL+5mwy9J2KMvZlcTL3R8P6rewEACMy/dL3IQDmyLLz+qrQxag6svaQDrL1N1my/6APkgUxG7L7ugKw03iLsvN4BcpWh0m7n4gFiIBUhVuPGwrO0nSWd45PzX2lcvGA9jPAXAy3SxCgjjNHB6MHV4cFDgpGzUDABbcI8wwLCODCH42uzNRBYQuy/zLzF4GaiNL1GAJADrKL3guzgkAFQQ8cBgQPy9AYDggJMAWK9Yr1qyeIC+wNFRQwiBQsSvR

wB4r5CvKQtjLyVqz8W4CmDDCUjsAIAQhcgIr+8QSK8nyL7AOHJv5gqAKhDIoB+ASWTn9OtQ+CIAnNLCZ5DHWIIQkK92APZD/Ig8g78weFYbAGcvIkgi1AzgYU/7gJhAZ4BAAA===
```
%%